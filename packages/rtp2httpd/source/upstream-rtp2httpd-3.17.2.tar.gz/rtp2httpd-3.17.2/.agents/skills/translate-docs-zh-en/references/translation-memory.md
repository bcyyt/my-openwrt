# Translation Memory for rtp2httpd Documentation

## Terminology Conventions

### Preserved Product/Technical Names

- rtp2httpd, udpxy, msd_lite, FFmpeg, APTV, TiviMate, LiteTV, Wireshark
- FCC (Fast Channel Change) - expand on first use
- FEC (Forward Error Correction) - expand on first use
- VA-API, V4L2, QSV - hardware acceleration names
- fnOS - keep as-is

### Standard Translations

- 组播 -> multicast
- 单播 -> unicast
- 快速换台 -> fast channel change / channel switching
- 无缝换台 -> seamless channel switching / Seamless switch (player setting label)
- 时移回看 -> time-shifted playback / time-shift / catch-up
- 媒体直链 -> media link / direct media URL
- 电子节目单 -> EPG (Electronic Program Guide)
- 频道 -> channel
- 线路/源 -> source
- 播放列表 -> playlist
- 上游服务器 -> upstream server
- 反向代理 -> reverse proxy
- 机顶盒 -> set-top box
- 抓包 -> packet capture
- 起播 -> start playback
- 帧间压缩 -> inter-frame compression
- 关键帧 / IDR 帧 -> keyframe / IDR frame
- P 帧 / B 帧 -> P-frame / B-frame
- NAT 穿透 -> NAT traversal
- 端口转发 -> port forwarding
- 慢客户端 -> slow clients
- 缓冲池 -> buffer pool
- 丢包 -> packet loss
- 花屏 -> artifacts
- 卡顿 -> stuttering
- 后台 -> admin panel / admin interface
- 画质增强 -> video enhancement
- 存活探测 -> liveness probe
- 行为变更 -> Behavior change
- 响应头 -> response header
- 上游流 Metadata -> upstream stream metadata (the `R2H-*` headers)
- Prefer "build" over "compile" except in literal commands.
- For packet-capture setups, use "traffic interception" or "packet capture via gateway", not "man-in-the-middle".

### Page Titles

- 详解 / 参数详解 -> Reference, for example Configuration Reference.
- 说明 -> a noun title or Guide, for example URL Formats.
- 报告 -> omit when redundant, for example Performance Benchmark.
- 建议 -> Guide, for example Public Access Guide.
- Use plural titles for multiple items; reserve Specification for an actual standard.

### China-specific Terms

- 运营商 -> operator / ISP (电信 -> China Telecom, 联通 -> China Unicom, 移动 -> China Mobile)
- 华为 -> Huawei, 中兴 -> ZTE, 烽火 -> FiberHome
- 央视 -> "CCTV" (do not keep Chinese in English docs)
- 卫视 -> Satellite (as group name)
- Province/city names -> standard pinyin (浙江 -> Zhejiang, 杭州 -> Hangzhou, etc.)

## Project-specific Patterns

- Benchmark tables use emoji trophy (🏆) to mark best performers.
- FCC collection: retain Chinese ISP names with English translation on first use.
- Chinese tutorial URLs are kept unchanged when the target content is Chinese-only.
- `AI 网络诊断助手` -> `AI Network Troubleshooting` for the self-contained consumer AI prompt
  page and its sidebar entry.

## Admonition Style

The project convention is GitHub alert syntax (`> [!NOTE]`, `> [!TIP]`, `> [!IMPORTANT]`,
`> [!WARNING]`, `> [!CAUTION]`). Preserve any existing VitePress containers when translating;
changing alert formats is a separate source edit.

GitHub alerts cannot carry a custom title. If a Chinese source needs one, put it as a
bold lead-in inside the alert body (`> **行为变更**：…`) and mirror that in English.
