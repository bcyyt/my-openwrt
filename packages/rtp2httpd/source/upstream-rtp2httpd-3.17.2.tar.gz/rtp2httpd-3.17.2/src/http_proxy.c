#include "http_proxy.h"
#include "buffer_pool.h"
#include "configuration.h"
#include "connection.h"
#include "http.h"
#include "http_headers.h"
#include "http_proxy_rewrite.h"
#include "platform_compat.h"
#include "poller.h"
#include "status.h"
#include "utils.h"
#include "worker.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <unistd.h>

/*
 * HTTP Proxy Client Implementation
 *
 * This module implements an HTTP reverse proxy that forwards requests
 * to upstream HTTP servers and streams the response back to clients.
 */

/* Helper function prototypes */
static int http_proxy_build_request(http_proxy_session_t *session);
static int http_proxy_try_send_pending(http_proxy_session_t *session);
static int http_proxy_try_receive_response(http_proxy_session_t *session);
static int http_proxy_parse_response_headers(http_proxy_session_t *session);
static int http_proxy_append_raw_headers(http_proxy_session_t *session, char **dest, size_t *remaining, int *total_len,
                                         int filter_user_agent);
static void http_proxy_pause_upstream(http_proxy_session_t *session);

static void http_proxy_parse_transfer_encoding(http_proxy_session_t *session, const char *value) {
  const char *cursor = value;
  int saw_token = 0;

  session->transfer_encoding_seen = 1;

  while (*cursor) {
    const char *token_start;
    const char *token_end;
    const char *element_end;

    while (*cursor == ' ' || *cursor == '\t' || *cursor == ',')
      cursor++;
    if (*cursor == '\0')
      break;

    token_start = cursor;
    while (*cursor && *cursor != ',' && *cursor != ';' && *cursor != ' ' && *cursor != '\t')
      cursor++;
    token_end = cursor;
    while (*cursor && *cursor != ',')
      cursor++;
    element_end = cursor;
    while (element_end > token_end && (element_end[-1] == ' ' || element_end[-1] == '\t'))
      element_end--;

    if (token_end == token_start) {
      session->unsupported_transfer_coding = 1;
    } else if ((size_t)(token_end - token_start) == 7 && strncasecmp(token_start, "chunked", 7) == 0 &&
               element_end == token_end && !session->response_is_chunked) {
      session->response_is_chunked = 1;
    } else {
      session->unsupported_transfer_coding = 1;
    }
    saw_token = 1;

    if (*cursor == ',') {
      if (session->response_is_chunked)
        session->unsupported_transfer_coding = 1;
      cursor++;
    }
  }

  if (!saw_token)
    session->unsupported_transfer_coding = 1;
}

static int http_proxy_get_app_base_path(char *output, size_t output_size) {
  int written;

  if (!output || output_size == 0)
    return -1;

  if (config.app_path_prefix && config.app_path_prefix[0] != '\0')
    written = snprintf(output, output_size, "%s/", config.app_path_prefix);
  else
    written = snprintf(output, output_size, "/");

  return (written >= 0 && (size_t)written < output_size) ? 0 : -1;
}

static const char *http_proxy_get_cookie_path(void) {
  return (config.app_path_prefix && config.app_path_prefix[0] != '\0') ? config.app_path_prefix : "/";
}

static const char *http_proxy_get_override_user_agent(void) {
  if (config.http_proxy_user_agent && config.http_proxy_user_agent[0] != '\0') {
    return config.http_proxy_user_agent;
  }

  return NULL;
}

/**
 * Set HTTP proxy session state and update client status
 */
static void http_proxy_set_state(http_proxy_session_t *session, http_proxy_state_t new_state) {
  static const client_state_type_t proxy_to_client_state[] = {
      [HTTP_PROXY_STATE_CONNECTING] = CLIENT_STATE_HTTP_CONNECTING,
      [HTTP_PROXY_STATE_SENDING_REQUEST] = CLIENT_STATE_HTTP_SENDING_REQUEST,
      [HTTP_PROXY_STATE_AWAITING_HEADERS] = CLIENT_STATE_HTTP_AWAITING_HEADERS,
      [HTTP_PROXY_STATE_STREAMING] = CLIENT_STATE_HTTP_STREAMING,
  };
  if (session->state == new_state)
    return;
  session->state = new_state;
  session->last_state_change_ms = get_time_ms();
  if (new_state < ARRAY_SIZE(proxy_to_client_state) && proxy_to_client_state[new_state] != 0) {
    status_update_client_state(session->status_index, proxy_to_client_state[new_state]);
  }
}

void http_proxy_session_init(http_proxy_session_t *session) {
  memset(session, 0, sizeof(http_proxy_session_t));
  session->initialized = 1;
  session->state = HTTP_PROXY_STATE_INIT;
  session->socket = -1;
  session->epoll_fd = -1;
  session->status_index = -1;
  session->target_port = 80; /* Default HTTP port */
  session->content_length = -1;
  session->bytes_received = 0;
  session->headers_received = 0;
  session->headers_forwarded = 0;
  session->upstream_paused = 0;
  session->cleanup_done = 0;
}

/* Pause/resume are flag-only.  We deliberately avoid `poller_mod` because on
 * kqueue (src/poller_kqueue.c) a mask without POLLER_IN/POLLER_OUT deletes
 * the read AND write filters, silently losing HUP/EOF detection while
 * paused.  Edge-triggered pollers will keep waking the worker for new data
 * arrivals; the recv handler bails out via the HWM check when the queue is
 * saturated.  This keeps the kernel TCP recv buffer the natural backstop:
 * once it fills, the upstream sender's window closes naturally.
 */
static void http_proxy_pause_upstream(http_proxy_session_t *session) {
  if (!session || session->upstream_paused)
    return;
  session->upstream_paused = 1;
  connection_record_pause(session->conn);
  connection_recompute_any_upstream_paused(session->conn);
  logger(LOG_DEBUG, "HTTP Proxy: Paused upstream reads (queued=%zu limit=%zu)",
         session->conn ? connection_queue_bytes(session->conn) : 0,
         session->conn ? session->conn->queue_limit_bytes : 0);
}

void http_proxy_resume_upstream(http_proxy_session_t *session) {
  if (!session || !session->upstream_paused)
    return;
  session->upstream_paused = 0;
  connection_recompute_any_upstream_paused(session->conn);
  logger(LOG_DEBUG, "HTTP Proxy: Resumed upstream reads");
  /* Drain synchronously here: edge-triggered pollers won't deliver another
   * EPOLLIN edge for bytes that arrived while paused, so anything still
   * buffered in the kernel must come out in this call frame.  Loop exits
   * on EAGAIN, HWM re-pause, EOF, or error. */
  while (session->state == HTTP_PROXY_STATE_STREAMING && !session->upstream_paused) {
    int ret = http_proxy_try_receive_response(session);
    if (ret <= 0)
      break;
  }
  /* EOF discovered mid-drain: no further upstream events will arrive, so
   * close the upstream socket here and start the client drain. */
  if (session->state == HTTP_PROXY_STATE_COMPLETE) {
    if (session->socket >= 0) {
      worker_cleanup_socket_from_epoll(session->epoll_fd, session->socket);
      session->socket = -1;
    }
    connection_begin_drain_close(session->conn);
  }
}

int http_proxy_parse_url(http_proxy_session_t *session, const char *url) {
  const char *p;
  char *slash;
  size_t host_len;

  if (!session || !url) {
    logger(LOG_ERROR, "HTTP Proxy: Invalid parameters to parse_url");
    return -1;
  }

  /* Skip /http/ prefix if present */
  if (strncmp(url, "/http/", 6) == 0) {
    p = url + 6;
  } else if (strncmp(url, "http://", 7) == 0) {
    p = url + 7;
  } else {
    /* Assume it's already host:port/path format */
    p = url;
  }

  /* Find the first slash after host:port */
  slash = strchr(p, '/');

  /* Extract host and port */
  if (slash) {
    host_len = slash - p;
  } else {
    host_len = strlen(p);
  }

  /* Parse host[:port], handling "[IPv6]:port", bracketed/bare IPv6 literals,
   * hostnames, and IPv4.  target_host stores the bare host (no brackets). */
  {
    char hostport[HTTP_PROXY_HOST_SIZE + 16];
    if (host_len >= sizeof(hostport)) {
      logger(LOG_ERROR, "HTTP Proxy: Host too long");
      return -1;
    }
    memcpy(hostport, p, host_len);
    hostport[host_len] = '\0';

    if (parse_host_port(hostport, session->target_host, sizeof(session->target_host), &session->target_port) != 0) {
      logger(LOG_ERROR, "HTTP Proxy: Invalid host format: %s", hostport);
      return -1;
    }
  }

  /* Validate port */
  if (session->target_port <= 0 || session->target_port > 65535) {
    session->target_port = 80;
  }

  /* Extract path (including query string), but strip r2h-token to avoid
   * leaking credentials to upstream server */
  if (slash) {
    if (strlen(slash) >= HTTP_PROXY_PATH_SIZE) {
      logger(LOG_ERROR, "HTTP Proxy: Path too long");
      return -1;
    }

    /* Check if URL has query string with potential r2h-token */
    const char *query_start = strchr(slash, '?');
    if (query_start && config.r2h_token && config.r2h_token[0] != '\0') {
      /* Copy path portion up to query string */
      size_t path_len = (size_t)(query_start - slash);
      memcpy(session->target_path, slash, path_len);

      /* Filter out r2h-token from query string */
      char filtered_query[HTTP_PROXY_PATH_SIZE];
      int filtered_len = http_filter_query_param(query_start + 1, "r2h-token", filtered_query, sizeof(filtered_query));
      if (filtered_len > 0) {
        /* Append filtered query string */
        int result = snprintf(session->target_path + path_len, HTTP_PROXY_PATH_SIZE - path_len, "?%s", filtered_query);
        if (result < 0 || (size_t)result >= HTTP_PROXY_PATH_SIZE - path_len) {
          logger(LOG_ERROR, "HTTP Proxy: Path with query too long");
          return -1;
        }
      } else {
        /* No remaining query params, just terminate at path */
        session->target_path[path_len] = '\0';
      }
    } else {
      /* No query string or no r2h-token configured, copy as-is */
      strncpy(session->target_path, slash, HTTP_PROXY_PATH_SIZE - 1);
      session->target_path[HTTP_PROXY_PATH_SIZE - 1] = '\0';
    }
  } else {
    /* No path, default to / */
    strcpy(session->target_path, "/");
  }

  logger(LOG_DEBUG, "HTTP Proxy: Parsed URL - host=%s, port=%d, path=%s", session->target_host, session->target_port,
         session->target_path);

  return 0;
}

void http_proxy_set_method(http_proxy_session_t *session, const char *method) {
  if (!session || !method)
    return;

  strncpy(session->method, method, sizeof(session->method) - 1);
  session->method[sizeof(session->method) - 1] = '\0';
}

void http_proxy_set_raw_headers(http_proxy_session_t *session, const char *raw_headers, size_t raw_headers_len) {
  if (!session)
    return;

  /* Store pointer reference instead of copying - raw_headers points to
   * http_request_t.raw_headers which remains valid during the proxy session */
  session->raw_headers = raw_headers;
  session->raw_headers_len = raw_headers_len;
}

void http_proxy_set_request_body(http_proxy_session_t *session, const char *body, size_t body_len) {
  if (!session)
    return;

  session->request_body = body;
  session->request_body_len = body_len;
}

void http_proxy_set_request_headers(http_proxy_session_t *session, const char *host_header,
                                    const char *x_forwarded_host, const char *x_forwarded_proto) {
  if (!session)
    return;

  if (host_header) {
    strncpy(session->host_header, host_header, sizeof(session->host_header) - 1);
    session->host_header[sizeof(session->host_header) - 1] = '\0';
  } else {
    session->host_header[0] = '\0';
  }

  if (x_forwarded_host) {
    strncpy(session->x_forwarded_host, x_forwarded_host, sizeof(session->x_forwarded_host) - 1);
    session->x_forwarded_host[sizeof(session->x_forwarded_host) - 1] = '\0';
  } else {
    session->x_forwarded_host[0] = '\0';
  }

  if (x_forwarded_proto) {
    strncpy(session->x_forwarded_proto, x_forwarded_proto, sizeof(session->x_forwarded_proto) - 1);
    session->x_forwarded_proto[sizeof(session->x_forwarded_proto) - 1] = '\0';
  } else {
    session->x_forwarded_proto[0] = '\0';
  }
}

/* Free the getaddrinfo candidate list (after success or final failure) */
static void http_proxy_free_connect_results(http_proxy_session_t *session) {
  if (session->connect_results) {
    freeaddrinfo(session->connect_results);
    session->connect_results = NULL;
    session->connect_next = NULL;
  }
}

/* Called when the current socket connected successfully: keep it, drop the
 * remaining candidates, and queue the HTTP request. */
static int http_proxy_on_connected(http_proxy_session_t *session) {
  http_proxy_free_connect_results(session);

  http_proxy_set_state(session, HTTP_PROXY_STATE_CONNECTED);

  /* Build and queue HTTP request */
  if (http_proxy_build_request(session) < 0) {
    logger(LOG_ERROR, "HTTP Proxy: Failed to build request");
    http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
    return -1;
  }

  http_proxy_set_state(session, HTTP_PROXY_STATE_SENDING_REQUEST);
  return 0;
}

/**
 * Try connecting to the next candidate from the getaddrinfo result list
 * (sequential dual-stack fallback, IPv6/IPv4 in resolver order).
 * On EINPROGRESS the session enters CONNECTING and the poller drives
 * completion; on hard failure the next candidate is tried immediately.
 * @return 0 if a connection succeeded or is in progress, -1 when all
 * candidates are exhausted
 */
static int http_proxy_try_next_candidate(http_proxy_session_t *session) {
  while (session->connect_next) {
    struct addrinfo *rp = session->connect_next;
    session->connect_next = rp->ai_next;

    int sock = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
    if (sock < 0) {
      session->connect_last_errno = errno;
      continue;
    }
    platform_set_nosigpipe(sock);

    if (connection_set_nonblocking(sock) < 0) {
      session->connect_last_errno = errno;
      close(sock);
      continue;
    }

    /* Bind to upstream interface if configured */
    bind_to_upstream_interface(sock, session->upstream_ifname);

    int connect_result = connect(sock, rp->ai_addr, rp->ai_addrlen);

    if (connect_result == 0) {
      /* Immediate connection success (rare, but possible for localhost) */
      logger(LOG_DEBUG, "HTTP Proxy: Connected immediately to %s:%d (%s)", session->target_host, session->target_port,
             rp->ai_family == AF_INET6 ? "IPv6" : "IPv4");

      session->socket = sock;
      if (session->epoll_fd >= 0) {
        if (poller_add(session->epoll_fd, session->socket,
                       POLLER_IN | POLLER_OUT | POLLER_HUP | POLLER_ERR | POLLER_RDHUP) < 0) {
          logger(LOG_ERROR, "HTTP Proxy: Failed to add socket to poller: %s", strerror(errno));
          close(session->socket);
          session->socket = -1;
          return -1;
        }
        fdmap_set(session->socket, session->conn);
      }

      return http_proxy_on_connected(session);
    }

    if (errno == EINPROGRESS || errno == EWOULDBLOCK) {
      /* Connection in progress - normal for non-blocking sockets */
      logger(LOG_DEBUG, "HTTP Proxy: Connection to %s:%d in progress (async, %s)", session->target_host,
             session->target_port, rp->ai_family == AF_INET6 ? "IPv6" : "IPv4");

      session->socket = sock;
      if (session->epoll_fd >= 0) {
        if (poller_add(session->epoll_fd, session->socket,
                       POLLER_OUT | POLLER_IN | POLLER_ERR | POLLER_HUP | POLLER_RDHUP) < 0) {
          logger(LOG_ERROR, "HTTP Proxy: Failed to add socket to poller: %s", strerror(errno));
          close(session->socket);
          session->socket = -1;
          return -1;
        }
        fdmap_set(session->socket, session->conn);
      }

      http_proxy_set_state(session, HTTP_PROXY_STATE_CONNECTING);
      /* Restart the per-candidate timeout even if we were already in
       * CONNECTING (set_state is a no-op for same-state transitions) */
      session->last_state_change_ms = get_time_ms();
      return 0;
    }

    /* Hard failure - try next candidate */
    session->connect_last_errno = errno;
    logger(LOG_DEBUG, "HTTP Proxy: connect() to %s:%d failed (%s): %s", session->target_host, session->target_port,
           rp->ai_family == AF_INET6 ? "IPv6" : "IPv4", strerror(errno));
    close(sock);
  }

  logger(LOG_ERROR, "HTTP Proxy: Failed to connect to %s:%d: %s", session->target_host, session->target_port,
         session->connect_last_errno ? strerror(session->connect_last_errno) : "no usable address");
  http_proxy_free_connect_results(session);
  return -1;
}

/**
 * Handle failure of the in-progress connect attempt: close the current
 * socket and fall back to the next address candidate if one remains.
 * @return 0 if another attempt was started, -1 if all candidates failed
 */
static int http_proxy_handle_connect_failure(http_proxy_session_t *session, int error) {
  session->connect_last_errno = error;
  logger(LOG_DEBUG, "HTTP Proxy: Async connect to %s:%d failed: %s", session->target_host, session->target_port,
         strerror(error));

  if (session->socket >= 0) {
    worker_cleanup_socket_from_epoll(session->epoll_fd, session->socket);
    session->socket = -1;
  }

  return http_proxy_try_next_candidate(session);
}

int http_proxy_connect(http_proxy_session_t *session) {
  struct addrinfo hints;
  char port_str[16];
  int gai_result;

  if (!session || session->socket >= 0) {
    logger(LOG_ERROR, "HTTP Proxy: Invalid session or already connected");
    return -1;
  }

  /* Resolve hostname (dual-stack: IPv6 and IPv4 candidates) */
  memset(&hints, 0, sizeof(hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  snprintf(port_str, sizeof(port_str), "%d", session->target_port);

  gai_result = getaddrinfo(session->target_host, port_str, &hints, &session->connect_results);
  if (gai_result != 0) {
    logger(LOG_ERROR, "HTTP Proxy: Cannot resolve hostname %s: %s", session->target_host, gai_strerror(gai_result));
    session->connect_results = NULL;
    return -1;
  }

  session->connect_next = session->connect_results;
  session->connect_last_errno = 0;

  return http_proxy_try_next_candidate(session);
}

static int http_proxy_build_request(http_proxy_session_t *session) {
  int len;
  char host_header[HTTP_PROXY_HOST_SIZE + 16];
  char *p;
  size_t remaining;
  const char *override_user_agent = http_proxy_get_override_user_agent();

  /* Build Host header with port if non-standard (IPv6 hosts bracketed) */
  if (format_host_port_for_url(session->target_host, session->target_port, 80, host_header, sizeof(host_header)) < 0) {
    logger(LOG_ERROR, "HTTP Proxy: Host header too long");
    return -1;
  }

  /* Use stored method or default to GET */
  const char *method = session->method[0] ? session->method : "GET";

  /* Build HTTP request - request line and mandatory headers */
  len = snprintf(session->pending_request, sizeof(session->pending_request),
                 "%s %s HTTP/1.1\r\n"
                 "Host: %s\r\n"
                 "Connection: close\r\n",
                 method, session->target_path, host_header);

  if (len < 0 || len >= (int)sizeof(session->pending_request)) {
    logger(LOG_ERROR, "HTTP Proxy: Request too large");
    return -1;
  }

  p = session->pending_request + len;
  remaining = sizeof(session->pending_request) - len;

  /* Add Content-Length header if there's a request body */
  if (session->request_body_len > 0) {
    int cl_len = snprintf(p, remaining, "Content-Length: %zu\r\n", session->request_body_len);
    if (cl_len < 0 || (size_t)cl_len >= remaining) {
      logger(LOG_ERROR, "HTTP Proxy: Request too large (Content-Length)");
      return -1;
    }
    len += cl_len;
    p += cl_len;
    remaining -= cl_len;
  }

  /* Add raw headers from client for full passthrough, filtering User-Agent
   * when a configured override should take precedence. */
  if (session->raw_headers_len > 0) {
    if (http_proxy_append_raw_headers(session, &p, &remaining, &len, override_user_agent != NULL) < 0) {
      return -1;
    }
  }

  if (override_user_agent) {
    int ua_len = snprintf(p, remaining, "User-Agent: %s\r\n", override_user_agent);
    if (ua_len < 0 || (size_t)ua_len >= remaining) {
      logger(LOG_ERROR, "HTTP Proxy: Request too large (User-Agent)");
      return -1;
    }
    len += ua_len;
    p += ua_len;
    remaining -= ua_len;
  }

  /* Add final CRLF to end headers */
  if (remaining < 3) {
    logger(LOG_ERROR, "HTTP Proxy: Request too large (final CRLF)");
    return -1;
  }
  strcpy(p, "\r\n");
  len += 2;

  /* Headers only in pending_request - body will be sent separately */
  session->pending_request_len = len;
  session->pending_request_sent = 0;
  session->request_body_sent = 0;

  logger(LOG_DEBUG, "HTTP Proxy: Built request headers (%d bytes, body %zu bytes) for %s%s", len,
         session->request_body_len, host_header, session->target_path);

  return 0;
}

static int http_proxy_append_raw_headers(http_proxy_session_t *session, char **dest, size_t *remaining, int *total_len,
                                         int filter_user_agent) {
  size_t offset = 0;

  while (offset < session->raw_headers_len) {
    size_t line_len = 0;
    const char *line = session->raw_headers + offset;

    while (offset + line_len + 1 < session->raw_headers_len &&
           !(line[line_len] == '\r' && line[line_len + 1] == '\n')) {
      line_len++;
    }

    if (offset + line_len + 1 >= session->raw_headers_len) {
      logger(LOG_ERROR, "HTTP Proxy: Malformed raw headers");
      return -1;
    }

    if (!(filter_user_agent && line_len >= 11 && strncasecmp(line, "User-Agent:", 11) == 0)) {
      if (line_len + 2 >= *remaining) {
        logger(LOG_ERROR, "HTTP Proxy: Request too large (raw headers)");
        return -1;
      }

      memcpy(*dest, line, line_len + 2);
      *dest += line_len + 2;
      *remaining -= line_len + 2;
      *total_len += (int)(line_len + 2);
    }

    offset += line_len + 2;
  }

  return 0;
}

static int http_proxy_try_send_pending(http_proxy_session_t *session) {
  ssize_t sent;
  size_t remaining;
  int total_sent = 0;

  /* Phase 1: Send request headers from pending_request buffer.
   * Loop to drain all writable data for edge-triggered pollers. */
  while (session->pending_request_sent < session->pending_request_len) {
    remaining = session->pending_request_len - session->pending_request_sent;
    sent = send(session->socket, session->pending_request + session->pending_request_sent, remaining,
                MSG_NOSIGNAL | MSG_DONTWAIT);

    if (sent <= 0) {
      if (sent < 0 && errno == EAGAIN) {
        return total_sent > 0 ? total_sent : 0;
      }
      if (sent < 0) {
        logger(LOG_ERROR, "HTTP Proxy: Send headers failed: %s", strerror(errno));
        return -1;
      }
      break; /* sent == 0: no progress */
    }

    session->pending_request_sent += sent;
    total_sent += (int)sent;
    logger(LOG_DEBUG, "HTTP Proxy: Sent headers %zd bytes (%zu/%zu)", sent, session->pending_request_sent,
           session->pending_request_len);
  }

  /* If headers not fully sent, wait for next writable event */
  if (session->pending_request_sent < session->pending_request_len) {
    return total_sent;
  }

  /* Phase 2: Send request body directly from request_body pointer.
   * Loop to drain all writable data for edge-triggered pollers. */
  while (session->request_body_len > 0 && session->request_body_sent < session->request_body_len) {
    remaining = session->request_body_len - session->request_body_sent;
    sent = send(session->socket, session->request_body + session->request_body_sent, remaining,
                MSG_NOSIGNAL | MSG_DONTWAIT);

    if (sent <= 0) {
      if (sent < 0 && errno == EAGAIN) {
        return total_sent > 0 ? total_sent : 0;
      }
      if (sent < 0) {
        logger(LOG_ERROR, "HTTP Proxy: Send body failed: %s", strerror(errno));
        return -1;
      }
      break; /* sent == 0: no progress */
    }

    session->request_body_sent += sent;
    total_sent += (int)sent;
    logger(LOG_DEBUG, "HTTP Proxy: Sent body %zd bytes (%zu/%zu)", sent, session->request_body_sent,
           session->request_body_len);
  }

  return total_sent;
}

static int http_proxy_append_rewrite_body(http_proxy_session_t *session, const uint8_t *data, size_t len) {
  size_t new_size;

  if (len == 0)
    return 0;
  if (!session || !data || len > REWRITE_MAX_BODY_SIZE - session->rewrite_body_buffer_used) {
    logger(LOG_ERROR, "HTTP Proxy: Rewrite body exceeds max size");
    return -1;
  }

  new_size = session->rewrite_body_buffer_used + len;
  if (new_size > session->rewrite_body_buffer_size) {
    size_t new_alloc = session->rewrite_body_buffer_size == 0 ? 16384 : session->rewrite_body_buffer_size * 2;
    while (new_alloc < new_size)
      new_alloc *= 2;
    if (new_alloc > REWRITE_MAX_BODY_SIZE)
      new_alloc = REWRITE_MAX_BODY_SIZE;

    char *new_buf = realloc(session->rewrite_body_buffer, new_alloc);
    if (!new_buf) {
      logger(LOG_ERROR, "HTTP Proxy: Failed to grow rewrite buffer");
      return -1;
    }
    session->rewrite_body_buffer = new_buf;
    session->rewrite_body_buffer_size = new_alloc;
  }

  memcpy(session->rewrite_body_buffer + session->rewrite_body_buffer_used, data, len);
  session->rewrite_body_buffer_used = new_size;
  return 0;
}

static int http_proxy_emit_decoded_body(void *opaque, const uint8_t *data, size_t len) {
  return http_proxy_append_rewrite_body((http_proxy_session_t *)opaque, data, len);
}

/**
 * Finalize M3U body rewriting: rewrite the buffered body and send the
 * response (headers + rewritten body) to the client.
 * Called when all body data has been collected or the upstream closed.
 * @return bytes queued on success, -1 on error
 */
static int http_proxy_finalize_rewrite(http_proxy_session_t *session) {
  int bytes_forwarded = 0;
  char *rewritten = NULL;
  size_t rewritten_size = 0;

  if (session->rewrite_body_buffer_used > 0) {
    /* Null-terminate for rewriting */
    if (session->rewrite_body_buffer_used >= session->rewrite_body_buffer_size) {
      char *new_buf = realloc(session->rewrite_body_buffer, session->rewrite_body_buffer_used + 1);
      if (!new_buf) {
        logger(LOG_ERROR, "HTTP Proxy: Failed to grow rewrite buffer for null");
        return -1;
      }
      session->rewrite_body_buffer = new_buf;
      session->rewrite_body_buffer_size = session->rewrite_body_buffer_used + 1;
    }
    session->rewrite_body_buffer[session->rewrite_body_buffer_used] = '\0';

    /* Build base URL and rewrite context */
    char *base_url = build_proxy_base_url(session->host_header, session->x_forwarded_host, session->x_forwarded_proto);
    if (!base_url) {
      logger(LOG_ERROR, "HTTP Proxy: Failed to build base URL for rewriting");
      return -1;
    }

    rewrite_context_t ctx = {.upstream_host = session->target_host,
                             .upstream_port = session->target_port,
                             .upstream_path = session->target_path,
                             .base_url = base_url};

    int rewrite_result = rewrite_m3u_content(&ctx, session->rewrite_body_buffer, &rewritten, &rewritten_size);
    free(base_url);

    if (rewrite_result < 0) {
      logger(LOG_ERROR, "HTTP Proxy: M3U rewrite failed");
      return -1;
    }
  }

  /* Build and send response headers with new Content-Length
   * Passthrough original headers except Content-Length, Transfer-Encoding, and Trailer */
  char headers[HTTP_PROXY_RESPONSE_BUFFER_SIZE];
  char *hdr_ptr = headers;
  size_t hdr_remaining = sizeof(headers);
  int headers_len = 0;

  if (session->saved_response_headers) {
    /* Rebuild headers in place; the saved copy is not needed after finalization. */
    char *line = strtok(session->saved_response_headers, "\r\n");
    while (line != NULL) {
      /* Skip headers that need to be modified */
      if (strncasecmp(line, "Content-Length:", 15) == 0 || strncasecmp(line, "Transfer-Encoding:", 18) == 0 ||
          strncasecmp(line, "Trailer:", 8) == 0) {
        /* Skip - will add correct Content-Length later */
      } else {
        /* Pass through this header */
        int written = snprintf(hdr_ptr, hdr_remaining, "%s\r\n", line);
        if (written > 0 && (size_t)written < hdr_remaining) {
          hdr_ptr += written;
          hdr_remaining -= written;
          headers_len += written;
        }
      }
      line = strtok(NULL, "\r\n");
    }

    /* Add correct Content-Length */
    int cl_written = snprintf(hdr_ptr, hdr_remaining, "Content-Length: %zu\r\n", rewritten_size);
    if (cl_written > 0 && (size_t)cl_written < hdr_remaining) {
      hdr_ptr += cl_written;
      hdr_remaining -= cl_written;
      headers_len += cl_written;
    }
  } else {
    /* Fallback: build minimal headers */
    headers_len = snprintf(headers, sizeof(headers),
                           "HTTP/1.1 %d OK\r\n"
                           "Content-Type: %s\r\n"
                           "Content-Length: %zu\r\n"
                           "Connection: close\r\n",
                           session->response_status_code, session->response_content_type, rewritten_size);
    hdr_ptr = headers + headers_len;
    hdr_remaining = sizeof(headers) - headers_len;
  }

  /* Inject Set-Cookie header if needed */
  if (session->conn && session->conn->should_set_r2h_cookie && config.r2h_token && config.r2h_token[0] != '\0') {
    int cookie_written = http_build_r2h_token_cookie_header(hdr_ptr, hdr_remaining, http_proxy_get_cookie_path());
    if (cookie_written > 0 && (size_t)cookie_written < hdr_remaining) {
      hdr_ptr += cookie_written;
      hdr_remaining -= cookie_written;
      headers_len += cookie_written;
    } else if (cookie_written < 0) {
      logger(LOG_ERROR, "HTTP Proxy: Failed to build Set-Cookie header for r2h-token");
    }
    session->conn->should_set_r2h_cookie = 0;
  }

  /* Add final CRLF to end headers */
  int final_written = snprintf(hdr_ptr, hdr_remaining, "\r\n");
  if (final_written > 0) {
    headers_len += final_written;
  }

  if (connection_queue_output(session->conn, (const uint8_t *)headers, headers_len) < 0) {
    free(rewritten);
    logger(LOG_ERROR, "HTTP Proxy: Failed to send rewritten headers");
    return -1;
  }

  /* Send rewritten body */
  if (connection_queue_output(session->conn, (const uint8_t *)rewritten, rewritten_size) < 0) {
    free(rewritten);
    logger(LOG_ERROR, "HTTP Proxy: Failed to send rewritten body");
    return -1;
  }

  session->headers_forwarded = 1;
  if (session->conn) {
    session->conn->headers_sent = 1;
  }

  bytes_forwarded = (int)(headers_len + rewritten_size);
  free(rewritten);

  logger(LOG_DEBUG, "HTTP Proxy: Sent rewritten M3U (%zu bytes body)", rewritten_size);

  http_proxy_set_state(session, HTTP_PROXY_STATE_COMPLETE);
  return bytes_forwarded;
}

static int http_proxy_consume_rewrite_body(http_proxy_session_t *session, const uint8_t *data, size_t len) {
  if (session->response_is_chunked) {
    size_t consumed = 0;
    http_chunked_decode_result_t result = http_chunked_decoder_feed(&session->chunked_decoder, data, len,
                                                                    http_proxy_emit_decoded_body, session, &consumed);
    if (result == HTTP_CHUNKED_DECODE_ERROR || consumed != len) {
      logger(LOG_ERROR, "HTTP Proxy: Invalid chunked M3U response body");
      return -1;
    }
    if (result == HTTP_CHUNKED_DECODE_DONE)
      return http_proxy_finalize_rewrite(session);
    return (int)len;
  }

  if (http_proxy_append_rewrite_body(session, data, len) < 0)
    return -1;
  if (session->content_length >= 0 && session->bytes_received >= session->content_length)
    return http_proxy_finalize_rewrite(session);
  return (int)len;
}

static int http_proxy_handle_upstream_end(http_proxy_session_t *session) {
  if (session->needs_body_rewrite) {
    if (session->response_is_chunked &&
        http_chunked_decoder_finish(&session->chunked_decoder) != HTTP_CHUNKED_DECODE_DONE) {
      logger(LOG_ERROR, "HTTP Proxy: Truncated chunked M3U response body");
      return -1;
    }
    return http_proxy_finalize_rewrite(session);
  }

  http_proxy_set_state(session, HTTP_PROXY_STATE_COMPLETE);
  return 0;
}

static int http_proxy_try_receive_response(http_proxy_session_t *session) {
  ssize_t received;
  int bytes_forwarded = 0;

  /*
   * Two-phase receive strategy to avoid an extra payload copy:
   * Phase 1 (AWAITING_HEADERS): Use fixed buffer for header parsing
   * Phase 2 (STREAMING): Receive directly into the send buffer pool
   *                      OR buffer for rewriting if needs_body_rewrite
   */

  if (session->state == HTTP_PROXY_STATE_STREAMING) {
    /* Check if we need to buffer for rewriting */
    if (session->needs_body_rewrite) {
      /* Buffer mode: collect body for rewriting */
      uint8_t temp_buf[8192];
      received = recv(session->socket, temp_buf, sizeof(temp_buf), 0);

      if (received < 0) {
        if (errno == EAGAIN)
          return 0;
        logger(LOG_ERROR, "HTTP Proxy: Recv failed: %s", strerror(errno));
        return http_proxy_handle_upstream_end(session);
      }

      if (received == 0) {
        logger(LOG_DEBUG, "HTTP Proxy: Upstream closed, processing rewrite buffer");
        return http_proxy_handle_upstream_end(session);
      }

      session->bytes_received += received;
      return http_proxy_consume_rewrite_body(session, temp_buf, (size_t)received);
    }

    /* Phase 2: Send queue streaming - recv directly to buffer pool */

    /* Pause upstream BEFORE recv when client queue is near limit.  Dropping
     * bytes mid-stream would corrupt the response body, so we instead push
     * backpressure into the upstream TCP receive buffer. */
    if (connection_should_pause_upstream(session->conn)) {
      http_proxy_pause_upstream(session);
      return 0;
    }

    buffer_ref_t *buf = buffer_pool_alloc();
    if (!buf) {
      logger(LOG_ERROR, "HTTP Proxy: Buffer pool exhausted");
      return -1;
    }

    received = recv(session->socket, buf->data, BUFFER_POOL_BUFFER_SIZE, 0);

    if (received < 0) {
      buffer_ref_put(buf);
      if (errno == EAGAIN) {
        return 0;
      }
      logger(LOG_ERROR, "HTTP Proxy: Recv failed: %s", strerror(errno));
      return http_proxy_handle_upstream_end(session);
    }

    if (received == 0) {
      buffer_ref_put(buf);
      logger(LOG_DEBUG, "HTTP Proxy: Upstream closed connection");
      return http_proxy_handle_upstream_end(session);
    }

    /* Queue for sending */
    buf->data_size = received;
    if (connection_queue_buffer(session->conn, buf) < 0) {
      buffer_ref_put(buf);
      logger(LOG_ERROR, "HTTP Proxy: Failed to queue body data");
      return -1;
    }
    buffer_ref_put(buf);
    bytes_forwarded = (int)received;

    /* Let connection_queue_buffer's internal batching mechanism handle
     * POLLER_OUT - it uses send_queue_should_flush() for optimal batching */
    session->bytes_received += bytes_forwarded;

    /* Check if we've received all content */
    if (session->content_length >= 0 && session->bytes_received >= session->content_length) {
      logger(LOG_DEBUG, "HTTP Proxy: Received all content (%zd bytes)", session->bytes_received);
      http_proxy_set_state(session, HTTP_PROXY_STATE_COMPLETE);
    }

    return bytes_forwarded;
  }

  /* Phase 1: Header parsing - use fixed buffer */
  /* Reserve 1 byte for null terminator used in header parsing */
  size_t available = HTTP_PROXY_RESPONSE_BUFFER_SIZE - 1 - session->response_buffer_pos;
  if (available == 0) {
    logger(LOG_ERROR, "HTTP Proxy: Response buffer full");
    return -1;
  }

  received = recv(session->socket, session->response_buffer + session->response_buffer_pos, available, 0);

  if (received < 0) {
    if (errno == EAGAIN) {
      return 0;
    }
    logger(LOG_ERROR, "HTTP Proxy: Recv failed: %s", strerror(errno));
    return -1;
  }

  if (received == 0) {
    logger(LOG_DEBUG, "HTTP Proxy: Upstream closed connection");
    http_proxy_set_state(session, HTTP_PROXY_STATE_COMPLETE);
    return 0;
  }

  session->response_buffer_pos += received;
  int socket_progress = (int)received;

  /* Try to parse headers */
  if (!session->headers_received) {
    int result = http_proxy_parse_response_headers(session);
    if (result < 0) {
      return -1;
    }
    if (result == 0) {
      return socket_progress; /* Progress: keep draining edge-triggered sockets */
    }
    /* result > 0 means headers complete, state is now STREAMING */
  }

  /* Forward any body data that came with headers (in response_buffer) */
  if (session->headers_received && session->response_buffer_pos > 0) {
    if (session->needs_body_rewrite) {
      /* Buffer or decode initial body data for rewriting */
      size_t initial_size = session->response_buffer_pos;
      session->bytes_received += initial_size;
      session->response_buffer_pos = 0;
      bytes_forwarded = http_proxy_consume_rewrite_body(session, session->response_buffer, initial_size);
      if (bytes_forwarded < 0)
        return -1;
    } else {
      /* Normal mode: forward immediately */
      if (connection_queue_output(session->conn, session->response_buffer, session->response_buffer_pos) < 0) {
        logger(LOG_ERROR, "HTTP Proxy: Failed to queue initial body data");
        return -1;
      }

      bytes_forwarded = (int)session->response_buffer_pos;
      session->response_buffer_pos = 0;
      session->bytes_received += bytes_forwarded;

      /* Check if we've received all content */
      if (session->content_length >= 0 && session->bytes_received >= session->content_length) {
        logger(LOG_DEBUG, "HTTP Proxy: Received all content (%zd bytes)", session->bytes_received);
        http_proxy_set_state(session, HTTP_PROXY_STATE_COMPLETE);
      }
    }
  }

  return bytes_forwarded > 0 ? bytes_forwarded : socket_progress;
}

/* Check if status code is a redirect that may have Location header */
static int http_proxy_is_redirect_status(int status_code) {
  return (status_code == 301 || status_code == 302 || status_code == 303 || status_code == 307 || status_code == 308);
}

/* Queue optional r2h-token Set-Cookie, then the header-block terminator. */
static int http_proxy_queue_cookie_and_end_headers(http_proxy_session_t *session) {
  if (session->conn->should_set_r2h_cookie && config.r2h_token && config.r2h_token[0] != '\0') {
    char set_cookie_header[HTTP_COOKIE_BUFFER_SIZE];
    int cookie_len =
        http_build_r2h_token_cookie_header(set_cookie_header, sizeof(set_cookie_header), http_proxy_get_cookie_path());
    if (cookie_len > 0 && cookie_len < (int)sizeof(set_cookie_header)) {
      if (connection_queue_output(session->conn, (const uint8_t *)set_cookie_header, cookie_len) < 0) {
        logger(LOG_ERROR, "HTTP Proxy: Failed to send Set-Cookie header");
        return -1;
      }
      logger(LOG_DEBUG, "HTTP Proxy: Injected Set-Cookie header for r2h-token");
    } else if (cookie_len < 0) {
      logger(LOG_ERROR, "HTTP Proxy: Failed to build Set-Cookie header for r2h-token");
    }
    session->conn->should_set_r2h_cookie = 0;
  }

  if (connection_queue_output(session->conn, (const uint8_t *)"\r\n", 2) < 0) {
    logger(LOG_ERROR, "HTTP Proxy: Failed to send header terminator");
    return -1;
  }
  return 0;
}

static int http_proxy_parse_response_headers(http_proxy_session_t *session) {
  struct phr_header headers[HTTP_HEADERS_MAX];
  size_t num_headers = HTTP_HEADERS_MAX;
  const char *msg = NULL;
  size_t msg_len = 0;
  int minor_version = -1;
  int status = 0;
  const uint8_t *body_start;
  size_t header_len;
  char location_header[HTTP_PROXY_PATH_SIZE];
  int has_location = 0;
  int pret;

  location_header[0] = '\0';

  pret = phr_parse_response((const char *)session->response_buffer, session->response_buffer_pos, &minor_version,
                            &status, &msg, &msg_len, headers, &num_headers);
  if (pret == -2)
    return 0; /* Need more data */
  if (pret < 0) {
    logger(LOG_ERROR, "HTTP Proxy: Invalid HTTP response");
    return -1;
  }

  header_len = (size_t)pret;
  if (header_len > session->response_buffer_pos) {
    logger(LOG_ERROR, "HTTP Proxy: Invalid HTTP response");
    return -1;
  }
  body_start = session->response_buffer + header_len;
  session->response_status_code = status;
  logger(LOG_DEBUG, "HTTP Proxy: Response status: %d", session->response_status_code);

  {
    long content_length = 0;
    char transfer_encoding[256];

    if (http_headers_get_long(headers, num_headers, "Content-Length", &content_length) == 0) {
      session->content_length = (ssize_t)content_length;
      logger(LOG_DEBUG, "HTTP Proxy: Content-Length: %zd", session->content_length);
    }
    if (http_headers_copy(headers, num_headers, "Content-Type", session->response_content_type,
                          sizeof(session->response_content_type)) == 0) {
      logger(LOG_DEBUG, "HTTP Proxy: Content-Type: %s", session->response_content_type);
    }
    if (http_headers_copy(headers, num_headers, "Transfer-Encoding", transfer_encoding, sizeof(transfer_encoding)) ==
        0) {
      http_proxy_parse_transfer_encoding(session, transfer_encoding);
      logger(LOG_DEBUG, "HTTP Proxy: Transfer-Encoding: %s", transfer_encoding);
    }
    if (http_headers_copy(headers, num_headers, "Location", location_header, sizeof(location_header)) == 0) {
      has_location = 1;
      logger(LOG_DEBUG, "HTTP Proxy: Location: %s", location_header);
    }
  }

  session->headers_received = 1;

  /* Check if a successful response body needs rewriting (M3U content). URL
   * extension takes precedence; fall back to Content-Type only when the URL
   * is not M3U-like. Non-2xx responses must retain normal HTTP semantics,
   * especially redirect Location rewriting and error response passthrough.
   * Skip for HEAD requests — there is no body to rewrite. */
  int is_m3u_response = rewrite_is_m3u_url(session->target_path);
  if (!is_m3u_response)
    is_m3u_response = rewrite_is_m3u_content_type(session->response_content_type);

  if (session->response_status_code >= 200 && session->response_status_code < 300 && is_m3u_response &&
      strcasecmp(session->method, "HEAD") != 0) {
    if (session->transfer_encoding_seen && (!session->response_is_chunked || session->unsupported_transfer_coding)) {
      logger(LOG_ERROR, "HTTP Proxy: Unsupported Transfer-Encoding for M3U rewrite");
      return -1;
    }

    /* Transfer-Encoding takes precedence over Content-Length. */
    if (session->response_is_chunked) {
      session->needs_body_rewrite = 1;
      http_chunked_decoder_init(&session->chunked_decoder);
      logger(LOG_DEBUG, "HTTP Proxy: Chunked M3U content detected, will decode and rewrite body");
    } else if (session->content_length > 0 && (size_t)session->content_length <= REWRITE_MAX_BODY_SIZE) {
      session->needs_body_rewrite = 1;
      logger(LOG_DEBUG, "HTTP Proxy: M3U content detected, will rewrite body");
    } else if (session->content_length == -1) {
      /* Chunked or unknown length - try to buffer if reasonable */
      session->needs_body_rewrite = 1;
      logger(LOG_DEBUG, "HTTP Proxy: M3U content with unknown length, will buffer");
    } else {
      logger(LOG_WARN, "HTTP Proxy: M3U content too large for rewriting (%zd bytes)", session->content_length);
    }

    /* Save original response headers for passthrough during rewrite */
    if (session->needs_body_rewrite) {
      session->saved_response_headers = malloc(header_len + 1);
      if (session->saved_response_headers) {
        memcpy(session->saved_response_headers, session->response_buffer, header_len);
        session->saved_response_headers[header_len] = '\0';
        logger(LOG_DEBUG, "HTTP Proxy: Saved %zu bytes of response headers for rewrite", header_len);
      }
    }
  }

  /* Forward response headers to client - flush immediately */
  /* Skip header forwarding if body needs rewriting (Content-Length may change) */
  if (!session->headers_forwarded && session->conn && !session->needs_body_rewrite) {
    /*
     * For redirect responses (30x), we need to rewrite the Location header
     * to point back through the proxy. We rebuild headers line by line.
     *
     * For non-redirect responses, we need to inject Set-Cookie header if
     * should_set_r2h_cookie is set.
     */
    int is_redirect = http_proxy_is_redirect_status(session->response_status_code);
    char rewritten_location[HTTP_PROXY_PATH_SIZE];
    int location_rewritten = 0;

    /* Rewrite Location header for redirects */
    if (is_redirect && has_location) {
      /*
       * Root-relative Locations (e.g. /rtsp/host:port/path) already target this
       * rtp2httpd instance and must be forwarded unchanged. Absolute URLs in the
       * same schemes M3U transform accepts (http/rtsp/rtp/udp) are rewritten
       * onto the matching proxy prefix.
       */
      if (location_header[0] == '/') {
        logger(LOG_DEBUG, "HTTP Proxy: Keeping relative Location unchanged: %s", location_header);
      } else {
        char app_base_path[HTTP_URL_BUFFER_SIZE];
        if (http_proxy_get_app_base_path(app_base_path, sizeof(app_base_path)) == 0 &&
            http_proxy_build_url(location_header, app_base_path, rewritten_location, sizeof(rewritten_location)) == 0) {
          location_rewritten = 1;
          logger(LOG_DEBUG, "HTTP Proxy: Rewritten Location: %s -> %s", location_header, rewritten_location);
        }
      }
    }

    if (location_rewritten) {
      /*
       * Rebuild headers with modified Location from the structured parse.
       */
      char rebuilt_headers[HTTP_PROXY_RESPONSE_BUFFER_SIZE];
      char *rebuild_ptr = rebuilt_headers;
      size_t rebuild_remaining = sizeof(rebuilt_headers);
      int written;

      if (msg_len > 0)
        written =
            snprintf(rebuild_ptr, rebuild_remaining, "HTTP/1.%d %d %.*s\r\n", minor_version, status, (int)msg_len, msg);
      else
        written = snprintf(rebuild_ptr, rebuild_remaining, "HTTP/1.%d %d\r\n", minor_version, status);
      if (written < 0 || (size_t)written >= rebuild_remaining) {
        logger(LOG_ERROR, "HTTP Proxy: Rebuilt headers too large");
        return -1;
      }
      rebuild_ptr += written;
      rebuild_remaining -= (size_t)written;

      for (size_t i = 0; i < num_headers; i++) {
        const struct phr_header *header = &headers[i];
        if (!header->name)
          continue;
        if (http_header_name_is(header, "Location"))
          written = snprintf(rebuild_ptr, rebuild_remaining, "Location: %s\r\n", rewritten_location);
        else
          written = snprintf(rebuild_ptr, rebuild_remaining, "%.*s: %.*s\r\n", (int)header->name_len, header->name,
                             (int)header->value_len, header->value);
        if (written < 0 || (size_t)written >= rebuild_remaining) {
          logger(LOG_ERROR, "HTTP Proxy: Rebuilt headers too large");
          return -1;
        }
        rebuild_ptr += written;
        rebuild_remaining -= (size_t)written;
      }

      /* Send rebuilt headers */
      size_t rebuilt_len = rebuild_ptr - rebuilt_headers;
      if (connection_queue_output(session->conn, (const uint8_t *)rebuilt_headers, rebuilt_len) < 0) {
        logger(LOG_ERROR, "HTTP Proxy: Failed to forward rebuilt headers");
        return -1;
      }

      if (http_proxy_queue_cookie_and_end_headers(session) < 0)
        return -1;
    } else {
      /* No Location rewriting needed - use original logic */
      size_t headers_without_crlf =
          http_headers_without_final_blank_line((const char *)session->response_buffer, header_len);

      /* Send headers up to (but not including) final \r\n\r\n */
      if (connection_queue_output(session->conn, session->response_buffer, headers_without_crlf) < 0) {
        logger(LOG_ERROR, "HTTP Proxy: Failed to forward headers to client");
        return -1;
      }

      if (http_proxy_queue_cookie_and_end_headers(session) < 0)
        return -1;
    }

    session->headers_forwarded = 1;
    session->conn->headers_sent = 1; /* Mark headers as sent */
    logger(LOG_DEBUG, "HTTP Proxy: Forwarded %zu bytes of headers to client", header_len);

    /* Flush headers immediately - don't use queue_output_and_flush which sets
     * CONN_CLOSING */
    connection_schedule_write(session->conn);
  }

  /* HEAD responses have no body — go straight to COMPLETE */
  if (strcasecmp(session->method, "HEAD") == 0) {
    session->response_buffer_pos = 0;
    http_proxy_set_state(session, HTTP_PROXY_STATE_COMPLETE);
  } else {
    /* Move body data to beginning of buffer */
    size_t body_len = session->response_buffer_pos - header_len;
    if (body_len > 0) {
      memmove(session->response_buffer, body_start, body_len);
    }
    session->response_buffer_pos = body_len;

    http_proxy_set_state(session, HTTP_PROXY_STATE_STREAMING);
  }

  return 1; /* Headers complete */
}

int http_proxy_handle_socket_event(http_proxy_session_t *session, uint32_t events) {
  int result;

  if (!session || session->socket < 0) {
    return -1;
  }

  /* Handle in-progress connect FIRST - before generic error/HUP handling.
   * A failed candidate (POLLER_ERR/HUP or SO_ERROR) falls back to the next
   * address from the getaddrinfo list instead of erroring out. */
  if (session->state == HTTP_PROXY_STATE_CONNECTING) {
    int sock_error = 0;
    socklen_t error_len = sizeof(sock_error);

    if (getsockopt(session->socket, SOL_SOCKET, SO_ERROR, &sock_error, &error_len) < 0) {
      logger(LOG_ERROR, "HTTP Proxy: getsockopt(SO_ERROR) failed: %s", strerror(errno));
      http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
      return -1;
    }

    if (sock_error == 0 && (events & (POLLER_ERR | POLLER_HUP)) && !(events & POLLER_OUT)) {
      /* Error/hangup event without a definite SO_ERROR - treat as failure */
      sock_error = ECONNREFUSED;
    }

    if (sock_error != 0) {
      if (http_proxy_handle_connect_failure(session, sock_error) < 0) {
        http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
        return -1;
      }
      return 0; /* Next candidate attempt in progress */
    }

    /* Connection succeeded */
    logger(LOG_INFO, "HTTP Proxy: Connected to %s:%d", session->target_host, session->target_port);

    if (http_proxy_on_connected(session) < 0) {
      return -1;
    }
  }

  /* Handle writable socket - send pending request */
  if ((events & POLLER_OUT) && session->state == HTTP_PROXY_STATE_SENDING_REQUEST) {
    result = http_proxy_try_send_pending(session);
    if (result < 0) {
      logger(LOG_ERROR, "HTTP Proxy: Failed to send request");
      http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
      return -1;
    }

    /* Check if send completed (headers + body) */
    if (session->pending_request_sent >= session->pending_request_len &&
        session->request_body_sent >= session->request_body_len) {
      logger(LOG_DEBUG, "HTTP Proxy: Request sent (%zu headers + %zu body bytes)", session->pending_request_len,
             session->request_body_len);
      http_proxy_set_state(session, HTTP_PROXY_STATE_AWAITING_HEADERS);

      /* Update poller to only monitor POLLER_IN */
      if (session->epoll_fd >= 0) {
        if (poller_mod(session->epoll_fd, session->socket, POLLER_IN | POLLER_HUP | POLLER_ERR | POLLER_RDHUP) < 0) {
          logger(LOG_ERROR, "HTTP Proxy: Failed to modify poller events: %s", strerror(errno));
          http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
          return -1;
        }
      }
    }
  }

  /* Handle readable socket - receive response.
   * Loop until EAGAIN to drain all available data.  This is required for
   * edge-triggered pollers (epoll EPOLLET / kqueue EV_CLEAR) where the read event fires
   * only once per data arrival and won't re-trigger while unread data
   * remains in the socket buffer. */
  int progress = 0;
  if (events & POLLER_IN) {
    while (session->state == HTTP_PROXY_STATE_AWAITING_HEADERS || session->state == HTTP_PROXY_STATE_STREAMING) {
      result = http_proxy_try_receive_response(session);
      if (result < 0) {
        logger(LOG_ERROR, "HTTP Proxy: Failed to receive response");
        http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
        return -1;
      }
      if (result == 0)
        break; /* EAGAIN or need more data - wait for next event */
      progress += result;
    }
  }

  /* Check hard socket errors AFTER draining readable data.  Linux may report
   * EPOLLIN together with EPOLLERR when a peer sends the final response bytes
   * and then resets the connection.  The response is still valid if those
   * bytes complete its framing, particularly the terminating chunk. */
  if ((events & POLLER_ERR) && session->state != HTTP_PROXY_STATE_COMPLETE) {
    int sock_error = 0;
    int has_socket_error = 0;
    socklen_t error_len = sizeof(sock_error);
    if (getsockopt(session->socket, SOL_SOCKET, SO_ERROR, &sock_error, &error_len) == 0 && sock_error != 0) {
      logger(LOG_ERROR, "HTTP Proxy: Socket error: %s", strerror(sock_error));
      has_socket_error = 1;
    } else if (session->state != HTTP_PROXY_STATE_SENDING_REQUEST) {
      logger(LOG_ERROR, "HTTP Proxy: Socket error event received");
      has_socket_error = 1;
    }

    if (has_socket_error) {
      if (session->state == HTTP_PROXY_STATE_STREAMING) {
        result = http_proxy_handle_upstream_end(session);
        if (result < 0) {
          http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
          return -1;
        }
        progress += result;
      } else {
        http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
        return -1;
      }
    }
  }

  /* Check for connection hangup AFTER processing data.
   * Only when POLLER_IN was NOT set — if POLLER_IN was set, recv already
   * handled EOF (returning 0) and set COMPLETE as needed.  Processing
   * POLLER_HUP together with POLLER_IN would prematurely set COMPLETE
   * before buffered data (e.g. rewrite body) is processed. */
  if ((events & (POLLER_HUP | POLLER_RDHUP)) && !(events & POLLER_IN)) {
    /* Upstream closed connection */
    if (session->state == HTTP_PROXY_STATE_STREAMING || session->state == HTTP_PROXY_STATE_AWAITING_HEADERS) {
      logger(LOG_DEBUG, "HTTP Proxy: Upstream closed connection (normal)");
      if (session->state == HTTP_PROXY_STATE_STREAMING) {
        result = http_proxy_handle_upstream_end(session);
        if (result < 0) {
          http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
          return -1;
        }
        progress += result;
      } else {
        http_proxy_set_state(session, HTTP_PROXY_STATE_COMPLETE);
      }
    } else if (session->state != HTTP_PROXY_STATE_COMPLETE) {
      /* For other states (like SENDING_REQUEST), this is unexpected */
      logger(LOG_INFO,
             "HTTP Proxy: Upstream closed connection unexpectedly in "
             "state %d",
             session->state);
      http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
      return -1;
    }
  }

  /* When transfer is complete, clean up proxy socket and begin draining
   * the client connection's output queue. */
  if (session->state == HTTP_PROXY_STATE_COMPLETE) {
    if (session->socket >= 0) {
      worker_cleanup_socket_from_epoll(session->epoll_fd, session->socket);
      session->socket = -1;
    }
    if (session->conn && session->conn->state != CONN_CLOSING) {
      logger(LOG_DEBUG, "HTTP Proxy: Transfer complete");
      session->conn->state = CONN_CLOSING;
      connection_schedule_write(session->conn);
    }
  }

  return progress;
}

int http_proxy_session_cleanup(http_proxy_session_t *session) {
  if (!session || !session->initialized) {
    return 0;
  }

  if (session->cleanup_done) {
    return 0;
  }

  logger(LOG_DEBUG, "HTTP Proxy: Cleaning up session (socket=%d)", session->socket);

  /* Close socket */
  if (session->socket >= 0) {
    worker_cleanup_socket_from_epoll(session->epoll_fd, session->socket);
    session->socket = -1;
  }

  /* Free pending connect candidates if any */
  http_proxy_free_connect_results(session);

  /* Free rewrite body buffer if allocated */
  if (session->rewrite_body_buffer) {
    free(session->rewrite_body_buffer);
    session->rewrite_body_buffer = NULL;
    session->rewrite_body_buffer_size = 0;
    session->rewrite_body_buffer_used = 0;
  }

  /* Free saved response headers if allocated */
  if (session->saved_response_headers) {
    free(session->saved_response_headers);
    session->saved_response_headers = NULL;
  }

  session->cleanup_done = 1;
  session->initialized = 0;
  session->state = HTTP_PROXY_STATE_CLOSING;

  return 0;
}

int http_proxy_session_tick(http_proxy_session_t *session, int64_t now) {
  if (!session || !session->initialized || session->last_state_change_ms <= 0)
    return 0;
  switch (session->state) {
  case HTTP_PROXY_STATE_CONNECTING:
  case HTTP_PROXY_STATE_SENDING_REQUEST:
  case HTTP_PROXY_STATE_AWAITING_HEADERS:
    break;
  default:
    return 0;
  }
  int64_t elapsed = now - session->last_state_change_ms;
  if (elapsed >= HTTP_PROXY_TIMEOUT_SEC * 1000) {
    /* Connect timeout: fall back to the next address candidate if any */
    if (session->state == HTTP_PROXY_STATE_CONNECTING && session->connect_next) {
      logger(LOG_INFO, "HTTP Proxy: Connect to %s:%d timed out, trying next address", session->target_host,
             session->target_port);
      if (http_proxy_handle_connect_failure(session, ETIMEDOUT) == 0) {
        return 0;
      }
    }
    logger(LOG_ERROR, "HTTP Proxy: State %d timed out after %lld ms", session->state, (long long)elapsed);
    http_proxy_set_state(session, HTTP_PROXY_STATE_ERROR);
    return -1;
  }
  return 0;
}

/*
 * Match an absolute URL against the schemes M3U transform accepts
 * (http, rtsp, rtp, udp). See is_url_recognizable() in m3u.c.
 */
static int http_proxy_match_m3u_scheme(const char *url, const char **host_start, const char **scheme_prefix) {
  static const struct {
    const char *scheme;
    size_t len;
    const char *prefix;
  } table[] = {
      {"http://", 7, "http/"},
      {"rtsp://", 7, "rtsp/"},
      {"rtp://", 6, "rtp/"},
      {"udp://", 6, "udp/"},
  };
  size_t i;

  if (!url || !host_start || !scheme_prefix)
    return -1;

  for (i = 0; i < ARRAY_SIZE(table); i++) {
    if (strncasecmp(url, table[i].scheme, table[i].len) == 0) {
      *host_start = url + table[i].len;
      *scheme_prefix = table[i].prefix;
      return 0;
    }
  }
  return -1;
}

int http_proxy_build_url(const char *http_url, const char *base_url_placeholder, char *output, size_t output_size) {
  const char *host_start;
  const char *scheme_prefix;
  char *encoded_token = NULL;
  int result;
  int has_r2h_token = (config.r2h_token && config.r2h_token[0] != '\0');

  if (!http_url || !base_url_placeholder || !output || output_size == 0)
    return -1;

  /* Convert scheme://host/... -> {BASE_URL}scheme/host/... */
  if (http_proxy_match_m3u_scheme(http_url, &host_start, &scheme_prefix) != 0)
    return -1;

  /* URL encode r2h-token if configured */
  if (has_r2h_token) {
    encoded_token = http_url_encode(config.r2h_token);
    if (!encoded_token) {
      logger(LOG_ERROR, "Failed to URL encode r2h-token");
      return -1;
    }
  }

  /* Check if original URL has query parameters */
  const char *query_start = strchr(host_start, '?');

  if (has_r2h_token && encoded_token) {
    if (query_start) {
      /* Original URL has query params, append r2h-token with & */
      result = snprintf(output, output_size, "%s%s%s&r2h-token=%s", base_url_placeholder, scheme_prefix, host_start,
                        encoded_token);
    } else {
      /* No query params, add r2h-token with ? */
      result = snprintf(output, output_size, "%s%s%s?r2h-token=%s", base_url_placeholder, scheme_prefix, host_start,
                        encoded_token);
    }
  } else {
    result = snprintf(output, output_size, "%s%s%s", base_url_placeholder, scheme_prefix, host_start);
  }

  if (encoded_token)
    free(encoded_token);

  if (result >= (int)output_size) {
    logger(LOG_ERROR, "HTTP proxy URL too long");
    return -1;
  }

  return 0;
}
