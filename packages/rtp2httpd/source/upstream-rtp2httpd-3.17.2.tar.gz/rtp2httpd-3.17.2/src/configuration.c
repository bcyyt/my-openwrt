#include "configuration.h"
#include "epg.h"
#include "http.h"
#include "m3u.h"
#include "service.h"
#include "utils.h"
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <libgen.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define MAX_LINE 4096

/* GLOBAL */
config_t config;
bindaddr_t *bind_addresses = NULL;

/* Config file path for reload */
static char *config_file_path = NULL;

int cmd_verbosity_set = 0;
int cmd_udpxy_set = 0;
int cmd_maxclients_set = 0;
int cmd_bind_set = 0;
int cmd_hostname_set = 0;
int cmd_xff_set = 0;
int cmd_r2h_token_set = 0;
int cmd_buffer_pool_max_size_set = 0;
int cmd_udp_rcvbuf_size_set = 0;
int cmd_mcast_rejoin_interval_set = 0;
int cmd_ffmpeg_path_set = 0;
int cmd_ffmpeg_args_set = 0;
int cmd_video_snapshot_set = 0;
int cmd_upstream_interface_set = 0;
int cmd_upstream_interface_fcc_set = 0;
int cmd_upstream_interface_rtsp_set = 0;
int cmd_upstream_interface_multicast_set = 0;
int cmd_upstream_interface_http_set = 0;
int cmd_fcc_listen_port_range_set = 0;
int cmd_status_page_path_set = 0;
int cmd_player_page_path_set = 0;
int cmd_app_path_prefix_set = 0;
int cmd_use_relative_path_in_m3u_set = 0;
int cmd_workers_set = 0;
int cmd_external_m3u_url_set = 0;
int cmd_external_m3u_update_interval_set = 0;
int cmd_rtsp_stun_server_set = 0;
int cmd_http_proxy_user_agent_set = 0;
int cmd_rtsp_user_agent_set = 0;
int cmd_cors_allow_origin_set = 0;
int cmd_access_log_set = 0;
int cmd_log_format_set = 0;
int cmd_pid_file_set = 0;

enum section_e { SEC_NONE = 0, SEC_BIND, SEC_SERVICES, SEC_GLOBAL };

enum long_option_e {
  OPT_APP_PATH_PREFIX = 1000,
  OPT_USE_RELATIVE_PATH_IN_M3U,
  OPT_ACCESS_LOG,
  OPT_LOG_FORMAT,
  OPT_PID_FILE
};

/* M3U parsing state variables */
static char *inline_m3u_buffer = NULL;
static size_t inline_m3u_buffer_size = 0;
static size_t inline_m3u_buffer_used = 0;

/* Helper functions for parsing */

/* Skip whitespace and extract next token */
static char *extract_token(char *line, int *pos) {
  int i = *pos;
  int j = i;

  while (isspace(line[i]))
    i++;
  j = i;
  while (line[j] != '\0' && !isspace(line[j]))
    j++;

  *pos = j;
  return strndup(line + i, j - i);
}

/* Parse boolean value from string */
static int parse_bool(const char *value) {
  return (strcasecmp("on", value) == 0) || (strcasecmp("true", value) == 0) || (strcasecmp("yes", value) == 0) ||
         (strcasecmp("1", value) == 0);
}

/* Set config value if not already set by command line */
static int set_if_not_cmd_override(int cmd_flag, const char *param_name) {
  if (cmd_flag) {
    logger(LOG_WARN, "Config file value \"%s\" ignored (already set on command line)", param_name);
    return 0;
  }
  return 1;
}

/* Free a string pointer if not NULL */
static void safe_free_string(char **str) {
  if (*str != NULL) {
    free(*str);
    *str = NULL;
  }
}

static void free_config_strings(config_t *target, bool force_free) {
  if (!cmd_hostname_set || force_free)
    safe_free_string(&target->hostname);
  if (!cmd_r2h_token_set || force_free)
    safe_free_string(&target->r2h_token);
  if (!cmd_ffmpeg_path_set || force_free)
    safe_free_string(&target->ffmpeg_path);
  if (!cmd_ffmpeg_args_set || force_free)
    safe_free_string(&target->ffmpeg_args);
  if (!cmd_status_page_path_set || force_free) {
    safe_free_string(&target->status_page_path);
    safe_free_string(&target->status_page_route);
  }
  if (!cmd_player_page_path_set || force_free) {
    safe_free_string(&target->player_page_path);
    safe_free_string(&target->player_page_route);
  }
  if (!cmd_app_path_prefix_set || force_free) {
    safe_free_string(&target->app_path_prefix);
    safe_free_string(&target->app_path_route);
  }
  if (!cmd_external_m3u_url_set || force_free)
    safe_free_string(&target->external_m3u_url);
  if (!cmd_rtsp_stun_server_set || force_free)
    safe_free_string(&target->rtsp_stun_server);
  if (!cmd_http_proxy_user_agent_set || force_free)
    safe_free_string(&target->http_proxy_user_agent);
  if (!cmd_rtsp_user_agent_set || force_free)
    safe_free_string(&target->rtsp_user_agent);
  if (!cmd_cors_allow_origin_set || force_free)
    safe_free_string(&target->cors_allow_origin);
  if (!cmd_access_log_set || force_free)
    safe_free_string(&target->access_log);
  if (!cmd_log_format_set || force_free)
    safe_free_string(&target->log_format);
  if (!cmd_pid_file_set || force_free)
    safe_free_string(&target->pid_file);
}

static int snapshot_string(char **dst, char *src, int keep_shallow) {
  if (keep_shallow) {
    *dst = src;
    return 0;
  }

  if (!src) {
    *dst = NULL;
    return 0;
  }

  *dst = strdup(src);
  return *dst ? 0 : -1;
}

static int bind_path_is_valid(const char *path) {
  if (!path || path[0] != '/')
    return 0;
  return strpbrk(path, " \t\r\n") == NULL;
}

static void add_bindaddr_tcp(char *node, char *service) {
  bindaddr_t *ba = malloc(sizeof(bindaddr_t));
  if (!ba) {
    logger(LOG_ERROR, "Failed to allocate bind address");
    free(node);
    free(service);
    return;
  }
  memset(ba, 0, sizeof(*ba));
  ba->type = BIND_ADDR_TCP;
  ba->node = node;
  ba->service = service;
  ba->next = bind_addresses;
  bind_addresses = ba;
}

static void add_bindaddr_unix(char *path) {
  bindaddr_t *ba = malloc(sizeof(bindaddr_t));
  if (!ba) {
    logger(LOG_ERROR, "Failed to allocate Unix socket bind address");
    free(path);
    return;
  }
  memset(ba, 0, sizeof(*ba));
  ba->type = BIND_ADDR_UNIX;
  ba->path = path;
  ba->next = bind_addresses;
  bind_addresses = ba;
}

static int parse_port_range_value(const char *value, int *min_port, int *max_port) {
  char *endptr = NULL;
  long start = 0;
  long end = 0;

  if (!value || !min_port || !max_port)
    return -1;

  errno = 0;
  start = strtol(value, &endptr, 10);
  if (endptr == value)
    return -1;

  while (*endptr && isspace((unsigned char)*endptr))
    endptr++;

  if (*endptr == '\0') {
    end = start;
  } else if (*endptr == '-') {
    const char *end_str = endptr + 1;
    while (*end_str && isspace((unsigned char)*end_str))
      end_str++;
    if (*end_str == '\0') {
      return -1;
    }
    errno = 0;
    end = strtol(end_str, &endptr, 10);
    if (endptr == end_str || *endptr != '\0')
      return -1;
  } else {
    return -1;
  }

  if (errno != 0 || start < 1 || start > 65535 || end < 1 || end > 65535)
    return -1;

  if (end < start)
    return -1;

  *min_port = (int)start;
  *max_port = (int)end;
  return 0;
}

/* Generic function to set page path and route */
static void set_page_path_value(const char *value, const char *page_name, char **path_ptr, char **route_ptr) {
  char normalized[HTTP_URL_BUFFER_SIZE];
  size_t len = 0;
  const char *src;

  if (!value || value[0] == '\0') {
    logger(LOG_ERROR, "%s-page-path cannot be empty, keeping previous value", page_name);
    return;
  }

  src = value;
  while (*src == '/')
    src++;

  normalized[len++] = '/';

  while (*src && len < sizeof(normalized) - 1)
    normalized[len++] = *src++;

  if (*src != '\0') {
    logger(LOG_ERROR, "%s-page-path is too long, keeping previous value", page_name);
    return;
  }

  while (len > 1 && normalized[len - 1] == '/')
    len--;

  normalized[len] = '\0';

  safe_free_string(path_ptr);
  safe_free_string(route_ptr);

  *path_ptr = strdup(normalized);
  if (!*path_ptr) {
    logger(LOG_ERROR, "Failed to allocate %s-page-path", page_name);
    *route_ptr = NULL;
    return;
  }

  if (normalized[1] != '\0')
    *route_ptr = strdup(normalized + 1);
  else
    *route_ptr = strdup("");

  if (!*route_ptr) {
    logger(LOG_ERROR, "Failed to allocate %s-page-path route", page_name);
    safe_free_string(path_ptr);
  }
}

static void set_status_page_path_value(const char *value) {
  set_page_path_value(value, "status", &config.status_page_path, &config.status_page_route);
}

static void set_player_page_path_value(const char *value) {
  set_page_path_value(value, "player", &config.player_page_path, &config.player_page_route);
}

static void set_app_path_prefix_value(const char *value) {
  char normalized[HTTP_URL_BUFFER_SIZE];
  size_t len = 0;
  const char *src;

  normalized[0] = '\0';

  if (!value)
    value = "";

  src = value;
  while (*src == '/')
    src++;

  if (*src != '\0') {
    normalized[len++] = '/';

    while (*src && len < sizeof(normalized) - 1)
      normalized[len++] = *src++;

    if (*src != '\0') {
      logger(LOG_ERROR, "app-path-prefix is too long, keeping previous value");
      return;
    }

    while (len > 0 && normalized[len - 1] == '/')
      len--;
  }

  normalized[len] = '\0';

  safe_free_string(&config.app_path_prefix);
  safe_free_string(&config.app_path_route);

  config.app_path_prefix = strdup(normalized);
  if (!config.app_path_prefix) {
    logger(LOG_ERROR, "Failed to allocate app-path-prefix");
    config.app_path_route = NULL;
    return;
  }

  if (normalized[0] != '\0')
    config.app_path_route = strdup(normalized + 1);
  else
    config.app_path_route = strdup("");

  if (!config.app_path_route) {
    logger(LOG_ERROR, "Failed to allocate app-path-prefix route");
    safe_free_string(&config.app_path_prefix);
  }
}

void parse_bind_sec(char *line) {
  int pos = 0;
  char *node, *service;

  node = extract_token(line, &pos);
  service = extract_token(line, &pos);

  if (!node || node[0] == '\0') {
    logger(LOG_ERROR, "Invalid empty bind address line");
    free(node);
    free(service);
    return;
  }

  if (node[0] == '/') {
    if (service && service[0] != '\0') {
      logger(LOG_ERROR, "Invalid Unix socket bind path (whitespace is not supported): %s", node);
      free(node);
      free(service);
      return;
    }
    if (!bind_path_is_valid(node)) {
      logger(LOG_ERROR, "Invalid Unix socket bind path: %s", node);
      free(node);
      free(service);
      return;
    }
    logger(LOG_DEBUG, "unix socket path: %s", node);
    add_bindaddr_unix(node);
    free(service);
    return;
  }

  if (!service || service[0] == '\0') {
    logger(LOG_ERROR, "Invalid TCP bind address line: missing port for %s", node);
    free(node);
    free(service);
    return;
  }

  if (strcmp("*", node) == 0) {
    free(node);
    node = NULL;
  } else if (node && node[0] == '[') {
    /* Strip brackets from "[IPv6]" notation for getaddrinfo */
    char *closing = strchr(node, ']');
    if (closing) {
      *closing = '\0';
      memmove(node, node + 1, strlen(node + 1) + 1);
    }
  }
  logger(LOG_DEBUG, "node: %s, port: %s", node, service);

  add_bindaddr_tcp(node, service);
}

void parse_services_sec(char *line) {
  int i;

  /* Check if this line is the start of M3U content (#EXTM3U header) */
  if (m3u_is_header(line)) {
    /* Allocate initial buffer for inline M3U */
    if (!inline_m3u_buffer) {
      inline_m3u_buffer_size = 8192;
      inline_m3u_buffer = malloc(inline_m3u_buffer_size);
      if (!inline_m3u_buffer) {
        logger(LOG_ERROR, "Failed to allocate M3U buffer");
        return;
      }
      inline_m3u_buffer_used = 0;
    }

    /* Add this line to buffer */
    size_t line_len = strlen(line);
    while (inline_m3u_buffer_used + line_len + 2 > inline_m3u_buffer_size) {
      /* Grow buffer */
      size_t new_size = inline_m3u_buffer_size * 2;
      char *new_buf = realloc(inline_m3u_buffer, new_size);
      if (!new_buf) {
        logger(LOG_ERROR, "Failed to grow M3U buffer");
        return;
      }
      inline_m3u_buffer = new_buf;
      inline_m3u_buffer_size = new_size;
    }
    memcpy(inline_m3u_buffer + inline_m3u_buffer_used, line, line_len);
    inline_m3u_buffer_used += line_len;
    inline_m3u_buffer[inline_m3u_buffer_used++] = '\n';
    inline_m3u_buffer[inline_m3u_buffer_used] = '\0';
    return;
  }

  /* If we're currently buffering M3U content, continue buffering */
  if (inline_m3u_buffer && inline_m3u_buffer_used > 0) {
    /* Check if this is a comment line (M3U metadata) or URL line */
    if (line[0] == '#' || strncmp(line, "rtp://", 6) == 0 || strncmp(line, "rtsp://", 7) == 0 ||
        strncmp(line, "udp://", 6) == 0 || strncmp(line, "http://", 7) == 0 || strncmp(line, "https://", 8) == 0) {
      /* Continue buffering */
      size_t line_len = strlen(line);
      while (inline_m3u_buffer_used + line_len + 2 > inline_m3u_buffer_size) {
        /* Grow buffer */
        size_t new_size = inline_m3u_buffer_size * 2;
        char *new_buf = realloc(inline_m3u_buffer, new_size);
        if (!new_buf) {
          logger(LOG_ERROR, "Failed to grow M3U buffer");
          return;
        }
        inline_m3u_buffer = new_buf;
        inline_m3u_buffer_size = new_size;
      }
      memcpy(inline_m3u_buffer + inline_m3u_buffer_used, line, line_len);
      inline_m3u_buffer_used += line_len;
      inline_m3u_buffer[inline_m3u_buffer_used++] = '\n';
      inline_m3u_buffer[inline_m3u_buffer_used] = '\0';
      return;
    } else {
      /* This line doesn't look like M3U content, stop buffering and process
       * what we have */
      /* This will fall through to parameter parsing below */
    }
  }

  /* If we reach here with non-empty line, log it for debugging */
  /* Note: external-m3u and external-m3u-update-interval are now in [global]
   * section */
  /* Trim whitespace to check if line is empty */
  i = 0;
  while (isspace(line[i]))
    i++;

  if (line[i] != '\0' && line[i] != '\n' && line[i] != '\r') {
    logger(LOG_DEBUG, "Ignoring unparsable line in [services]: '%s'", line);
  }
}

void parse_global_sec(char *line) {
  int i, j;
  char *param, *value;
  char *ind;

  /* Find the '=' sign first */
  ind = index(line, '=');
  if (ind == NULL) {
    logger(LOG_ERROR, "Unrecognised config line: %s", line);
    return;
  }

  /* Extract parameter name (from start to '=', trimming trailing whitespace) */
  j = ind - line;
  while (j > 0 && isspace(line[j - 1]))
    j--;
  param = strndupa(line, j);

  /* Extract value (from '=' to end, trimming leading and trailing whitespace)
   */
  i = ind - line + 1;
  while (isspace(line[i]))
    i++;
  j = i;
  /* Find end of line (excluding trailing whitespace and newline) */
  while (line[j] != '\0' && line[j] != '\n' && line[j] != '\r')
    j++;
  /* Trim trailing whitespace */
  while (j > i && isspace(line[j - 1]))
    j--;
  value = strndupa(line + i, j - i);

  /* Integer parameters with command line override */
  if (strcasecmp("verbosity", param) == 0) {
    if (set_if_not_cmd_override(cmd_verbosity_set, "verbosity"))
      config.verbosity = atoi(value);
    return;
  }

  if (strcasecmp("maxclients", param) == 0) {
    if (set_if_not_cmd_override(cmd_maxclients_set, "maxclients")) {
      int max_clients = atoi(value);
      if (max_clients < 1 || max_clients > CONFIG_MAX_CLIENTS) {
        logger(LOG_ERROR, "Invalid maxclients! Must be between 1 and %d. Ignoring.", CONFIG_MAX_CLIENTS);
        return;
      }
      config.maxclients = max_clients;
    }
    return;
  }

  if (strcasecmp("workers", param) == 0) {
    int n = atoi(value);
    if (n < 1 || n > CONFIG_MAX_WORKERS) {
      logger(LOG_ERROR, "Invalid workers value! Must be between 1 and %d. Ignoring.", CONFIG_MAX_WORKERS);
      return;
    }
    config.workers = n;
    return;
  }

  if (strcasecmp("fcc-listen-port-range", param) == 0) {
    if (set_if_not_cmd_override(cmd_fcc_listen_port_range_set, "fcc-listen-port-range")) {
      int min_port = 0, max_port = 0;
      if (parse_port_range_value(value, &min_port, &max_port) == 0) {
        config.fcc_listen_port_min = min_port;
        config.fcc_listen_port_max = max_port;
        logger(LOG_INFO, "FCC listen port range set to %d-%d", min_port, max_port);
      } else {
        logger(LOG_ERROR, "Invalid fcc-listen-port-range value: %s", value);
      }
    }
    return;
  }

  if (strcasecmp("buffer-pool-max-size", param) == 0) {
    if (set_if_not_cmd_override(cmd_buffer_pool_max_size_set, "buffer-pool-max-size")) {
      int val = atoi(value);
      if (val < 1) {
        logger(LOG_ERROR, "Invalid buffer-pool-max-size! Must be >= 1. Ignoring.");
      } else {
        config.buffer_pool_max_size = val;
      }
    }
    return;
  }

  if (strcasecmp("udp-rcvbuf-size", param) == 0) {
    if (set_if_not_cmd_override(cmd_udp_rcvbuf_size_set, "udp-rcvbuf-size")) {
      int val = atoi(value);
      if (val < 65536) {
        logger(LOG_ERROR, "Invalid udp-rcvbuf-size! Must be >= 65536 (64KB). Ignoring.");
      } else {
        config.udp_rcvbuf_size = val;
      }
    }
    return;
  }

  /* Boolean parameters with command line override */
  if (strcasecmp("udpxy", param) == 0) {
    if (set_if_not_cmd_override(cmd_udpxy_set, "udpxy"))
      config.udpxy = parse_bool(value);
    return;
  }

  if (strcasecmp("video-snapshot", param) == 0) {
    if (set_if_not_cmd_override(cmd_video_snapshot_set, "video-snapshot"))
      config.video_snapshot = parse_bool(value);
    return;
  }

  if (strcasecmp("use-relative-path-in-m3u", param) == 0) {
    if (set_if_not_cmd_override(cmd_use_relative_path_in_m3u_set, "use-relative-path-in-m3u"))
      config.use_relative_path_in_m3u = parse_bool(value);
    return;
  }

  /* String parameters with command line override */
  if (strcasecmp("hostname", param) == 0) {
    if (set_if_not_cmd_override(cmd_hostname_set, "hostname")) {
      safe_free_string(&config.hostname);
      config.hostname = strdup(value);
    }
    return;
  }

  if (strcasecmp("xff", param) == 0) {
    if (set_if_not_cmd_override(cmd_xff_set, "xff"))
      config.xff = parse_bool(value);
    return;
  }

  if (strcasecmp("status-page-path", param) == 0) {
    if (set_if_not_cmd_override(cmd_status_page_path_set, "status-page-path"))
      set_status_page_path_value(value);
    return;
  }

  if (strcasecmp("player-page-path", param) == 0) {
    if (set_if_not_cmd_override(cmd_player_page_path_set, "player-page-path"))
      set_player_page_path_value(value);
    return;
  }

  if (strcasecmp("app-path-prefix", param) == 0) {
    if (set_if_not_cmd_override(cmd_app_path_prefix_set, "app-path-prefix"))
      set_app_path_prefix_value(value);
    return;
  }

  if (strcasecmp("r2h-token", param) == 0) {
    if (set_if_not_cmd_override(cmd_r2h_token_set, "r2h-token")) {
      safe_free_string(&config.r2h_token);
      config.r2h_token = strdup(value);
    }
    return;
  }

  if (strcasecmp("ffmpeg-path", param) == 0) {
    if (set_if_not_cmd_override(cmd_ffmpeg_path_set, "ffmpeg-path")) {
      safe_free_string(&config.ffmpeg_path);
      config.ffmpeg_path = strdup(value);
    }
    return;
  }

  if (strcasecmp("ffmpeg-args", param) == 0) {
    if (set_if_not_cmd_override(cmd_ffmpeg_args_set, "ffmpeg-args")) {
      safe_free_string(&config.ffmpeg_args);
      config.ffmpeg_args = strdup(value);
    }
    return;
  }

  /* Interface parameters with command line override */
  if (strcasecmp("upstream-interface", param) == 0) {
    if (set_if_not_cmd_override(cmd_upstream_interface_set, "upstream-interface")) {
      strncpy(config.upstream_interface, value, IFNAMSIZ - 1);
    }
    return;
  }

  if (strcasecmp("upstream-interface-fcc", param) == 0) {
    if (set_if_not_cmd_override(cmd_upstream_interface_fcc_set, "upstream-interface-fcc")) {
      strncpy(config.upstream_interface_fcc, value, IFNAMSIZ - 1);
    }
    return;
  }

  if (strcasecmp("upstream-interface-rtsp", param) == 0) {
    if (set_if_not_cmd_override(cmd_upstream_interface_rtsp_set, "upstream-interface-rtsp")) {
      strncpy(config.upstream_interface_rtsp, value, IFNAMSIZ - 1);
    }
    return;
  }

  if (strcasecmp("upstream-interface-multicast", param) == 0) {
    if (set_if_not_cmd_override(cmd_upstream_interface_multicast_set, "upstream-interface-multicast")) {
      strncpy(config.upstream_interface_multicast, value, IFNAMSIZ - 1);
    }
    return;
  }

  if (strcasecmp("upstream-interface-http", param) == 0) {
    if (set_if_not_cmd_override(cmd_upstream_interface_http_set, "upstream-interface-http")) {
      strncpy(config.upstream_interface_http, value, IFNAMSIZ - 1);
    }
    return;
  }

  if (strcasecmp("mcast-rejoin-interval", param) == 0) {
    if (set_if_not_cmd_override(cmd_mcast_rejoin_interval_set, "mcast-rejoin-interval")) {
      int interval = atoi(value);
      if (interval < 0) {
        logger(LOG_ERROR, "Invalid mcast-rejoin-interval value: %s (must be >= 0)", value);
      } else {
        config.mcast_rejoin_interval = interval;
        if (interval > 0) {
          logger(LOG_INFO, "Multicast rejoin interval set to %d seconds", interval);
        }
      }
    }
    return;
  }

  /* External M3U configuration */
  if (strcasecmp("external-m3u", param) == 0) {
    if (config.external_m3u_url)
      free(config.external_m3u_url);
    config.external_m3u_url = strdup(value);
    logger(LOG_INFO, "External M3U URL configured: %s", config.external_m3u_url);
    return;
  }

  if (strcasecmp("external-m3u-update-interval", param) == 0) {
    config.external_m3u_update_interval = atoi(value);
    logger(LOG_INFO, "External M3U update interval: %d seconds", config.external_m3u_update_interval);
    return;
  }

  /* STUN NAT traversal configuration */
  if (strcasecmp("rtsp-stun-server", param) == 0) {
    if (!cmd_rtsp_stun_server_set) {
      safe_free_string(&config.rtsp_stun_server);
      if (value[0] != '\0') {
        config.rtsp_stun_server = strdup(value);
        logger(LOG_INFO, "RTSP STUN server: %s", config.rtsp_stun_server);
      }
    }
    return;
  }

  if (strcasecmp("http-proxy-user-agent", param) == 0) {
    if (set_if_not_cmd_override(cmd_http_proxy_user_agent_set, "http-proxy-user-agent")) {
      safe_free_string(&config.http_proxy_user_agent);
      if (value[0] != '\0') {
        config.http_proxy_user_agent = strdup(value);
      }
    }
    return;
  }

  if (strcasecmp("rtsp-user-agent", param) == 0) {
    if (set_if_not_cmd_override(cmd_rtsp_user_agent_set, "rtsp-user-agent")) {
      safe_free_string(&config.rtsp_user_agent);
      if (value[0] != '\0') {
        config.rtsp_user_agent = strdup(value);
      }
    }
    return;
  }

  /* CORS configuration */
  if (strcasecmp("cors-allow-origin", param) == 0) {
    if (set_if_not_cmd_override(cmd_cors_allow_origin_set, "cors-allow-origin")) {
      safe_free_string(&config.cors_allow_origin);
      config.cors_allow_origin = strdup(value);
    }
    return;
  }

  /* Keep legacy snake_case config names working for existing files. */
  if (strcasecmp("access-log", param) == 0 || strcasecmp("access_log", param) == 0) {
    if (set_if_not_cmd_override(cmd_access_log_set, "access-log")) {
      safe_free_string(&config.access_log);
      if (value[0] != '\0')
        config.access_log = strdup(value);
    }
    return;
  }

  if (strcasecmp("log-format", param) == 0 || strcasecmp("log_format", param) == 0) {
    if (set_if_not_cmd_override(cmd_log_format_set, "log-format")) {
      safe_free_string(&config.log_format);
      if (value[0] != '\0')
        config.log_format = strdup(value);
    }
    return;
  }

  if (strcasecmp("pid-file", param) == 0) {
    if (set_if_not_cmd_override(cmd_pid_file_set, "pid-file")) {
      safe_free_string(&config.pid_file);
      if (value[0] != '\0')
        config.pid_file = strdup(value);
    }
    return;
  }

  logger(LOG_ERROR, "Unknown config parameter: %s", param);
}

int parse_config_file(const char *path) {
  FILE *cfile;
  char line[MAX_LINE];
  int i, bind_msg_done = 0;
  enum section_e section = SEC_NONE;
  enum section_e prev_section = SEC_NONE;

  logger(LOG_DEBUG, "Opening %s", path);
  cfile = fopen(path, "r");
  if (cfile == NULL)
    return -1;

  /* Reset transformed M3U playlist buffer at start of config parsing */
  m3u_reset_transformed_playlist();

  while (fgets(line, MAX_LINE, cfile)) {
    i = 0;

    while (isspace(line[i]))
      i++;

    /* Allow # comments in [services] section for M3U content, skip in other
     * sections */
    if ((line[i] == '#' || line[i] == ';') && section != SEC_SERVICES)
      continue;

    if (line[i] == '\0')
      continue;

    if (line[i] == '[') { /* section change */
      /* Process any buffered M3U content before changing sections */
      if (prev_section == SEC_SERVICES) {
        if (inline_m3u_buffer && inline_m3u_buffer_used > 0) {
          /* Parse inline M3U (EPG will be fetched async by workers) */
          m3u_parse_and_create_services(inline_m3u_buffer, "inline");
          free(inline_m3u_buffer);
          inline_m3u_buffer = NULL;
          inline_m3u_buffer_size = 0;
          inline_m3u_buffer_used = 0;
        }
      }

      char *end = index(line + i, ']');
      if (end) {
        char *section_name = strndupa(line + i + 1, end - line - i - 1);
        if (strcasecmp("bind", section_name) == 0) {
          prev_section = section;
          section = SEC_BIND;
          continue;
        }
        if (strcasecmp("services", section_name) == 0) {
          prev_section = section;
          section = SEC_SERVICES;
          continue;
        }
        if (strcasecmp("global", section_name) == 0) {
          prev_section = section;
          section = SEC_GLOBAL;
          continue;
        }
        logger(LOG_ERROR, "Invalid section name: %s", section_name);
        continue;
      } else {
        logger(LOG_ERROR, "Unterminated section: %s", line + i);
        continue;
      }
    }

    if (cmd_bind_set && section == SEC_BIND) {
      if (!bind_msg_done) {
        logger(LOG_WARN, "Config file section \"[bind]\" ignored (already set "
                         "on command line)");
        bind_msg_done = 1;
      }
      continue;
    }

    switch (section) {
    case SEC_BIND:
      parse_bind_sec(line + i);
      break;
    case SEC_SERVICES:
      parse_services_sec(line + i);
      break;
    case SEC_GLOBAL:
      parse_global_sec(line + i);
      break;
    default:
      logger(LOG_ERROR, "Unrecognised config line: %s", line);
    }
  }

  /* Process any remaining buffered inline M3U content at end of file */
  if (section == SEC_SERVICES) {
    if (inline_m3u_buffer && inline_m3u_buffer_used > 0) {
      /* Parse inline M3U (EPG will be fetched async by workers) */
      m3u_parse_and_create_services(inline_m3u_buffer, "inline");
      free(inline_m3u_buffer);
      inline_m3u_buffer = NULL;
      inline_m3u_buffer_size = 0;
      inline_m3u_buffer_used = 0;
    }
  }

  fclose(cfile);
  return 0;
}

bindaddr_t *new_empty_bindaddr(void) {
  bindaddr_t *ba;
  ba = malloc(sizeof(bindaddr_t));
  memset(ba, 0, sizeof(*ba));
  ba->type = BIND_ADDR_TCP;
  ba->service = strdup("5140");
  return ba;
}

void free_bindaddr(bindaddr_t *ba) {
  bindaddr_t *bat;
  while (ba) {
    bat = ba;
    ba = ba->next;
    if (bat->node)
      free(bat->node);
    if (bat->service)
      free(bat->service);
    if (bat->path)
      free(bat->path);
    free(bat);
  }
}

/**
 * Deep copy a bind address list
 */
bindaddr_t *bindaddr_copy(bindaddr_t *src) {
  bindaddr_t *head = NULL;
  bindaddr_t **tail = &head;

  while (src) {
    bindaddr_t *copy = malloc(sizeof(bindaddr_t));
    if (!copy) {
      free_bindaddr(head);
      return NULL;
    }
    memset(copy, 0, sizeof(*copy));
    copy->type = src->type;
    copy->node = src->node ? strdup(src->node) : NULL;
    copy->service = src->service ? strdup(src->service) : NULL;
    copy->path = src->path ? strdup(src->path) : NULL;
    copy->next = NULL;
    *tail = copy;
    tail = &copy->next;
    src = src->next;
  }

  return head;
}

/**
 * Compare two bind address lists for equality
 * Returns 1 if equal, 0 if different
 */
int bind_addresses_equal(bindaddr_t *a, bindaddr_t *b) {
  while (a && b) {
    if (a->type != b->type)
      return 0;

    /* Compare node (both NULL or both equal) */
    if (a->node == NULL && b->node != NULL)
      return 0;
    if (a->node != NULL && b->node == NULL)
      return 0;
    if (a->node && b->node && strcmp(a->node, b->node) != 0)
      return 0;

    /* Compare service (both NULL or both equal) */
    if (a->service == NULL && b->service != NULL)
      return 0;
    if (a->service != NULL && b->service == NULL)
      return 0;
    if (a->service && b->service && strcmp(a->service, b->service) != 0)
      return 0;

    /* Compare path (both NULL or both equal) */
    if (a->path == NULL && b->path != NULL)
      return 0;
    if (a->path != NULL && b->path == NULL)
      return 0;
    if (a->path && b->path && strcmp(a->path, b->path) != 0)
      return 0;

    a = a->next;
    b = b->next;
  }

  /* Both should be NULL at the end for equality */
  return (a == NULL && b == NULL);
}

/**
 * Get the config file path
 */
const char *get_config_file_path(void) { return config_file_path; }

/**
 * Set the config file path (stores a copy)
 */
void set_config_file_path(const char *path) {
  if (config_file_path) {
    free(config_file_path);
    config_file_path = NULL;
  }
  if (path) {
    config_file_path = strdup(path);
  }
}

/**
 * Free all configuration resources
 * Frees services, EPG cache, M3U cache, bind addresses, and config strings.
 * Respects cmd_*_set flags - resources set by command line are NOT freed.
 * Does NOT reset cmd_*_set flags (they track command line args).
 */
void config_cleanup(bool force_free) {
  /* Free all services */
  service_free_all();

  /* Free EPG cache */
  epg_cleanup();

  /* Free string config values */
  free_config_strings(&config, force_free);

  /* Free bind addresses */
  if (!cmd_bind_set || force_free) {
    free_bindaddr(bind_addresses);
    bind_addresses = NULL;
  }
}

int config_snapshot(config_t *snapshot) {
  if (!snapshot)
    return -1;

  *snapshot = config;
  snapshot->hostname = NULL;
  snapshot->r2h_token = NULL;
  snapshot->ffmpeg_path = NULL;
  snapshot->ffmpeg_args = NULL;
  snapshot->status_page_path = NULL;
  snapshot->status_page_route = NULL;
  snapshot->player_page_path = NULL;
  snapshot->player_page_route = NULL;
  snapshot->app_path_prefix = NULL;
  snapshot->app_path_route = NULL;
  snapshot->external_m3u_url = NULL;
  snapshot->rtsp_stun_server = NULL;
  snapshot->http_proxy_user_agent = NULL;
  snapshot->rtsp_user_agent = NULL;
  snapshot->cors_allow_origin = NULL;
  snapshot->access_log = NULL;
  snapshot->log_format = NULL;
  snapshot->pid_file = NULL;

#define SNAPSHOT_STRING(field, cmd_flag)                                                                               \
  do {                                                                                                                 \
    if (snapshot_string(&snapshot->field, config.field, cmd_flag) < 0)                                                 \
      goto error;                                                                                                      \
  } while (0)

  SNAPSHOT_STRING(hostname, cmd_hostname_set);
  SNAPSHOT_STRING(r2h_token, cmd_r2h_token_set);
  SNAPSHOT_STRING(ffmpeg_path, cmd_ffmpeg_path_set);
  SNAPSHOT_STRING(ffmpeg_args, cmd_ffmpeg_args_set);
  SNAPSHOT_STRING(status_page_path, cmd_status_page_path_set);
  SNAPSHOT_STRING(status_page_route, cmd_status_page_path_set);
  SNAPSHOT_STRING(player_page_path, cmd_player_page_path_set);
  SNAPSHOT_STRING(player_page_route, cmd_player_page_path_set);
  SNAPSHOT_STRING(app_path_prefix, cmd_app_path_prefix_set);
  SNAPSHOT_STRING(app_path_route, cmd_app_path_prefix_set);
  SNAPSHOT_STRING(external_m3u_url, cmd_external_m3u_url_set);
  SNAPSHOT_STRING(rtsp_stun_server, cmd_rtsp_stun_server_set);
  SNAPSHOT_STRING(http_proxy_user_agent, cmd_http_proxy_user_agent_set);
  SNAPSHOT_STRING(rtsp_user_agent, cmd_rtsp_user_agent_set);
  SNAPSHOT_STRING(cors_allow_origin, cmd_cors_allow_origin_set);
  SNAPSHOT_STRING(access_log, cmd_access_log_set);
  SNAPSHOT_STRING(log_format, cmd_log_format_set);
  SNAPSHOT_STRING(pid_file, cmd_pid_file_set);

#undef SNAPSHOT_STRING

  return 0;

error:
  config_snapshot_free(snapshot);
  return -1;
}

void config_snapshot_free(config_t *snapshot) {
  if (!snapshot)
    return;

  free_config_strings(snapshot, false);
  memset(snapshot, 0, sizeof(*snapshot));
}

void config_restore_snapshot(config_t *snapshot) {
  if (!snapshot)
    return;

  free_config_strings(&config, false);
  config = *snapshot;
  memset(snapshot, 0, sizeof(*snapshot));
}

/**
 * Initialize configuration with default values
 * Sets all config values to defaults. Respects cmd_*_set flags -
 * values set by command line are NOT reset.
 * Does NOT reset cmd_*_set flags (they track command line args).
 */
void config_init(void) {
  /* Set numeric config values to defaults (only if not set by command line) */
  if (!cmd_verbosity_set)
    config.verbosity = LOG_ERROR;
  if (!cmd_maxclients_set)
    config.maxclients = 5;
  if (!cmd_udpxy_set)
    config.udpxy = 1;
  if (!cmd_buffer_pool_max_size_set)
    config.buffer_pool_max_size = 16384;
  if (!cmd_udp_rcvbuf_size_set)
    config.udp_rcvbuf_size = 512 * 1024; /* 512KB default */
  if (!cmd_xff_set)
    config.xff = 0;
  if (!cmd_video_snapshot_set)
    config.video_snapshot = 0;
  if (!cmd_mcast_rejoin_interval_set)
    config.mcast_rejoin_interval = 0;
  if (!cmd_use_relative_path_in_m3u_set)
    config.use_relative_path_in_m3u = 0;
  if (!cmd_fcc_listen_port_range_set) {
    config.fcc_listen_port_min = 0;
    config.fcc_listen_port_max = 0;
  }

  /* Workers setting (only if not set by command line) */
  if (!cmd_workers_set)
    config.workers = 1;

  /* Set string config values to defaults (only if not set by command line) */
  if (!cmd_ffmpeg_args_set)
    config.ffmpeg_args = strdup("-hwaccel none");
  if (!cmd_status_page_path_set)
    set_status_page_path_value("/status");
  if (!cmd_player_page_path_set)
    set_player_page_path_value("/player");
  if (!cmd_app_path_prefix_set)
    set_app_path_prefix_value("");
  if (!cmd_log_format_set)
    config.log_format = strdup(DEFAULT_ACCESS_LOG_FORMAT);

  /* Reset interface settings (only if not set by command line) */
  if (!cmd_upstream_interface_set)
    memset(config.upstream_interface, 0, IFNAMSIZ);
  if (!cmd_upstream_interface_fcc_set)
    memset(config.upstream_interface_fcc, 0, IFNAMSIZ);
  if (!cmd_upstream_interface_rtsp_set)
    memset(config.upstream_interface_rtsp, 0, IFNAMSIZ);
  if (!cmd_upstream_interface_multicast_set)
    memset(config.upstream_interface_multicast, 0, IFNAMSIZ);
  if (!cmd_upstream_interface_http_set)
    memset(config.upstream_interface_http, 0, IFNAMSIZ);

  /* External M3U settings (only if not set by command line) */
  if (!cmd_external_m3u_update_interval_set)
    config.external_m3u_update_interval = 7200;
  config.last_external_m3u_update_time = 0;

  /* Initialize service hashmap */
  service_hashmap_init();
}

/**
 * Reload configuration from file
 * Sequence: config_cleanup() -> config_init() -> parse_config_file()
 *
 * @param out_bind_changed If non-NULL, set to 1 if bind addresses changed
 * @return 0 on success, -1 on error (keeps old config)
 */
int config_reload(int *out_bind_changed) {
  bindaddr_t *old_bind_addresses;

  if (!config_file_path) {
    logger(LOG_INFO, "Only reload M3U/EPG, skipping configuration reload "
                     "(config file path not set)");
    config.last_external_m3u_update_time = 0;
    return 0;
  }

  /* Save current bind addresses for comparison and potential rollback */
  old_bind_addresses = bindaddr_copy(bind_addresses);

  /* Step 1: Cleanup all configuration resources */
  config_cleanup(false);

  /* Step 2: Initialize configuration with defaults */
  config_init();

  /* Step 3: Parse config file */
  if (parse_config_file(config_file_path) != 0) {
    logger(LOG_ERROR, "Failed to parse config file during reload: %s", config_file_path);
    goto reload_failed;
  }

  /* Check if bind addresses changed */
  if (out_bind_changed) {
    *out_bind_changed = !bind_addresses_equal(bind_addresses, old_bind_addresses);
  }

  /* Clean up saved bind addresses */
  if (old_bind_addresses)
    free_bindaddr(old_bind_addresses);

  logger(LOG_INFO, "Configuration reloaded successfully from %s", config_file_path);

  return 0;

reload_failed:
  /* Restore the bind addresses captured before the failed reload */
  if (!cmd_bind_set) {
    free_bindaddr(bind_addresses);
    bind_addresses = old_bind_addresses;
    old_bind_addresses = NULL; /* Now owned by the global */
  }
  if (old_bind_addresses)
    free_bindaddr(old_bind_addresses);
  return -1;
}

void usage(FILE *f, char *progname) {
  char *prog = basename(progname);
  fprintf(f, PACKAGE " - Multicast RTP to Unicast HTTP stream convertor\n"
                     "\n"
                     "Version " VERSION "\n"
                     "\n"
                     "This program is free software; you can redistribute it and/or modify\n"
                     "it under the terms of the GNU General Public License version 2\n"
                     "as published by the Free Software Foundation.\n");
  fprintf(f,
          "\n"
          "Usage: %s [options]\n"
          "\n"
          "Options:\n"
          "\t-h --help            Show this help\n"
          "\t-v --verbose         Increase verbosity (0=FATAL, 1=ERROR, 2=WARN, "
          "3=INFO, 4=DEBUG)\n"
          "\t-q --quiet           Report only fatal errors\n"
          "\t-U --noudpxy         Disable UDPxy compatibility\n"
          "\t-m --maxclients <n>  Serve max n requests simultaneously (default 5)\n"
          "\t-w --workers <n>     Number of worker processes with SO_REUSEPORT "
          "(default 1)\n"
          "\t-b --buffer-pool-max-size <n> Maximum number of buffers in "
          "pool (default 16384)\n"
          "\t-B --udp-rcvbuf-size <bytes> UDP socket receive buffer size for "
          "multicast/FCC/RTSP (default 524288 = 512KB)\n"
          "\t-l --listen [addr:]port|/path.sock  TCP address/port or Unix "
          "socket path to bind (default ANY:5140)\n"
          "\t-c --config <file>   Read this file for configuration, instead of the "
          "default one\n"
          "\t-C --noconfig        Do not read the default config\n"
          "\t   --pid-file <path> Write and lock the supervisor PID file\n"
          "\t-P --fcc-listen-port-range <start[-end]>  Restrict FCC UDP listen "
          "sockets to specific ports\n"
          "\t-H --hostname <hostname> Hostname to check in the Host: HTTP header "
          "(default none)\n"
          "\t-X --xff             Enable X-Forwarded-For header recognize "
          "(default: off)\n"
          "\t-T --r2h-token <token>   Authentication token for HTTP requests "
          "(default none)\n"
          "\t-i --upstream-interface <interface>  Default interface for all "
          "upstream traffic (lowest priority)\n"
          "\t-f --upstream-interface-fcc <interface>  Interface for FCC unicast "
          "traffic (overrides -i)\n"
          "\t-t --upstream-interface-rtsp <interface>  Interface for RTSP unicast "
          "traffic (overrides -i)\n"
          "\t-r --upstream-interface-multicast <interface>  Interface for "
          "multicast traffic (overrides -i)\n"
          "\t-y --upstream-interface-http <interface>  Interface for HTTP proxy "
          "upstream traffic (overrides -i)\n"
          "\t-R --mcast-rejoin-interval <seconds>  Periodic multicast rejoin "
          "interval (0=disabled, default 0)\n"
          "\t-F --ffmpeg-path <path>  Path to ffmpeg executable (default: ffmpeg)\n"
          "\t-A --ffmpeg-args <args>  Additional ffmpeg arguments (default: "
          "-hwaccel none)\n"
          "\t-S --video-snapshot      Enable video snapshot feature (default: "
          "off)\n"
          "\t-s --status-page-path <path>  HTTP path for status UI (default: "
          "/status)\n"
          "\t-p --player-page-path <path>  HTTP path for player UI (default: "
          "/player)\n"
          "\t   --app-path-prefix <path>  Public mount path prefix for all HTTP "
          "resources (default: none)\n"
          "\t   --use-relative-path-in-m3u  Use root-relative URLs in generated "
          "and rewritten M3U playlists (default: off)\n"
          "\t-M --external-m3u <url>  External M3U playlist URL (file://, http://, "
          "https://)\n"
          "\t-I --external-m3u-update-interval <seconds>  Auto-update interval "
          "(default: 7200 = 2h, 0=disabled)\n"
          "\t-g --http-proxy-user-agent <value>  Override User-Agent for upstream HTTP proxy requests\n"
          "\t-u --rtsp-user-agent <value>  User-Agent header for upstream RTSP requests "
          "(default: rtp2httpd/<version>)\n"
          "\t-N --rtsp-stun-server <host:port>  STUN server for RTSP NAT traversal "
          "(default: disabled)\n"
          "\t-O --cors-allow-origin <origin>  Set Access-Control-Allow-Origin header "
          "(default: disabled)\n"
          "\t   --access-log <path>  Write access logs to this file (default: disabled)\n"
          "\t   --log-format <format>  Access log format (nginx-style $variables)\n"
          "\t                     default " CONFIGFILE "\n",
          prog);
}

void parse_bind_cmd(char *arg) {
  char *p, *node, *service;

  if (arg && arg[0] == '/') {
    char *path;
    if (!bind_path_is_valid(arg)) {
      logger(LOG_ERROR, "Invalid Unix socket bind path: %s", arg);
      return;
    }
    path = strdup(arg);
    if (!path) {
      logger(LOG_ERROR, "Failed to allocate Unix socket bind path");
      return;
    }
    logger(LOG_DEBUG, "unix socket path: %s", path);
    add_bindaddr_unix(path);
    return;
  }

  if (arg[0] == '[') {
    p = index(arg++, ']');
    if (p) {
      *p = '\0';
      p = rindex(++p, ':');
    }
  } else {
    p = rindex(arg, ':');
  }
  if (p) {
    *p = '\0';
    node = strdup(arg);
    service = strdup(p + 1);
  } else {
    node = NULL;
    service = strdup(arg);
  }

  logger(LOG_DEBUG, "node: %s, port: %s", node, service);
  add_bindaddr_tcp(node, service);
}

void parse_cmd_line(int argc, char *argv[]) {
  const struct option longopts[] = {{"verbose", required_argument, 0, 'v'},
                                    {"quiet", no_argument, 0, 'q'},
                                    {"help", no_argument, 0, 'h'},
                                    {"noudpxy", no_argument, 0, 'U'},
                                    {"maxclients", required_argument, 0, 'm'},
                                    {"workers", required_argument, 0, 'w'},
                                    {"buffer-pool-max-size", required_argument, 0, 'b'},
                                    {"udp-rcvbuf-size", required_argument, 0, 'B'},
                                    {"listen", required_argument, 0, 'l'},
                                    {"config", required_argument, 0, 'c'},
                                    {"noconfig", no_argument, 0, 'C'},
                                    {"fcc-listen-port-range", required_argument, 0, 'P'},
                                    {"hostname", required_argument, 0, 'H'},
                                    {"xff", no_argument, 0, 'X'},
                                    {"r2h-token", required_argument, 0, 'T'},
                                    {"upstream-interface", required_argument, 0, 'i'},
                                    {"upstream-interface-fcc", required_argument, 0, 'f'},
                                    {"upstream-interface-rtsp", required_argument, 0, 't'},
                                    {"upstream-interface-multicast", required_argument, 0, 'r'},
                                    {"upstream-interface-http", required_argument, 0, 'y'},
                                    {"mcast-rejoin-interval", required_argument, 0, 'R'},
                                    {"ffmpeg-path", required_argument, 0, 'F'},
                                    {"ffmpeg-args", required_argument, 0, 'A'},
                                    {"video-snapshot", no_argument, 0, 'S'},
                                    {"status-page-path", required_argument, 0, 's'},
                                    {"player-page-path", required_argument, 0, 'p'},
                                    {"app-path-prefix", required_argument, 0, OPT_APP_PATH_PREFIX},
                                    {"use-relative-path-in-m3u", no_argument, 0, OPT_USE_RELATIVE_PATH_IN_M3U},
                                    {"external-m3u", required_argument, 0, 'M'},
                                    {"external-m3u-update-interval", required_argument, 0, 'I'},
                                    {"http-proxy-user-agent", required_argument, 0, 'g'},
                                    {"rtsp-stun-server", required_argument, 0, 'N'},
                                    {"rtsp-user-agent", required_argument, 0, 'u'},
                                    {"cors-allow-origin", required_argument, 0, 'O'},
                                    {"access-log", required_argument, 0, OPT_ACCESS_LOG},
                                    {"log-format", required_argument, 0, OPT_LOG_FORMAT},
                                    {"pid-file", required_argument, 0, OPT_PID_FILE},
                                    {0, 0, 0, 0}};

  const char short_opts[] = "v:qhUm:w:b:B:c:l:P:H:XT:i:f:t:r:y:R:F:A:s:p:M:I:SCg:N:u:O:";
  int option_index, opt;
  int configfile_failed = 1;

  /* Zero out config structure and initialize with defaults */
  memset(&config, 0, sizeof(config_t));
  config_init();

  while ((opt = getopt_long(argc, argv, short_opts, longopts, &option_index)) != -1) {
    switch (opt) {
    case 0:
      break;
    case 'v':
      config.verbosity = atoi(optarg);
      cmd_verbosity_set = 1;
      break;
    case 'q':
      config.verbosity = 0;
      cmd_verbosity_set = 1;
      break;
    case 'h':
      usage(stdout, argv[0]);
      exit(EXIT_SUCCESS);
      break;
    case 'U':
      config.udpxy = 0;
      cmd_udpxy_set = 1;
      break;
    case 'm': {
      int max_clients = atoi(optarg);
      if (max_clients < 1 || max_clients > CONFIG_MAX_CLIENTS) {
        logger(LOG_ERROR, "Invalid maxclients! Must be between 1 and %d. Ignoring.", CONFIG_MAX_CLIENTS);
      } else {
        config.maxclients = max_clients;
        cmd_maxclients_set = 1;
      }
      break;
    }
    case 'w': {
      int worker_count = atoi(optarg);
      if (worker_count < 1 || worker_count > CONFIG_MAX_WORKERS) {
        logger(LOG_ERROR, "Invalid workers! Must be between 1 and %d. Ignoring.", CONFIG_MAX_WORKERS);
      } else {
        config.workers = worker_count;
        cmd_workers_set = 1;
      }
      break;
    }
    case 'b':
      if (atoi(optarg) < 1) {
        logger(LOG_ERROR, "Invalid buffer-pool-max-size! Ignoring.");
      } else {
        config.buffer_pool_max_size = atoi(optarg);
        cmd_buffer_pool_max_size_set = 1;
      }
      break;
    case 'B':
      if (atoi(optarg) < 65536) {
        logger(LOG_ERROR, "Invalid udp-rcvbuf-size! Must be >= 65536 (64KB). Ignoring.");
      } else {
        config.udp_rcvbuf_size = atoi(optarg);
        cmd_udp_rcvbuf_size_set = 1;
      }
      break;
    case 'c':
      configfile_failed = parse_config_file(optarg);
      if (configfile_failed == 0) {
        set_config_file_path(optarg);
      }
      break;
    case 'C':
      configfile_failed = 0;
      set_config_file_path(NULL); /* No config file */
      break;
    case 'l':
      if (!cmd_bind_set && bind_addresses) {
        free_bindaddr(bind_addresses);
        bind_addresses = NULL;
      }
      parse_bind_cmd(optarg);
      cmd_bind_set = 1;
      break;
    case 'P': {
      int min_port = 0;
      int max_port = 0;
      if (parse_port_range_value(optarg, &min_port, &max_port) == 0) {
        config.fcc_listen_port_min = min_port;
        config.fcc_listen_port_max = max_port;
        cmd_fcc_listen_port_range_set = 1;
        logger(LOG_INFO, "FCC listen port range set to %d-%d", min_port, max_port);
      } else {
        logger(LOG_ERROR, "Invalid fcc-listen-port-range value: %s", optarg);
      }
      break;
    }
    case 'H':
      safe_free_string(&config.hostname);
      config.hostname = strdup(optarg);
      cmd_hostname_set = 1;
      break;
    case 'X':
      config.xff = 1;
      cmd_xff_set = 1;
      logger(LOG_INFO, "X-Forwarded-For header recognize enabled");
      break;
    case 'T':
      safe_free_string(&config.r2h_token);
      config.r2h_token = strdup(optarg);
      cmd_r2h_token_set = 1;
      break;
    case 's':
      set_status_page_path_value(optarg);
      cmd_status_page_path_set = 1;
      break;
    case 'p':
      set_player_page_path_value(optarg);
      cmd_player_page_path_set = 1;
      break;
    case OPT_APP_PATH_PREFIX:
      set_app_path_prefix_value(optarg);
      cmd_app_path_prefix_set = 1;
      break;
    case OPT_USE_RELATIVE_PATH_IN_M3U:
      config.use_relative_path_in_m3u = 1;
      cmd_use_relative_path_in_m3u_set = 1;
      logger(LOG_INFO, "Using root-relative URLs in M3U playlists");
      break;
    case 'i':
      strncpy(config.upstream_interface, optarg, IFNAMSIZ - 1);
      cmd_upstream_interface_set = 1;
      break;
    case 'f':
      strncpy(config.upstream_interface_fcc, optarg, IFNAMSIZ - 1);
      cmd_upstream_interface_fcc_set = 1;
      break;
    case 't':
      strncpy(config.upstream_interface_rtsp, optarg, IFNAMSIZ - 1);
      cmd_upstream_interface_rtsp_set = 1;
      break;
    case 'r':
      strncpy(config.upstream_interface_multicast, optarg, IFNAMSIZ - 1);
      cmd_upstream_interface_multicast_set = 1;
      break;
    case 'y':
      strncpy(config.upstream_interface_http, optarg, IFNAMSIZ - 1);
      cmd_upstream_interface_http_set = 1;
      break;
    case 'R':
      if (atoi(optarg) < 0) {
        logger(LOG_ERROR, "Invalid mcast-rejoin-interval! Ignoring.");
      } else {
        config.mcast_rejoin_interval = atoi(optarg);
        cmd_mcast_rejoin_interval_set = 1;
        if (config.mcast_rejoin_interval > 0) {
          logger(LOG_INFO, "Multicast rejoin interval set to %d seconds", config.mcast_rejoin_interval);
        }
      }
      break;
    case 'F':
      safe_free_string(&config.ffmpeg_path);
      config.ffmpeg_path = strdup(optarg);
      cmd_ffmpeg_path_set = 1;
      break;
    case 'A':
      safe_free_string(&config.ffmpeg_args);
      config.ffmpeg_args = strdup(optarg);
      cmd_ffmpeg_args_set = 1;
      break;
    case 'S':
      config.video_snapshot = 1;
      cmd_video_snapshot_set = 1;
      break;
    case 'M':
      if (config.external_m3u_url)
        free(config.external_m3u_url);
      config.external_m3u_url = strdup(optarg);
      cmd_external_m3u_url_set = 1;
      logger(LOG_INFO, "External M3U URL set to: %s", config.external_m3u_url);
      break;
    case 'I':
      if (atoi(optarg) < 0) {
        logger(LOG_ERROR, "Invalid external-m3u-update-interval! Ignoring.");
      } else {
        config.external_m3u_update_interval = atoi(optarg);
        cmd_external_m3u_update_interval_set = 1;
        logger(LOG_INFO, "External M3U update interval set to %d seconds", config.external_m3u_update_interval);
      }
      break;
    case 'g':
      safe_free_string(&config.http_proxy_user_agent);
      if (optarg[0] != '\0') {
        config.http_proxy_user_agent = strdup(optarg);
      }
      cmd_http_proxy_user_agent_set = 1;
      break;
    case 'N':
      safe_free_string(&config.rtsp_stun_server);
      config.rtsp_stun_server = strdup(optarg);
      cmd_rtsp_stun_server_set = 1;
      logger(LOG_INFO, "RTSP STUN server: %s", config.rtsp_stun_server);
      break;
    case 'u':
      safe_free_string(&config.rtsp_user_agent);
      if (optarg[0] != '\0') {
        config.rtsp_user_agent = strdup(optarg);
      }
      cmd_rtsp_user_agent_set = 1;
      break;
    case 'O':
      safe_free_string(&config.cors_allow_origin);
      config.cors_allow_origin = strdup(optarg);
      cmd_cors_allow_origin_set = 1;
      break;
    case OPT_ACCESS_LOG:
      safe_free_string(&config.access_log);
      if (optarg[0] != '\0') {
        config.access_log = strdup(optarg);
      }
      cmd_access_log_set = 1;
      break;
    case OPT_LOG_FORMAT:
      safe_free_string(&config.log_format);
      if (optarg[0] != '\0') {
        config.log_format = strdup(optarg);
      }
      cmd_log_format_set = 1;
      break;
    case OPT_PID_FILE:
      safe_free_string(&config.pid_file);
      if (optarg[0] != '\0') {
        config.pid_file = strdup(optarg);
      }
      cmd_pid_file_set = 1;
      break;
    default:
      logger(LOG_FATAL, "Unknown option! %d ", opt);
      usage(stderr, argv[0]);
      exit(EXIT_FAILURE);
    }
  }
  if (configfile_failed) {
    configfile_failed = parse_config_file(CONFIGFILE);
    if (configfile_failed == 0) {
      set_config_file_path(CONFIGFILE);
    }
  }
  if (configfile_failed) {
    logger(LOG_WARN, "No config file found");
    set_config_file_path(NULL);
  }

  /* External M3U will be loaded asynchronously by workers after startup
   * This avoids blocking the startup process waiting for network resources */
  if (config.external_m3u_url) {
    logger(LOG_INFO, "External M3U configured: %s (will load asynchronously)", config.external_m3u_url);
    /* Initialize to 0 to trigger immediate first fetch in worker event loop */
    config.last_external_m3u_update_time = 0;
  }

  logger(LOG_DEBUG, "Verbosity: %d, Maxclients: %d, Workers: %d", config.verbosity, config.maxclients, config.workers);
}
