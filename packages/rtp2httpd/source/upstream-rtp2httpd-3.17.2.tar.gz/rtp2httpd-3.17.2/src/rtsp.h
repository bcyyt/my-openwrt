#ifndef __RTSP_H__
#define __RTSP_H__

#include <netinet/in.h>
#include <stdint.h>
#include <sys/types.h>

#include "stun.h"

/* Forward declaration */
struct addrinfo;

/*
 * Endpoint advertised upstream for NAT traversal: either the STUN-discovered
 * public mapping or the RTSP control connection's own local endpoint.
 */
typedef struct {
  struct in_addr ip4;
  char ip[INET6_ADDRSTRLEN];
  uint16_t control_port; /* port named by the x-NAT header */
  uint16_t rtp_port;     /* port advertised as client_port / in the punch packet */
  uint16_t rtcp_port;
} rtsp_nat_endpoint_t;

#define RTSP_DISABLE_TCP_TRANSPORT 0 /* To debug UDP transport, set to 1 */

/* Timeout constants for RTSP state machine */
#define RTSP_HANDSHAKE_TIMEOUT_SEC 3
#define RTSP_TEARDOWN_TIMEOUT_SEC 3
#define RTSP_FIRST_MEDIA_TIMEOUT_SEC 3

/* ========== RTSP BUFFER SIZE CONFIGURATION ========== */

/* RTCP buffer size - same as RTP buffer pool for consistency */
#define RTCP_BUFFER_SIZE 1536

/* RTSP response buffer - for server responses and SDP descriptions */
#define RTSP_RESPONSE_BUFFER_SIZE 4096

/* RTSP request buffer - for building outgoing requests */
#define RTSP_REQUEST_BUFFER_SIZE 4096

/* RTSP headers buffer - for extra headers in requests */
#define RTSP_HEADERS_BUFFER_SIZE 1024

/* RTSP session ID - server-generated session identifier */
#define RTSP_SESSION_ID_SIZE 128

/* RTSP server URL - complete RTSP URL. Kept in sync with HTTP_URL_BUFFER_SIZE
 * (service.h) so the entire pipeline shares one URL ceiling and there is no
 * silent mid-pipeline truncation. */
#define RTSP_SERVER_URL_SIZE 2048

/* RTSP server hostname - DNS name or IP address */
#define RTSP_SERVER_HOST_SIZE 256

/* RTSP server path - path component of URL with query string. Same sizing
 * rationale as RTSP_SERVER_URL_SIZE. */
#define RTSP_SERVER_PATH_SIZE 2048

#define RTSP_CREDENTIAL_SIZE 128

/* URL copy buffer - for URL parsing operations. Same sizing rationale as
 * RTSP_SERVER_URL_SIZE. */
#define RTSP_URL_COPY_SIZE 2048

/* Time conversion buffers - for playseek time formatting */
#define RTSP_TIME_STRING_SIZE 64

/* Port string buffer - for port number conversion */
#define RTSP_PORT_STRING_SIZE 16

/* Header parsing buffer - for individual header values */
#define RTSP_HEADER_PREFIX_SIZE 64

/* ========== RTSP MESSAGE TYPES ========== */

#define RTSP_METHOD_OPTIONS "OPTIONS"
#define RTSP_METHOD_DESCRIBE "DESCRIBE"
#define RTSP_METHOD_SETUP "SETUP"
#define RTSP_METHOD_PLAY "PLAY"
#define RTSP_METHOD_TEARDOWN "TEARDOWN"
#define RTSP_METHOD_GET_PARAMETER "GET_PARAMETER"

/* RTSP authentication types */
typedef enum { RTSP_AUTH_NONE = 0, RTSP_AUTH_BASIC, RTSP_AUTH_DIGEST } rtsp_auth_type_t;

/* RTSP protocol states - fully async state machine */
typedef enum {
  RTSP_STATE_INIT = 0,
  RTSP_STATE_CONNECTING,        /* Async TCP connection in progress */
  RTSP_STATE_CONNECTED,         /* Connected, ready to send OPTIONS */
  RTSP_STATE_SENDING_OPTIONS,   /* Sending OPTIONS request */
  RTSP_STATE_AWAITING_OPTIONS,  /* Waiting for OPTIONS response */
  RTSP_STATE_SENDING_DESCRIBE,  /* Sending DESCRIBE request */
  RTSP_STATE_AWAITING_DESCRIBE, /* Waiting for DESCRIBE response */
  RTSP_STATE_DESCRIBED,         /* DESCRIBE complete, ready to send SETUP */
  RTSP_STATE_SENDING_SETUP,     /* Sending SETUP request */
  RTSP_STATE_AWAITING_SETUP,    /* Waiting for SETUP response */
  RTSP_STATE_SETUP,             /* SETUP complete, ready to send PLAY */
  RTSP_STATE_SENDING_PLAY,      /* Sending PLAY request */
  RTSP_STATE_AWAITING_PLAY,     /* Waiting for PLAY response */
  RTSP_STATE_PLAYING,           /* PLAY complete, streaming active */
  RTSP_STATE_RECONNECTING,      /* Reconnecting to send TEARDOWN */
  RTSP_STATE_SENDING_TEARDOWN,  /* Sending TEARDOWN request */
  RTSP_STATE_AWAITING_TEARDOWN, /* Waiting for TEARDOWN response */
  RTSP_STATE_TEARDOWN_COMPLETE, /* TEARDOWN complete, ready to close */
  RTSP_STATE_PAUSED,
  RTSP_STATE_ERROR
} rtsp_state_t;

/* Transport mode types */
typedef enum {
  RTSP_TRANSPORT_UDP = 0, /* Traditional UDP transport */
  RTSP_TRANSPORT_TCP      /* TCP interleaved transport */
} rtsp_transport_mode_t;

/* Transport protocol types */
typedef enum {
  RTSP_PROTOCOL_RTP = 0, /* RTP - Media over RTP (needs RTP unwrapping) */
  RTSP_PROTOCOL_MP2T,    /* MP2T - Direct MPEG-2 TS (no RTP unwrapping) */
} rtsp_transport_protocol_t;

/* RTSP session structure */
typedef struct {
  int initialized;                         /* Flag: session has been initialized with resources */
  int socket;                              /* TCP socket to RTSP server */
  int epoll_fd;                            /* Epoll file descriptor for socket registration */
  struct connection_s *conn;               /* Connection pointer for fdmap registration */
  rtsp_state_t state;                      /* Current RTSP state */
  int64_t last_state_change_ms;            /* Timestamp of last state change */
  int status_index;                        /* Index in status_shared->clients array for state updates
                                            */
  uint32_t cseq;                           /* RTSP sequence number */
  char session_id[RTSP_SESSION_ID_SIZE];   /* RTSP session ID */
  char server_url[RTSP_SERVER_URL_SIZE];   /* Full RTSP URL */
  char setup_url[RTSP_SERVER_URL_SIZE];    /* Resolved SETUP URL (from
                                              Content-Base + a=control) */
  char server_host[RTSP_SERVER_HOST_SIZE]; /* RTSP server hostname (bare, no
                                              IPv6 brackets) */
  int server_port;                         /* RTSP server port */
  char server_path[RTSP_SERVER_PATH_SIZE]; /* RTSP path with query string */

  /* Dual-stack async connect state (sequential candidate fallback).
   * connect_results owns the getaddrinfo list; connect_next points to the
   * next untried candidate. */
  struct addrinfo *connect_results;
  struct addrinfo *connect_next;
  int connect_last_errno;
  int upstream_family; /* Address family of the connected/connecting upstream
                          (AF_INET / AF_INET6) */
  int redirect_count;  /* Number of redirects followed */
  char r2h_start[RTSP_TIME_STRING_SIZE];
  char playseek_range_start[RTSP_TIME_STRING_SIZE];
  int use_playseek_range;
  int r2h_duration;
  float r2h_duration_value;
  int metadata_probe;
  /* Set once the control socket reports EOF.  Sticky: the session can never
   * continue after this, even if a complete response arrived alongside it. */
  int peer_closed;
  /* Bumped by every rtsp_connect().  Lets an event handler tell whether the
   * response it just processed replaced the control connection (redirect or
   * TEARDOWN reconnect), in which case events for the old one must be ignored.
   * fd numbers cannot be used for this: close()+socket() often reuses them. */
  unsigned connect_generation;

  /* Control connection endpoints as actually selected by the kernel.  The ZTE
   * x-NAT header and punch packet are IPv4-only, so only the IPv4 addresses are
   * retained next to the printable form of the local address (which is also
   * filled for IPv6 control connections, for logging). */
  struct in_addr control_local_ip4;
  struct in_addr control_peer_ip4;
  char control_local_ip[INET6_ADDRSTRLEN];
  uint16_t control_local_port;
  int control_endpoints_valid;
  /* ZTE NAT traversal is in effect for this session: send the x-NAT header and
   * the client_address parameter, pin the media sockets to the control
   * connection's local address, and punch with the ZXV10STB packet.  Requires
   * IPv4 on both ends of the control connection. */
  int zte_nat_active;

  /* Set while the OPTIONS response has been processed but DESCRIBE is held
   * back waiting for STUN.  The state stays AWAITING_OPTIONS throughout, so
   * this flag is what distinguishes "parked, safe to resume" from "OPTIONS
   * still in flight" - resuming in the latter would pipeline DESCRIBE behind
   * an unanswered OPTIONS. */
  int describe_waiting_for_stun;

  /* Authentication state */
  char username[RTSP_CREDENTIAL_SIZE];    /* RTSP username for authentication */
  char password[RTSP_CREDENTIAL_SIZE];    /* RTSP password for authentication */
  rtsp_auth_type_t auth_type;             /* Authentication type required by server */
  char auth_realm[RTSP_CREDENTIAL_SIZE];  /* Digest auth realm */
  char auth_nonce[RTSP_CREDENTIAL_SIZE];  /* Digest auth nonce */
  char auth_opaque[RTSP_CREDENTIAL_SIZE]; /* Digest auth opaque */
  int auth_retry_count;                   /* Number of auth retries (prevent infinite loops) */

  /* Transport mode configuration */
  rtsp_transport_mode_t transport_mode;         /* Current transport mode */
  rtsp_transport_protocol_t transport_protocol; /* Current transport protocol */

  /* TCP interleaved transport info */
  int rtp_channel;  /* RTP interleaved channel (usually 0) */
  int rtcp_channel; /* RTCP interleaved channel (usually 1) */

  /* RTP/UDP transport info (preserved for future use) */
  int rtp_socket;                                 /* Local RTP receiving socket */
  int rtcp_socket;                                /* Local RTCP receiving socket */
  int local_rtp_port;                             /* Local RTP port */
  int local_rtcp_port;                            /* Local RTCP port */
  int server_rtp_port;                            /* Server RTP port */
  int server_rtcp_port;                           /* Server RTCP port */
  char server_source_addr[RTSP_SERVER_HOST_SIZE]; /* Server UDP source address
                                                     for NAT traversal */

  /* STUN NAT traversal state */
  stun_state_t stun; /* STUN state for discovering mapped UDP port */

  /* Statistics */
  uint64_t packets_dropped; /* Packets dropped due to backpressure */

  /* Cleanup state */
  int cleanup_done;         /* Flag: cleanup has been completed */
  int first_media_received; /* Flag: first media packet received in PLAYING */

  /* Non-blocking I/O state */
  char pending_request[RTSP_REQUEST_BUFFER_SIZE]; /* Request being sent */
  size_t pending_request_len;                     /* Total length of pending request */
  size_t pending_request_sent;                    /* Bytes already sent */
  size_t response_buffer_pos;                     /* Current position in response buffer */
  int awaiting_response;                          /* Flag: waiting for response */

  /* Keepalive tracking */
  int keepalive_interval_ms;       /* Keepalive interval (0 = disabled) */
  int64_t last_keepalive_ms;       /* Timestamp of last keepalive */
  int keepalive_pending;           /* Pending keepalive request queued for send */
  int awaiting_keepalive_response; /* Awaiting keepalive response */
  int use_get_parameter;           /* Use GET_PARAMETER for keepalive (1), fallback to
                                      OPTIONS (0) */

  /* Teardown and cleanup state */
  int teardown_requested;             /* Flag: TEARDOWN has been requested (cleanup
                                         initiated) */
  int teardown_reconnect_done;        /* Flag: Already attempted reconnect for TEARDOWN
                                       */
  rtsp_state_t state_before_teardown; /* State before TEARDOWN was initiated */

  /* Per-service upstream interface override (resolved at init, non-owning) */
  const char *upstream_ifname;

  /* Buffering */
  uint8_t response_buffer[RTSP_RESPONSE_BUFFER_SIZE]; /* Buffer for RTSP
                                                         responses (control
                                                         plane, not media) */

  /* Flow control state (TCP interleaved transport only) */
  int upstream_paused; /* 1 = upstream recv currently suspended due to client backpressure */
} rtsp_session_t;

/* Function prototypes */

/**
 * Initialize RTSP session structure
 * @param session RTSP session to initialize
 */
void rtsp_session_init(rtsp_session_t *session);

/**
 * Parse RTSP server URL and initialize session (RTSP protocol layer)
 * Parses RTSP URL components (host, port, path).
 * Seek parameter handling is done by service_resolve_upstream_url() before
 * calling this function.
 * @param session RTSP session to populate
 * @param rtsp_url Full RTSP URL (rtsp://host:port/path), already resolved
 * @param fallback_username Optional username to reuse when URL lacks
 * credentials
 * @param fallback_password Optional password to reuse when URL lacks
 * credentials
 * @return 0 on success, -1 on error
 */
int rtsp_parse_server_url(rtsp_session_t *session, const char *rtsp_url, const char *fallback_username,
                          const char *fallback_password);

/**
 * Connect to RTSP server (non-blocking)
 * @param session RTSP session (must have epoll_fd set)
 * @return 0 on success (connection in progress), -1 on error
 */
int rtsp_connect(rtsp_session_t *session);

/**
 * Handle socket events (readable/writable) for async I/O state machine
 * Called when socket has EPOLLIN or EPOLLOUT events
 * Handles both RTSP handshake and RTP data in PLAYING state
 * @param session RTSP session
 * @param events Epoll events (EPOLLIN, EPOLLOUT, etc.)
 * @return Return values:
 *   >0: Number of bytes forwarded to client
 *    0: No data forwarded (handshake in progress or no data available)
 *   -1: Error or connection should close (including graceful TEARDOWN completion)
 *   -2: Duration query completed (r2h-duration request)
 */
int rtsp_handle_socket_event(rtsp_session_t *session, uint32_t events);

/**
 * Handle TCP interleaved RTP data and forward to HTTP client via connection
 * output buffer
 * @param session RTSP session
 * @param conn Connection object for output buffering
 * @return Number of bytes forwarded, -1 on error
 */
int rtsp_handle_tcp_interleaved_data(rtsp_session_t *session, struct connection_s *conn);

/**
 * Handle UDP RTP data and forward to HTTP client via connection output buffer
 * @param session RTSP session
 * @param conn Connection object for output buffering
 * @return Number of bytes forwarded, -1 on error
 */
int rtsp_handle_udp_rtp_data(rtsp_session_t *session, struct connection_s *conn);

/**
 * Send RTSP TEARDOWN and cleanup session
 * @param session RTSP session
 * @return 0 if cleanup completed immediately, 1 if async TEARDOWN initiated
 * (cleanup deferred)
 */
int rtsp_session_cleanup(rtsp_session_t *session);

/** Immediately release session resources, including a pending TEARDOWN.
 * The owner must still free the session object. Safe to call repeatedly. */
void rtsp_force_cleanup(rtsp_session_t *session);

/**
 * Schedule an RTSP OPTIONS keepalive request if the session is idle.
 * @param session RTSP session
 * @return 0 on success, -1 if keepalive could not be queued
 */
int rtsp_send_keepalive(rtsp_session_t *session);

/**
 * Advance the RTSP state machine to the next state.
 * Called after receiving a response or when STUN completes.
 * @param session RTSP session
 * @return Return values:
 *    0: Success, state machine advanced
 *   -1: Error (protocol error, failed to prepare request)
 *   -2: Graceful TEARDOWN completed (not an error, cleanup should proceed)
 */
int rtsp_state_machine_advance(rtsp_session_t *session);

/**
 * Periodic tick for RTSP session (STUN timeout, keepalive, max-pause guard)
 * @param session RTSP session
 * @param now Current timestamp in milliseconds
 * @return 0 on success, -1 if session must be closed (e.g. paused too long)
 */
int rtsp_session_tick(rtsp_session_t *session, int64_t now);

/**
 * Resume reading from upstream RTSP TCP socket after client send queue has
 * drained.  No-op for UDP transport mode.  Called from stream_on_client_drain.
 * @param session RTSP session
 */
void rtsp_resume_upstream(rtsp_session_t *session);

#endif /* __RTSP_H__ */
