/** Small WebGL2 helpers shared by video filters. */

export function compileShader(gl: WebGL2RenderingContext, type: GLenum, source: string): WebGLShader {
  const shader = gl.createShader(type);
  if (!shader) {
    throw new Error("Failed to create shader");
  }
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS) && !gl.isContextLost()) {
    const info = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error(`Shader compile failed: ${info}`);
  }
  return shader;
}

export function createProgram(gl: WebGL2RenderingContext, vertexSource: string, fragmentSource: string): WebGLProgram {
  const program = gl.createProgram();
  if (!program) {
    throw new Error("Failed to create program");
  }
  let vs: WebGLShader | null = null;
  let fs: WebGLShader | null = null;
  try {
    vs = compileShader(gl, gl.VERTEX_SHADER, vertexSource);
    fs = compileShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS) && !gl.isContextLost()) {
      throw new Error(`Program link failed: ${gl.getProgramInfoLog(program)}`);
    }
    return program;
  } catch (error) {
    gl.deleteProgram(program);
    throw error;
  } finally {
    // Also release a successfully compiled vertex shader if fragment compilation fails.
    if (vs) gl.deleteShader(vs);
    if (fs) gl.deleteShader(fs);
  }
}

/**
 * Vertex shader emitting a fullscreen triangle from gl_VertexID (no vertex buffers needed).
 * v_texCoord has (0,0) at the top-left of the video frame (texel row 0 = top video row,
 * so Y is flipped relative to clip space). Field parity math relies on this orientation.
 */
export const FULLSCREEN_VERTEX_SHADER = /*glsl*/ `#version 300 es
out vec2 v_texCoord;
void main() {
  vec2 pos = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  v_texCoord = vec2(pos.x, 1.0 - pos.y);
  gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
}
`;

/**
 * Vertex shader for presenters, which may sample either orientation depending
 * on whether a source stage ran first: framebuffer-backed textures use
 * WebGL's native bottom-left origin (no flip), while a raw DOM video upload
 * fed to a presenter directly (no source stage) needs the same Y-flip as
 * `FULLSCREEN_VERTEX_SHADER`. `u_flipY` selects which one applies per draw.
 */
export const FRAMEBUFFER_VERTEX_SHADER = /*glsl*/ `#version 300 es
uniform bool u_flipY;
out vec2 v_texCoord;
void main() {
  vec2 pos = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  v_texCoord = u_flipY ? vec2(pos.x, 1.0 - pos.y) : pos;
  gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
}
`;
