#!/usr/bin/env node

import { createHash } from "node:crypto";
import { readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { extname, join, relative } from "node:path";
import { argv, exit } from "node:process";
import { gzipSync } from "node:zlib";

const GZIP_HEADER_OS_OFFSET = 9;
const GZIP_OS_UNIX = 3;

function usage() {
  console.error("Usage: node embed-dist.js <dist-dir> <output.h>");
  console.error("  dist-dir: path to the dist directory (e.g., web-ui/dist)");
  console.error("  output.h: output header file (e.g., src/embedded_web.h)");
}

function formatByteArray(buffer) {
  const bytesPerLine = 24;
  const lines = [];

  for (let offset = 0; offset < buffer.length; offset += bytesPerLine) {
    const slice = buffer.slice(offset, offset + bytesPerLine);
    const line = slice.join(", ");
    lines.push(`    ${line},`);
  }

  if (lines.length > 0) {
    const lastIndex = lines.length - 1;
    lines[lastIndex] = lines[lastIndex].replace(/,\s*$/, "");
  }

  return lines.join("\n");
}

function generateEtag(buffer) {
  const hash = createHash("sha256").update(buffer).digest("hex");
  return `"${hash}"`;
}

function gzipDeterministic(buffer) {
  const compressed = gzipSync(buffer, { level: 9 });

  // zlib writes the gzip OS header byte based on the current platform.
  // Normalize it so the generated header is reproducible across macOS/Linux.
  if (compressed.length > GZIP_HEADER_OS_OFFSET) {
    compressed[GZIP_HEADER_OS_OFFSET] = GZIP_OS_UNIX;
  }

  return compressed;
}

function getMimeType(filePath) {
  const ext = extname(filePath).toLowerCase();
  const mimeTypes = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
    ".eot": "application/vnd.ms-fontobject",
    ".webp": "image/webp",
    ".wasm": "application/wasm",
  };
  return mimeTypes[ext] || "application/octet-stream";
}

function hasHashInFilename(filename) {
  // Match patterns like: name-a1b2c3d4.js, name-A1B2-3C4D.css, etc.
  // Vite generates hashes like: [name]-[hash].js where hash contains alphanumeric chars and hyphens
  // Match: player-JMsuKSSN.js, status-BtNSEM5x.js, use-locale-BAU8V-1E.css
  return /-[a-zA-Z0-9_-]{6,}\.(js|css|png|jpg|svg|woff2?|wasm)$/i.test(filename);
}

function shouldGzip(filePath) {
  return extname(filePath).toLowerCase() !== ".html";
}

function scanDirectory(dir, baseDir = dir) {
  const files = [];
  const entries = readdirSync(dir).sort();

  for (const entry of entries) {
    const fullPath = join(dir, entry);
    const stat = statSync(fullPath);

    if (stat.isDirectory()) {
      files.push(...scanDirectory(fullPath, baseDir));
    } else if (stat.isFile()) {
      const relativePath = `/${relative(baseDir, fullPath).replace(/\\/g, "/")}`;
      files.push({
        path: relativePath,
        fullPath,
        hasHash: hasHashInFilename(entry),
      });
    }
  }

  return files;
}

function sanitizeVarName(path) {
  // Convert path to valid C identifier
  // /status.html -> data_status_html
  // /assets/main-abc123.js -> data_assets_main_abc123_js
  return `data_${path.replace(/[^a-zA-Z0-9]/g, "_")}`;
}

function main() {
  const [, , distDir, outputPath] = argv;
  if (!distDir || !outputPath) {
    usage();
    exit(1);
  }

  console.log(`Scanning directory: ${distDir}`);
  const files = scanDirectory(distDir);
  console.log(`Found ${files.length} files`);

  const embeddedFiles = [];
  let totalCompressedSize = 0;
  let totalOriginalSize = 0;

  // Process each file
  for (const file of files) {
    const content = readFileSync(file.fullPath);
    const gzipEncoded = shouldGzip(file.path);
    const embeddedContent = gzipEncoded ? gzipDeterministic(content) : content;
    const varName = sanitizeVarName(file.path);
    const mimeType = getMimeType(file.path);
    const etag = file.hasHash || !gzipEncoded ? null : generateEtag(embeddedContent);

    totalOriginalSize += content.length;
    totalCompressedSize += embeddedContent.length;

    embeddedFiles.push({
      path: file.path,
      varName,
      mimeType,
      etag,
      content: embeddedContent,
      hasHash: file.hasHash,
      gzipEncoded,
    });

    const cacheType = file.hasHash ? "immutable" : gzipEncoded ? "etag" : "runtime";
    console.log(
      `  ${file.path} (${(content.length / 1000).toFixed(1)}KB → ${(embeddedContent.length / 1000).toFixed(1)}KB, ${cacheType})`,
    );
  }

  console.log(
    `\nTotal size: ${(totalOriginalSize / 1000).toFixed(1)}KB → ${(totalCompressedSize / 1000).toFixed(1)}KB ` +
      `(${((1 - totalCompressedSize / totalOriginalSize) * 100).toFixed(1)}% reduction)`,
  );

  // Generate header file
  const lines = [
    "#ifndef EMBEDDED_WEB_DATA_H",
    "#define EMBEDDED_WEB_DATA_H",
    "",
    "#include <stdint.h>",
    "#include <stddef.h>",
    "#include <stdbool.h>",
    "",
    "/* Embedded web files - auto-generated, do not edit manually */",
    "",
  ];

  // Declare data arrays for each file
  for (const file of embeddedFiles) {
    lines.push(
      `/* ${file.path} (${(file.content.length / 1000).toFixed(1)}KB ${file.gzipEncoded ? "gzipped" : "plain"}) */`,
    );
    lines.push(`static const uint8_t ${file.varName}[] = {`);
    lines.push(formatByteArray(file.content));
    lines.push("};");
    lines.push("");
  }

  // Include embedded_web.h for the type definition
  lines.push("/* Include embedded_web.h for embedded_file_t definition */");
  lines.push('#include "embedded_web.h"');
  lines.push("");

  // Define the array
  lines.push("static const embedded_file_t embedded_files[] = {");
  for (const file of embeddedFiles) {
    const etagStr = file.etag ? file.etag : "NULL";
    const hasHashStr = file.hasHash ? "true" : "false";
    const gzipEncodedStr = file.gzipEncoded ? "true" : "false";
    lines.push(
      `    {"${file.path}", "${file.mimeType}", ${etagStr}, ${file.varName}, sizeof(${file.varName}), ${hasHashStr}, ${gzipEncodedStr}},`,
    );
  }
  lines.push("};");
  lines.push("");

  lines.push(`#define EMBEDDED_FILES_COUNT ${embeddedFiles.length}`);
  lines.push("");
  lines.push("#endif /* EMBEDDED_WEB_DATA_H */");
  lines.push("");

  writeFileSync(outputPath, lines.join("\n"), "utf8");
  console.log(`\nGenerated ${outputPath}`);
}

main();
