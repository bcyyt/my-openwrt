"""
Pytest configuration and shared fixtures for rtp2httpd E2E tests.

Run all tests (parallel by default):
    ./scripts/run-e2e.sh

Run sequentially:
    ./scripts/run-e2e.sh -p 1

Run a single suite:
    uv run pytest e2e/test_m3u.py -v

Run tests matching a keyword:
    uv run pytest e2e/ -k "etag" -v

Skip slow / multicast tests:
    uv run pytest e2e/ -m "not multicast" -v
"""

import sys
from pathlib import Path

import pytest

# Make helpers importable from test modules
sys.path.insert(0, str(Path(__file__).parent))

from helpers import (
    BINARY_PATH,
    MockFCCServer,
    MockHTTPUpstream,
    MockHTTPUpstreamSilent,
    MockRTSPServer,
    MockRTSPServerNoMedia,
    MockRTSPServerNoTeardownResponse,
    MockRTSPServerSilent,
    MockRTSPServerUDP,
    MulticastSender,
    R2HProcess,
    find_free_port,
    find_free_udp_port,
)

# ---------------------------------------------------------------------------
# Markers
# ---------------------------------------------------------------------------


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "multicast: requires multicast on loopback")
    config.addinivalue_line("markers", "rtsp: requires mock RTSP server")
    config.addinivalue_line("markers", "fcc: requires mock FCC server")
    config.addinivalue_line("markers", "http_proxy: requires mock HTTP upstream")
    config.addinivalue_line("markers", "slow: tests that take a bit longer")


# ---------------------------------------------------------------------------
# Session-scoped fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def r2h_binary() -> Path:
    """Return the path to rtp2httpd, or skip the session if it is missing."""
    if not BINARY_PATH.exists():
        pytest.skip(
            f"rtp2httpd binary not found at {BINARY_PATH}.  "
            "Build the project first (cmake -B build && cmake --build build)."
        )
    return BINARY_PATH


# ---------------------------------------------------------------------------
# Function-scoped convenience fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def free_port():
    return find_free_port()


@pytest.fixture()
def free_udp_port():
    return find_free_udp_port()


@pytest.fixture()
def r2h_server(r2h_binary, free_port):
    """Start rtp2httpd with sensible test defaults (no config, debug log)."""
    proc = R2HProcess(
        r2h_binary,
        free_port,
        extra_args=["-v", "4", "-m", "100"],
    )
    proc.start()
    yield proc
    proc.stop()


@pytest.fixture()
def multicast_sender():
    """Yield a started MulticastSender; stops it on teardown."""
    sender = MulticastSender()
    sender.start()
    yield sender
    sender.stop()


@pytest.fixture()
def mock_rtsp():
    """Yield a started MockRTSPServer (TCP interleaved); stops on teardown."""
    srv = MockRTSPServer()
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture()
def mock_rtsp_udp():
    """Yield a started MockRTSPServerUDP; stops on teardown."""
    srv = MockRTSPServerUDP()
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture()
def mock_fcc():
    """Yield a started MockFCCServer; stops on teardown."""
    srv = MockFCCServer()
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture()
def mock_http():
    """Yield a started MockHTTPUpstream (empty routes); stops on teardown."""
    srv = MockHTTPUpstream()
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture()
def mock_rtsp_silent():
    """Yield a started MockRTSPServerSilent; stops on teardown."""
    srv = MockRTSPServerSilent()
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture()
def mock_rtsp_no_media():
    """Yield a started MockRTSPServerNoMedia; stops on teardown."""
    srv = MockRTSPServerNoMedia()
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture()
def mock_rtsp_no_teardown():
    """Yield a started MockRTSPServerNoTeardownResponse; stops on teardown."""
    srv = MockRTSPServerNoTeardownResponse()
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture()
def mock_http_silent():
    """Yield a started MockHTTPUpstreamSilent; stops on teardown."""
    srv = MockHTTPUpstreamSilent()
    srv.start()
    yield srv
    srv.stop()
