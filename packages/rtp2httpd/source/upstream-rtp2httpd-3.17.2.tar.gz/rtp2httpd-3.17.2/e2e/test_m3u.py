"""
E2E tests for M3U playlist transformation.

Tests cover inline M3U (via [services] section), external M3U (via file://),
URL rewriting, ETag caching, and edge cases.
"""

import os
import tempfile
import time

import pytest
from helpers import (
    MockRTSPServer,
    R2HProcess,
    assert_etag_cache_behavior,
    extract_catchup_source,
    find_free_port,
    http_get,
    http_request,
    make_m3u_rtsp_config,
    stream_get,
)

# ---------------------------------------------------------------------------
# Inline M3U (from [services] config section)
# ---------------------------------------------------------------------------


class TestInlineM3U:
    """M3U content defined directly in the [services] section."""

    def test_inline_m3u_served(self, r2h_binary):
        """An inline M3U should be returned at /playlist.m3u."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4
maxclients = 10

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Channel One
rtp://239.0.0.1:1234
#EXTINF:-1,Channel Two
rtp://239.0.0.2:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _hdrs, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()

            assert status == 200
            assert "#EXTM3U" in text
            assert "Channel One" in text
            assert "Channel Two" in text
        finally:
            r2h.stop()

    def test_inline_m3u_content_type(self, r2h_binary):
        """Playlist should be served as audio/x-mpegurl."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Test
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, hdrs, _ = http_get("127.0.0.1", port, "/playlist.m3u")
            assert status == 200
            ct = hdrs.get("Content-Type", "")
            assert "mpegurl" in ct.lower() or "m3u" in ct.lower()
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# External M3U via file://
# ---------------------------------------------------------------------------


class TestExternalM3UFile:
    """M3U loaded from a local file via -M file://."""

    def _write_m3u(self, content: str) -> str:
        fd, path = tempfile.mkstemp(suffix=".m3u", prefix="r2h_test_")
        with os.fdopen(fd, "w") as f:
            f.write(content)
        return path

    def test_external_file_m3u(self, r2h_binary):
        m3u_path = self._write_m3u("#EXTM3U\n#EXTINF:-1,File Channel\nrtp://239.10.0.1:5000\n")
        port = find_free_port()
        r2h = R2HProcess(
            r2h_binary,
            port,
            extra_args=["-v", "4", "-m", "100", "-M", f"file://{m3u_path}"],
        )
        try:
            r2h.start()
            # External M3U may load asynchronously, give it a moment
            time.sleep(0.2)
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "File Channel" in text
        finally:
            r2h.stop()
            os.unlink(m3u_path)

    def test_external_m3u_with_fec(self, r2h_binary):
        """FEC query parameter in M3U source should be preserved internally.
        The transformed URL may or may not include the FEC param (it is stored
        in the service config).  We just verify the service is listed."""
        m3u_path = self._write_m3u("#EXTM3U\n#EXTINF:-1,FEC Stream\nrtp://239.10.0.1:5000?fec=5002\n")
        port = find_free_port()
        r2h = R2HProcess(
            r2h_binary,
            port,
            extra_args=["-v", "4", "-m", "100", "-M", f"file://{m3u_path}"],
        )
        try:
            r2h.start()
            time.sleep(0.2)
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "FEC Stream" in text
        finally:
            r2h.stop()
            os.unlink(m3u_path)


# ---------------------------------------------------------------------------
# URL rewriting
# ---------------------------------------------------------------------------


class TestM3UURLRewriting:
    """Verify that source URLs are rewritten to go through rtp2httpd."""

    def test_rtp_url_rewritten(self, r2h_binary):
        """rtp:// URLs should be rewritten to http://<server>/<name>."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,My Channel
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            # Should NOT contain the raw rtp:// URL
            assert "rtp://239.0.0.1:1234" not in text
            # Should contain a proxied HTTP URL
            assert "http://" in text
            assert "My Channel" in text
        finally:
            r2h.stop()

    def test_rtsp_url_rewritten(self, r2h_binary):
        """rtsp:// URLs should also be rewritten."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,RTSP Channel
rtsp://10.0.0.1:554/live
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "rtsp://10.0.0.1:554" not in text
            assert "RTSP Channel" in text
        finally:
            r2h.stop()

    def test_http_url_preserved_or_rewritten(self, r2h_binary):
        """http:// source URLs should either be rewritten through the proxy
        or preserved, depending on implementation."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Web Stream
http://example.com:8080/live.m3u8
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "Web Stream" in text
        finally:
            r2h.stop()

    def test_relative_path_output_with_app_path_prefix(self, r2h_binary):
        """When enabled, playlist URLs should omit scheme/host and keep app-path-prefix."""
        port = find_free_port()
        app_prefix = "/app/rtp2httpd"
        config = f"""\
[global]
verbosity = 4
app-path-prefix = {app_prefix}
use-relative-path-in-m3u = yes

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Relative Channel
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, f"{app_prefix}/playlist.m3u")
            text = body.decode()
            urls = [line for line in text.splitlines() if "Relative%20Channel" in line]

            assert status == 200
            assert len(urls) == 1
            assert urls[0] == f"{app_prefix}/Relative%20Channel"
            assert "http://" not in text
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# ETag and conditional GET
# ---------------------------------------------------------------------------


class TestM3UETag:
    """Verify ETag-based caching on the playlist endpoint."""

    def _start_with_m3u(self, r2h_binary, port):
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,ETag Test
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        r2h.start()
        return r2h

    def test_etag_cache_behavior(self, r2h_binary):
        """Playlist endpoint should implement stable ETag cache semantics."""
        port = find_free_port()
        r2h = self._start_with_m3u(r2h_binary, port)
        try:
            assert_etag_cache_behavior("127.0.0.1", port, "/playlist.m3u")
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# Duplicate service names
# ---------------------------------------------------------------------------


class TestM3UDuplicateNames:
    """Duplicate service names should be de-duplicated with /N suffixes."""

    def test_duplicate_names(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Same Name
rtp://239.0.0.1:1234
#EXTINF:-1,Same Name
rtp://239.0.0.2:1234
#EXTINF:-1,Same Name
rtp://239.0.0.3:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            # Each "Same Name" entry should have a distinct URL
            lines = [line for line in text.splitlines() if line.startswith("http")]
            assert len(lines) >= 3, "Expected at least 3 rewritten URLs"
            assert len(set(lines)) == len(lines), "URLs should be unique"
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# Catchup / timeshift attributes
# ---------------------------------------------------------------------------


class TestM3UCatchup:
    """Catchup attributes in EXTINF should be preserved."""

    def test_catchup_source_preserved(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="default" catchup-source="rtsp://10.0.0.50:554/playback?seek={{utc:YmdHMS}}-{{utcend:YmdHMS}}",Catchup Ch
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert 'catchup="default"' in text or "catchup-source=" in text
            assert "Catchup Ch" in text
        finally:
            r2h.stop()


class TestM3UCatchupAppend:
    """Append catchup fragments should be promoted into direct catchup proxy URLs."""

    def test_question_mark_preserved_no_dynamic_query(self, r2h_binary):
        """Append catchup with '?' should become a direct proxy catchup URL."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="append" catchup-source="?playseek={{utc}}-{{utcend}}",QMark NoDyn Ch
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "QMark NoDyn Ch" in text
            line, catchup_source = extract_catchup_source(text, "QMark NoDyn Ch")
            assert 'catchup="default"' in line, f"Expected transformed append catchup to become default, got:\n{line}"
            assert "/QMark%20NoDyn%20Ch/catchup?playseek={utc}-{utcend}" in catchup_source, (
                f"Expected direct catchup proxy URL, got:\n{catchup_source}"
            )
        finally:
            r2h.stop()

    def test_ampersand_adjusted_to_question_no_dynamic_query(self, r2h_binary):
        """Append catchup with '&' should also become a direct proxy catchup URL."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="append" catchup-source="&playseek={{utc}}-{{utcend}}",Amp NoDyn Ch
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "Amp NoDyn Ch" in text
            line, catchup_source = extract_catchup_source(text, "Amp NoDyn Ch")
            assert 'catchup="default"' in line, f"Expected transformed append catchup to become default, got:\n{line}"
            assert "/Amp%20NoDyn%20Ch/catchup?playseek={utc}-{utcend}" in catchup_source, (
                f"Expected direct catchup proxy URL, got:\n{catchup_source}"
            )
        finally:
            r2h.stop()

    def test_ampersand_preserved_with_dynamic_query(self, r2h_binary):
        """Append catchup should use direct proxy URL even when main proxy URL has dynamic query."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="append" catchup-source="&playseek={{utc}}-{{utcend}}",Amp Dyn Ch
http://10.10.10.1:8888/live/stream.m3u8?begin={{utc}}
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "Amp Dyn Ch" in text
            line, catchup_source = extract_catchup_source(text, "Amp Dyn Ch")
            assert 'catchup="default"' in line, f"Expected transformed append catchup to become default, got:\n{line}"
            assert "/Amp%20Dyn%20Ch/catchup?playseek={utc}-{utcend}" in catchup_source, (
                f"Expected direct catchup proxy URL, got:\n{catchup_source}"
            )
            assert "http://127.0.0.1:" in line
        finally:
            r2h.stop()

    def test_question_adjusted_to_ampersand_with_dynamic_query(self, r2h_binary):
        """Append catchup with '?' should still use a direct proxy catchup URL."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="append" catchup-source="?playseek={{utc}}-{{utcend}}",QMark Dyn Ch
http://10.10.10.1:8888/live/stream.m3u8?begin={{utc}}
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "QMark Dyn Ch" in text
            line, catchup_source = extract_catchup_source(text, "QMark Dyn Ch")
            assert 'catchup="default"' in line, f"Expected transformed append catchup to become default, got:\n{line}"
            assert "/QMark%20Dyn%20Ch/catchup?playseek={utc}-{utcend}" in catchup_source, (
                f"Expected direct catchup proxy URL, got:\n{catchup_source}"
            )
        finally:
            r2h.stop()

    def test_static_query_does_not_count_as_dynamic(self, r2h_binary):
        """Static main-query parameters should not prevent append catchup promotion."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="append" catchup-source="&playseek={{utc}}-{{utcend}}",Static Query Ch
http://10.10.10.1:8888/live/stream.m3u8?token=abc
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "Static Query Ch" in text
            line, catchup_source = extract_catchup_source(text, "Static Query Ch")
            assert 'catchup="default"' in line, f"Expected transformed append catchup to become default, got:\n{line}"
            assert "/Static%20Query%20Ch/catchup?playseek={utc}-{utcend}" in catchup_source, (
                f"Expected direct catchup proxy URL, got:\n{catchup_source}"
            )
        finally:
            r2h.stop()

    def test_no_prefix_catchup_is_promoted(self, r2h_binary):
        """Append catchup-source without a leading separator should still become a direct proxy URL."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="append" catchup-source="playseek={{utc}}-{{utcend}}",No Prefix Ch
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "No Prefix Ch" in text
            line, catchup_source = extract_catchup_source(text, "No Prefix Ch")
            assert 'catchup="default"' in line, f"Expected transformed append catchup to become default, got:\n{line}"
            assert "/No%20Prefix%20Ch/catchup?playseek={utc}-{utcend}" in catchup_source, (
                f"Expected direct catchup proxy URL, got:\n{catchup_source}"
            )
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# TVG URL in header
# ---------------------------------------------------------------------------


class TestM3UTvgUrl:
    """x-tvg-url attribute in #EXTM3U header should be preserved."""

    def test_tvg_url(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U x-tvg-url="http://example.com/epg.xml.gz"
#EXTINF:-1 tvg-id="CH1" tvg-name="Channel 1",Channel 1
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "tvg-id" in text or "tvg-name" in text
            assert "Channel 1" in text
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# EXTINF metadata
# ---------------------------------------------------------------------------


class TestM3UMetadata:
    """EXTINF metadata (tvg-id, group-title, logo) should be preserved."""

    def test_group_title_preserved(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 tvg-id="CCTV1" tvg-name="CCTV-1" tvg-logo="http://example.com/logo.png" group-title="Central",CCTV-1
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert 'group-title="Central"' in text
            assert "CCTV-1" in text
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# Special characters in service names
# ---------------------------------------------------------------------------


class TestM3USpecialChars:
    """Service names with Chinese / special characters should be URL-encoded
    in the transformed playlist but accessible when decoded."""

    def test_chinese_service_name(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,\u5e7f\u4e1c\u536b\u89c6
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            # The service name should appear (either encoded or literal)
            assert "\u5e7f\u4e1c\u536b\u89c6" in text or "%E5%B9%BF" in text
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# Mixed protocol sources
# ---------------------------------------------------------------------------


class TestM3UMixedSources:
    """Playlist with a mix of rtp://, rtsp://, and http:// sources."""

    def test_mixed_sources(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,RTP Channel
rtp://239.0.0.1:1234
#EXTINF:-1,RTSP Channel
rtsp://10.0.0.1:554/live
#EXTINF:-1,HTTP Channel
http://example.com:8080/stream.m3u8
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "RTP Channel" in text
            assert "RTSP Channel" in text
            assert "HTTP Channel" in text
            # Each should have a distinct URL line
            url_lines = [line for line in text.splitlines() if line.startswith("http")]
            assert len(url_lines) >= 3
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# Named service access (via M3U service name)
# ---------------------------------------------------------------------------


class TestM3UServiceAccess:
    """Services defined in M3U should be accessible by name."""

    def test_service_head_by_name(self, r2h_binary):
        """HEAD request to a named service should return 200."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Test Service
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_request(
                "127.0.0.1",
                port,
                "HEAD",
                "/Test%20Service",
                timeout=3.0,
            )
            assert status == 200
            assert len(body) == 0
        finally:
            r2h.stop()

    def test_service_unknown_name_404(self, r2h_binary):
        """A service name not in M3U should return 404."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Known
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, _ = http_get("127.0.0.1", port, "/Unknown")
            assert status == 404
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# Label suffix ($label) stripping
# ---------------------------------------------------------------------------


class TestM3ULabelSuffix:
    """The $label suffix in URLs is for UI display only and should be
    stripped before service matching."""

    def test_label_suffix_stripped(self, r2h_binary):
        """HEAD /ServiceName$label should match ServiceName."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,MyChannel
rtp://239.0.0.1:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            # With $label suffix
            status, _, _ = http_request(
                "127.0.0.1",
                port,
                "HEAD",
                "/MyChannel$HD",
                timeout=3.0,
            )
            assert status == 200
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# External M3U via HTTP URL
# ---------------------------------------------------------------------------


class TestM3UHTTPExternal:
    """M3U loaded from an HTTP URL via -M http://..."""

    def test_external_http_m3u(self, r2h_binary):
        """Loading M3U from an HTTP URL should populate the playlist."""
        from helpers import MockHTTPUpstream

        m3u_content = "#EXTM3U\n#EXTINF:-1,HTTP Loaded Channel\nrtp://239.10.0.1:5000\n"
        upstream = MockHTTPUpstream(
            routes={
                "/channels.m3u": {
                    "status": 200,
                    "body": m3u_content,
                    "headers": {"Content-Type": "audio/x-mpegurl"},
                },
            }
        )
        upstream.start()

        port = find_free_port()
        r2h = R2HProcess(
            r2h_binary,
            port,
            extra_args=[
                "-v",
                "4",
                "-m",
                "100",
                "-M",
                f"http://127.0.0.1:{upstream.port}/channels.m3u",
            ],
        )
        try:
            r2h.start()
            time.sleep(0.5)  # allow async M3U fetch via curl
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "HTTP Loaded Channel" in text
        finally:
            r2h.stop()
            upstream.stop()

    def test_external_http_m3u_url_rewritten(self, r2h_binary):
        """URLs in externally loaded HTTP M3U should be rewritten."""
        from helpers import MockHTTPUpstream

        m3u_content = (
            "#EXTM3U\n"
            "#EXTINF:-1,Ext RTSP Channel\n"
            "rtsp://192.168.1.1:554/live\n"
            "#EXTINF:-1,Ext RTP Channel\n"
            "rtp://239.10.0.1:5000\n"
        )
        upstream = MockHTTPUpstream(
            routes={
                "/list.m3u": {
                    "status": 200,
                    "body": m3u_content,
                    "headers": {"Content-Type": "audio/x-mpegurl"},
                },
            }
        )
        upstream.start()

        port = find_free_port()
        r2h = R2HProcess(
            r2h_binary,
            port,
            extra_args=[
                "-v",
                "4",
                "-m",
                "100",
                "-M",
                f"http://127.0.0.1:{upstream.port}/list.m3u",
            ],
        )
        try:
            r2h.start()
            time.sleep(0.5)
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            # URLs should be rewritten to go through rtp2httpd
            assert "rtsp://192.168.1.1:554" not in text
            assert "rtp://239.10.0.1:5000" not in text
            assert "http://" in text
        finally:
            r2h.stop()
            upstream.stop()


# ---------------------------------------------------------------------------
# Multiple sources per channel with $label suffix in M3U
# ---------------------------------------------------------------------------


class TestM3UMultiLabel:
    """M3U with multiple sources for the same channel using $label."""

    def test_multi_label_distinct_urls(self, r2h_binary):
        """Channels with same name but different $label should produce
        distinct URLs in the playlist."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,CCTV-1
rtp://239.0.0.1:1234$HD
#EXTINF:-1,CCTV-1
rtp://239.0.0.2:1234$SD
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert "CCTV-1" in text
            # Should have URLs for both sources
            url_lines = [line for line in text.splitlines() if line.startswith("http")]
            assert len(url_lines) >= 2, f"Expected at least 2 URLs for multi-label, got {len(url_lines)}"
            assert len(set(url_lines)) == len(url_lines), "URLs should be unique"
        finally:
            r2h.stop()

    def test_multi_label_urls_contain_labels(self, r2h_binary):
        """The playlist URLs for multi-label channels should reference labels."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,TestCh
rtp://239.0.0.1:1234$HD
#EXTINF:-1,TestCh
rtp://239.0.0.2:1234$SD
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            # Both EXTINF entries should reference TestCh
            assert text.count("TestCh") >= 2
        finally:
            r2h.stop()


class TestM3UMultiURLPerEXTINF:
    """A single #EXTINF followed by several URL lines describes one channel
    with multiple sources. Every URL must get its own service, and the
    transformed playlist must keep the same shape: one EXTINF line followed
    by the rewritten URLs."""

    def test_shape_preserved_and_every_url_rewritten(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 group-title="Group 1",Channel 3
rtp://239.0.0.3:1234$Line 1
rtp://239.0.0.4:1234$Line 2
#EXTINF:-1 group-title="Group 1",Channel 4
rtp://239.0.0.5:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            assert status == 200
            lines = [line for line in body.decode().splitlines() if line]

            extinf_lines = [line for line in lines if line.startswith("#EXTINF")]
            url_lines = [line for line in lines if line.startswith("http")]
            assert extinf_lines == [
                '#EXTINF:-1 group-title="Group 1",Channel 3',
                '#EXTINF:-1 group-title="Group 1",Channel 4',
            ]
            assert len(url_lines) == 3
            assert url_lines[0].endswith("/Channel%203/Line%201$Line 1")
            assert url_lines[1].endswith("/Channel%203/Line%202$Line 2")
            assert url_lines[2].endswith("/Channel%204")
            # Input shape is kept: one EXTINF, then its URLs, then the next entry
            assert lines[1:] == [
                extinf_lines[0],
                url_lines[0],
                url_lines[1],
                extinf_lines[1],
                url_lines[2],
            ]
            # The two entries are still separated by exactly one blank line
            raw = body.decode()
            assert f"{url_lines[0]}\n{url_lines[1]}\n\n{extinf_lines[1]}\n" in raw

            for path in ("/Group%201/Channel%203/Line%201", "/Group%201/Channel%203/Line%202"):
                head_status, _, _ = http_request("127.0.0.1", port, "HEAD", path)
                assert head_status == 200, f"{path} should resolve to a service"
        finally:
            r2h.stop()

    def test_unlabeled_urls_get_unique_service_paths(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,News
rtp://239.0.0.1:1234
rtp://239.0.0.2:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            assert status == 200
            text = body.decode()
            url_lines = [line for line in text.splitlines() if line.startswith("http")]
            assert len(url_lines) == 2
            assert len(set(url_lines)) == 2, "each source needs its own service path"
            assert text.count("#EXTINF:-1,News") == 1
        finally:
            r2h.stop()

    def test_repeated_extinf_input_keeps_repeated_extinf_output(self, r2h_binary):
        """The converter mirrors the input: repeated EXTINF stays repeated."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,News
rtp://239.0.0.1:1234$HD
#EXTINF:-1,News
rtp://239.0.0.2:1234$SD
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            assert status == 200
            lines = [line for line in body.decode().splitlines() if line]
            assert lines[1:] == [
                "#EXTINF:-1,News",
                lines[2],
                "#EXTINF:-1,News",
                lines[4],
            ]
            assert lines[2].endswith("/News/HD$HD")
            assert lines[4].endswith("/News/SD$SD")
        finally:
            r2h.stop()

    def test_catchup_rewritten_once_for_multi_url_entry(self, r2h_binary):
        """catchup-source lives on the single EXTINF line, so it is rewritten
        once (against the first source) and both URLs follow it."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1 catchup="default" catchup-source="rtsp://10.0.0.50:554/playback?seek={{utc:YmdHMS}}-{{utcend:YmdHMS}}",Catchup Ch
rtp://239.0.0.1:1234$HD
rtp://239.0.0.2:1234$SD
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            text = body.decode()
            assert status == 200
            assert text.count("#EXTINF") == 1
            _, catchup_url = extract_catchup_source(text, "Catchup Ch")
            assert "/Catchup%20Ch/HD/catchup" in catchup_url
            url_lines = [line for line in text.splitlines() if line.startswith("http")]
            assert [line.rsplit("/", 1)[-1] for line in url_lines] == ["HD$HD", "SD$SD"]
            for path in ("/Catchup%20Ch/HD", "/Catchup%20Ch/SD"):
                head_status, _, _ = http_request("127.0.0.1", port, "HEAD", path)
                assert head_status == 200, f"{path} should resolve to a service"
        finally:
            r2h.stop()

    def test_stray_text_after_url_is_not_treated_as_source(self, r2h_binary):
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4

[bind]
* {port}

[services]
#EXTM3U
#EXTINF:-1,Solo
rtp://239.0.0.1:1234
this is not a url
#EXTINF:-1,Next
rtp://239.0.0.2:1234
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        try:
            r2h.start()
            status, _, body = http_get("127.0.0.1", port, "/playlist.m3u")
            assert status == 200
            text = body.decode()
            assert "this is not a url" not in text
            assert text.count("#EXTINF") == 2
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# M3U-configured service + request query merge mechanism
# ---------------------------------------------------------------------------


_STREAM_TIMEOUT = 20.0


class TestM3UQueryMerge:
    """Generic query-merge mechanism for M3U-configured services."""

    @pytest.mark.parametrize(
        "param_name,configured_value,request_value",
        [
            pytest.param("r2h-ifname", "configured_iface", "request_iface", id="r2h-ifname"),
            pytest.param("r2h-ifname-fcc", "configured_fcc_iface", "request_fcc_iface", id="r2h-ifname-fcc"),
        ],
    )
    def test_request_overrides_configured_via_merged_url_log(
        self, r2h_binary, param_name, configured_value, request_value
    ):
        """request-side r2h-ifname / r2h-ifname-fcc must win over the configured
        value. Both are stripped from the upstream URI, so we observe the merge
        result via the rtp2httpd debug log."""
        r2h_port = find_free_port()
        rtsp = MockRTSPServer(num_packets=500)
        rtsp.start()
        try:
            config = make_m3u_rtsp_config(
                r2h_port, rtsp.port, f"MergeWinsLog_{param_name}", f"?{param_name}={configured_value}"
            )
            r2h = R2HProcess(r2h_binary, r2h_port, config_content=config, capture_log=True)
            r2h.start()
            try:
                # Bogus interface names — rtp2httpd logs a bind error but the
                # request still goes through; we only inspect the merged URL.
                stream_get(
                    "127.0.0.1",
                    r2h_port,
                    f"/MergeWinsLog_{param_name}?{param_name}={request_value}",
                    read_bytes=4096,
                    timeout=_STREAM_TIMEOUT,
                )

                log = r2h.read_log()
                merged_lines = [line for line in log.splitlines() if "merged URL:" in line]
                assert merged_lines, f"expected a 'merged URL:' debug log line; got log:\n{log}"
                merged_line = merged_lines[-1]
                assert f"{param_name}={request_value}" in merged_line, merged_line
                assert f"{param_name}={configured_value}" not in merged_line, merged_line
            finally:
                r2h.stop()
        finally:
            rtsp.stop()

    def test_merged_url_overflow_returns_500(self, r2h_binary):
        """When the merged URL exceeds HTTP_URL_BUFFER_SIZE, the merge layer
        must return NULL and the request must surface as HTTP 500 — never
        silently fall back to the unmerged configured URL."""
        r2h_port = find_free_port()
        rtsp = MockRTSPServer(num_packets=500)
        rtsp.start()
        try:
            # ~1200 bytes per side guarantees the merged URL exceeds 2048.
            configured_pad = "padconfigured=" + ("a" * 1200)
            request_pad = "padrequest=" + ("b" * 1200)
            config = make_m3u_rtsp_config(r2h_port, rtsp.port, "OverflowMerge", "?" + configured_pad)
            r2h = R2HProcess(r2h_binary, r2h_port, config_content=config, capture_log=True)
            r2h.start()
            try:
                status, _, _ = stream_get(
                    "127.0.0.1",
                    r2h_port,
                    "/OverflowMerge?playseek=20240101120000-20240101130000&" + request_pad,
                    read_bytes=4096,
                    timeout=_STREAM_TIMEOUT,
                )
                assert status == 500, status
                # Pin the failure to the merge-overflow path — distinguishes it
                # from any unrelated 500 (e.g. RTSP teardown).
                assert "Merged RTSP URL too long" in r2h.read_log()
            finally:
                r2h.stop()
        finally:
            rtsp.stop()
