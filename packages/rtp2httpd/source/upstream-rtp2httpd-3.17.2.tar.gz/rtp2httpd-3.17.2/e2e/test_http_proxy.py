"""
E2E tests for HTTP reverse proxy.

These tests start a mock HTTP upstream, point rtp2httpd at it via
/http/127.0.0.1:<port>/..., and verify responses are correctly proxied.
"""

import time

import pytest
from helpers import (
    LOOPBACK_IF,
    MCAST_ADDR,
    MockHTTPUpstream,
    MockHTTPUpstreamSilent,
    MockRTSPServer,
    MulticastSender,
    R2HProcess,
    find_free_port,
    find_free_udp_port,
    http_get,
    stream_get,
)

pytestmark = pytest.mark.http_proxy
APP_PREFIX = "/app/rtp2httpd"


# ---------------------------------------------------------------------------
# Module-scoped shared rtp2httpd instance
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def shared_r2h(r2h_binary):
    """A single rtp2httpd instance shared by all HTTP proxy tests."""
    port = find_free_port()
    r2h = R2HProcess(r2h_binary, port, extra_args=["-v", "4", "-m", "100"])
    r2h.start()
    yield r2h
    r2h.stop()


# ---------------------------------------------------------------------------
# Basic proxy functionality
# ---------------------------------------------------------------------------


class TestBasicProxy:
    """Verify that rtp2httpd can proxy simple HTTP requests."""

    def test_proxy_200(self, shared_r2h):
        """A proxied path returning 200 should be relayed to the client."""
        upstream = MockHTTPUpstream(
            routes={
                "/hello": {"status": 200, "body": b"world", "headers": {"Content-Type": "text/plain"}},
            }
        )
        upstream.start()
        try:
            status, hdrs, body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/hello",
                timeout=5.0,
            )
            assert status == 200
            assert body == b"world"
            assert not any(name.lower().startswith("r2h-") for name in hdrs)
        finally:
            upstream.stop()

    def test_proxy_404_passthrough(self, shared_r2h):
        """A proxied 404 from the upstream should be forwarded to the client."""
        upstream = MockHTTPUpstream(routes={})  # no routes -> all 404
        upstream.start()
        try:
            status, _, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/missing",
                timeout=5.0,
            )
            assert status == 404
        finally:
            upstream.stop()


# ---------------------------------------------------------------------------
# Content types
# ---------------------------------------------------------------------------


class TestProxyContentType:
    """Verify Content-Type from upstream is preserved."""

    def test_json_content_type(self, shared_r2h):
        upstream = MockHTTPUpstream(
            routes={
                "/api/data": {
                    "status": 200,
                    "body": b'{"key":"value"}',
                    "headers": {"Content-Type": "application/json"},
                },
            }
        )
        upstream.start()
        try:
            status, _hdrs, body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/api/data",
                timeout=5.0,
            )
            assert status == 200
            assert body == b'{"key":"value"}'
        finally:
            upstream.stop()


# ---------------------------------------------------------------------------
# Large response
# ---------------------------------------------------------------------------


class TestProxyLargeBody:
    """Verify a larger payload is proxied completely."""

    @pytest.mark.slow
    def test_large_payload(self, shared_r2h):
        """Verify a 64 KB payload is proxied completely."""
        big_body = b"X" * (64 * 1024)
        upstream = MockHTTPUpstream(
            routes={
                "/big": {"status": 200, "body": big_body, "headers": {"Content-Type": "application/octet-stream"}},
            }
        )
        upstream.start()
        try:
            status, _, body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/big",
                timeout=10.0,
            )
            assert status == 200
            assert len(body) == len(big_body)
        finally:
            upstream.stop()


# ---------------------------------------------------------------------------
# Query parameter forwarding
# ---------------------------------------------------------------------------


class TestProxyQueryParams:
    """Query parameters should be forwarded to the upstream."""

    def test_query_forwarded(self, shared_r2h):
        # The mock doesn't inspect query params, but rtp2httpd should
        # proxy the full URL. We just verify a 200 comes back.
        upstream = MockHTTPUpstream(
            routes={
                "/search": {"status": 200, "body": b"found"},
            }
        )
        upstream.start()
        try:
            status, _, _body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/search?q=test&page=1",
                timeout=5.0,
            )
            assert status == 200
        finally:
            upstream.stop()

    @pytest.mark.parametrize("token_param", ["r2h-token", "R2H-Token"])
    def test_r2h_token_not_forwarded(self, shared_r2h, token_param):
        """r2h-token is local auth metadata and should be stripped before upstream HTTP."""
        upstream = MockHTTPUpstream(
            routes={
                "/search": {"status": 200, "body": b"found"},
            }
        )
        upstream.start()
        try:
            status, _, body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/search?{token_param}=secret-token&q=test",
                timeout=5.0,
            )
            assert status == 200
            assert body == b"found"
            assert upstream.requests_log, "expected upstream HTTP request"
            upstream_path = upstream.requests_log[0]["path"]
            assert "r2h-token" not in upstream_path.lower()
            assert "q=test" in upstream_path
        finally:
            upstream.stop()

    def test_r2h_filename_not_forwarded(self, shared_r2h):
        """r2h-filename is local download metadata and should be stripped before upstream HTTP."""
        upstream = MockHTTPUpstream(
            routes={
                "/search": {"status": 200, "body": b"found"},
            }
        )
        upstream.start()
        try:
            status, headers, body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/search?r2h-filename=clip.ts&q=test",
                timeout=5.0,
            )
            assert status == 200
            assert body == b"found"
            assert "Content-Disposition" not in {key.lower() for key in headers}
            assert upstream.requests_log, "expected upstream HTTP request"
            upstream_path = upstream.requests_log[0]["path"]
            assert "r2h-filename" not in upstream_path.lower()
            assert "q=test" in upstream_path
        finally:
            upstream.stop()


# ---------------------------------------------------------------------------
# Upstream unreachable
# ---------------------------------------------------------------------------


class TestProxyUnreachable:
    """When the upstream is unreachable, rtp2httpd should fail gracefully."""

    def test_upstream_down(self, shared_r2h):
        dead_port = find_free_port()
        status, _, _ = stream_get(
            "127.0.0.1",
            shared_r2h.port,
            f"/http/127.0.0.1:{dead_port}/whatever",
            read_bytes=512,
            timeout=6.0,
        )
        # Should be an error or a closed connection
        assert status in (0, 500, 502, 503)


# ---------------------------------------------------------------------------
# Upstream timeout (accepts connection but never responds)
# ---------------------------------------------------------------------------

# Timeout constant matching C code (3s)
_HTTP_PROXY_TIMEOUT = 3
_TIMEOUT_MIN_FACTOR = 0.8
_TIMEOUT_MAX_FACTOR = 3.0


class TestProxyUpstreamTimeout:
    """When the HTTP upstream accepts but never responds, should time out."""

    @pytest.mark.slow
    def test_http_proxy_response_timeout(self, r2h_binary):
        """MockHTTPUpstreamSilent doesn't respond — should get 503 within timeout."""
        r2h_port = find_free_port()
        r2h = R2HProcess(r2h_binary, r2h_port, extra_args=["-v", "4", "-m", "100"])
        r2h.start()
        try:
            upstream = MockHTTPUpstreamSilent()
            upstream.start()
            try:
                t0 = time.monotonic()
                status, _, _ = stream_get(
                    "127.0.0.1",
                    r2h_port,
                    f"/http/127.0.0.1:{upstream.port}/test",
                    read_bytes=256,
                    timeout=_HTTP_PROXY_TIMEOUT * _TIMEOUT_MAX_FACTOR + 5,
                )
                elapsed = time.monotonic() - t0

                assert status == 503, f"Expected 503, got {status}"
                assert elapsed >= _HTTP_PROXY_TIMEOUT * _TIMEOUT_MIN_FACTOR, f"Timed out too quickly: {elapsed:.1f}s"
                assert elapsed <= _HTTP_PROXY_TIMEOUT * _TIMEOUT_MAX_FACTOR + 2, f"Timed out too slowly: {elapsed:.1f}s"
            finally:
                upstream.stop()
        finally:
            r2h.stop()


# ---------------------------------------------------------------------------
# HTTP proxy with different status codes
# ---------------------------------------------------------------------------


class TestProxyStatusCodes:
    """Verify various upstream HTTP status codes are forwarded."""

    def test_proxy_500(self, shared_r2h):
        upstream = MockHTTPUpstream(
            routes={
                "/err": {"status": 500, "body": b"Internal Error"},
            }
        )
        upstream.start()
        try:
            status, _, _body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/err",
                timeout=5.0,
            )
            assert status == 500
        finally:
            upstream.stop()

    def test_proxy_302_body(self, shared_r2h):
        """rtp2httpd should forward redirects from upstream."""
        upstream = MockHTTPUpstream(
            routes={
                "/redirect": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "http://example.com/new"},
                },
            }
        )
        upstream.start()
        try:
            status, _hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/redirect",
                timeout=5.0,
            )
            assert status == 302
        finally:
            upstream.stop()


# ---------------------------------------------------------------------------
# Redirect Location rewriting
# ---------------------------------------------------------------------------


def _get_location(hdrs: dict) -> str | None:
    """Extract Location header value (case-insensitive lookup)."""
    for k, v in hdrs.items():
        if k.lower() == "location":
            return str(v)
    return None


class TestProxyRedirectLocationRewrite:
    """30x redirect responses should have their Location header rewritten
    so the URL points back through the rtp2httpd proxy."""

    def test_302_location_rewritten(self, shared_r2h):
        """302 Location with http:// URL should be rewritten to /http/... path."""
        upstream = MockHTTPUpstream(
            routes={
                "/old": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "http://10.0.0.1:8080/new/page"},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/old",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location is not None, "Location header missing"
            assert location == "/http/10.0.0.1:8080/new/page"
        finally:
            upstream.stop()

    def test_302_location_rewritten_with_app_path_prefix(self, r2h_binary):
        """Redirect Location should include app-path-prefix when configured."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4
app-path-prefix = {APP_PREFIX}

[bind]
* {port}
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        upstream = MockHTTPUpstream(
            routes={
                "/old": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "http://10.0.0.1:8080/new/page"},
                },
            }
        )
        upstream.start()
        try:
            r2h.start()
            status, hdrs, _ = http_get(
                "127.0.0.1",
                port,
                f"{APP_PREFIX}/http/127.0.0.1:{upstream.port}/old",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location == f"{APP_PREFIX}/http/10.0.0.1:8080/new/page"
        finally:
            r2h.stop()
            upstream.stop()

    def test_301_location_rewritten(self, shared_r2h):
        """301 permanent redirect should also rewrite Location."""
        upstream = MockHTTPUpstream(
            routes={
                "/moved": {
                    "status": 301,
                    "body": b"",
                    "headers": {"Location": "http://10.0.0.1:8080/moved-here"},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/moved",
                timeout=5.0,
            )
            assert status == 301
            location = _get_location(hdrs)
            assert location is not None, "Location header missing"
            assert location == "/http/10.0.0.1:8080/moved-here"
        finally:
            upstream.stop()

    def test_307_location_rewritten(self, shared_r2h):
        """307 temporary redirect should rewrite Location."""
        upstream = MockHTTPUpstream(
            routes={
                "/temp": {
                    "status": 307,
                    "body": b"",
                    "headers": {"Location": "http://10.0.0.1:8080/temp-dest"},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/temp",
                timeout=5.0,
            )
            assert status == 307
            location = _get_location(hdrs)
            assert location is not None, "Location header missing"
            assert location == "/http/10.0.0.1:8080/temp-dest"
        finally:
            upstream.stop()

    def test_redirect_location_preserves_query_string(self, shared_r2h):
        """Query parameters in Location URL should be preserved after rewrite."""
        upstream = MockHTTPUpstream(
            routes={
                "/redir-qs": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "http://10.0.0.1:8080/target?foo=bar&baz=1"},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/redir-qs",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location is not None, "Location header missing"
            assert "/http/10.0.0.1:8080/target?" in location
            assert "foo=bar" in location
            assert "baz=1" in location
        finally:
            upstream.stop()

    def test_redirect_https_location_not_rewritten(self, shared_r2h):
        """https:// Location should NOT be rewritten (not an M3U-recognized scheme)."""
        upstream = MockHTTPUpstream(
            routes={
                "/secure-redir": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "https://example.com/secure"},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/secure-redir",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location is not None, "Location header missing"
            assert location == "https://example.com/secure"
        finally:
            upstream.stop()

    def test_non_redirect_location_not_rewritten(self, shared_r2h):
        """A 200 response with a Location header should NOT rewrite it."""
        upstream = MockHTTPUpstream(
            routes={
                "/ok-with-loc": {
                    "status": 200,
                    "body": b"ok",
                    "headers": {
                        "Location": "http://10.0.0.1:8080/other",
                        "Content-Type": "text/plain",
                    },
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/ok-with-loc",
                timeout=5.0,
            )
            assert status == 200
            location = _get_location(hdrs)
            if location is not None:
                assert location == "http://10.0.0.1:8080/other"
        finally:
            upstream.stop()

    def test_302_rtsp_location_rewritten(self, shared_r2h):
        """302 Location with rtsp:// URL should be rewritten to /rtsp/... path."""
        upstream = MockHTTPUpstream(
            routes={
                "/catchup": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "rtsp://10.0.0.1:1554/iptv/live?auth=token123"},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/catchup",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location == "/rtsp/10.0.0.1:1554/iptv/live?auth=token123"
        finally:
            upstream.stop()

    def test_302_rtsp_location_rewritten_with_app_path_prefix(self, r2h_binary):
        """rtsp:// redirect Location should include app-path-prefix when configured."""
        port = find_free_port()
        config = f"""\
[global]
verbosity = 4
app-path-prefix = {APP_PREFIX}

[bind]
* {port}
"""
        r2h = R2HProcess(r2h_binary, port, config_content=config)
        upstream = MockHTTPUpstream(
            routes={
                "/catchup": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "rtsp://10.0.0.1:1554/iptv/live"},
                },
            }
        )
        upstream.start()
        try:
            r2h.start()
            status, hdrs, _ = http_get(
                "127.0.0.1",
                port,
                f"{APP_PREFIX}/http/127.0.0.1:{upstream.port}/catchup",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location == f"{APP_PREFIX}/rtsp/10.0.0.1:1554/iptv/live"
        finally:
            r2h.stop()
            upstream.stop()

    @pytest.mark.parametrize(
        "upstream_location, expected",
        [
            ("rtp://239.0.0.1:1234", "/rtp/239.0.0.1:1234"),
            ("rtp://239.0.0.1:1234?fcc=10.0.0.2:8027", "/rtp/239.0.0.1:1234?fcc=10.0.0.2:8027"),
            ("udp://239.0.0.1:1234", "/udp/239.0.0.1:1234"),
            ("udp://239.0.0.1:1234?fec=1235", "/udp/239.0.0.1:1234?fec=1235"),
        ],
    )
    def test_302_m3u_scheme_location_rewritten(self, shared_r2h, upstream_location, expected):
        """M3U-recognized rtp:// and udp:// Locations rewrite onto /rtp/ and /udp/."""
        upstream = MockHTTPUpstream(
            routes={
                "/catchup": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": upstream_location},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/catchup",
                timeout=5.0,
            )
            assert status == 302
            assert _get_location(hdrs) == expected
        finally:
            upstream.stop()

    def test_302_relative_location_kept_unchanged(self, shared_r2h):
        """Root-relative Location such as /rtsp/... must be forwarded as-is."""
        upstream = MockHTTPUpstream(
            routes={
                "/catchup": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "/rtsp/10.0.0.1:1554/iptv/live?auth=token123"},
                },
            }
        )
        upstream.start()
        try:
            status, hdrs, _ = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/catchup",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location == "/rtsp/10.0.0.1:1554/iptv/live?auth=token123"
        finally:
            upstream.stop()

    @pytest.mark.rtsp
    def test_302_rtsp_location_rewritten_and_playable(self, shared_r2h):
        """HTTP 302 to rtsp:// should rewrite to /rtsp/... and the client can play it."""
        rtsp = MockRTSPServer(num_packets=50)
        rtsp.start()
        try:
            rtsp_url = f"rtsp://127.0.0.1:{rtsp.port}/iptv/live?auth=token123"
            expected = f"/rtsp/127.0.0.1:{rtsp.port}/iptv/live?auth=token123"
            upstream = MockHTTPUpstream(
                routes={
                    "/catchup": {
                        "status": 302,
                        "body": b"",
                        "headers": {"Location": rtsp_url},
                    },
                }
            )
            upstream.start()
            try:
                status, hdrs, _ = http_get(
                    "127.0.0.1",
                    shared_r2h.port,
                    f"/http/127.0.0.1:{upstream.port}/catchup",
                    timeout=5.0,
                )
                assert status == 302
                location = _get_location(hdrs)
                assert location is not None, "Location header missing"
                assert location == expected

                stream_status, _, body = stream_get(
                    "127.0.0.1",
                    shared_r2h.port,
                    location,
                    read_bytes=4096,
                    timeout=20.0,
                )
                assert stream_status == 200
                assert len(body) > 0, "Expected RTSP stream after following rewritten Location"
            finally:
                upstream.stop()
        finally:
            rtsp.stop()

    @pytest.mark.rtsp
    def test_302_relative_rtsp_location_playable(self, shared_r2h):
        """HTTP 302 to /rtsp/... should be forwarded unchanged and remain playable."""
        rtsp = MockRTSPServer(num_packets=50)
        rtsp.start()
        try:
            expected = f"/rtsp/127.0.0.1:{rtsp.port}/iptv/live?auth=token123"
            upstream = MockHTTPUpstream(
                routes={
                    "/catchup": {
                        "status": 302,
                        "body": b"",
                        "headers": {"Location": expected},
                    },
                }
            )
            upstream.start()
            try:
                status, hdrs, _ = http_get(
                    "127.0.0.1",
                    shared_r2h.port,
                    f"/http/127.0.0.1:{upstream.port}/catchup",
                    timeout=5.0,
                )
                assert status == 302
                location = _get_location(hdrs)
                assert location is not None, "Location header missing"
                assert location == expected

                stream_status, _, body = stream_get(
                    "127.0.0.1",
                    shared_r2h.port,
                    location,
                    read_bytes=4096,
                    timeout=20.0,
                )
                assert stream_status == 200
                assert len(body) > 0, "Expected RTSP stream after following relative Location"
            finally:
                upstream.stop()
        finally:
            rtsp.stop()

    @pytest.mark.multicast
    def test_302_rtp_location_rewritten_and_playable(self, r2h_binary):
        """HTTP 302 to rtp:// should rewrite to /rtp/... and the client can play it."""
        port = find_free_port()
        r2h = R2HProcess(r2h_binary, port, extra_args=["-v", "4", "-m", "100", "-r", LOOPBACK_IF])
        mcast_port = find_free_udp_port()
        sender = MulticastSender(addr=MCAST_ADDR, port=mcast_port, pps=200)
        rtp_url = f"rtp://{MCAST_ADDR}:{mcast_port}"
        expected = f"/rtp/{MCAST_ADDR}:{mcast_port}"
        upstream = MockHTTPUpstream(
            routes={
                "/live": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": rtp_url},
                },
            }
        )
        sender.start()
        upstream.start()
        try:
            r2h.start()
            status, hdrs, _ = http_get(
                "127.0.0.1",
                port,
                f"/http/127.0.0.1:{upstream.port}/live",
                timeout=5.0,
            )
            assert status == 302
            location = _get_location(hdrs)
            assert location is not None, "Location header missing"
            assert location == expected

            stream_status, _, body = stream_get(
                "127.0.0.1",
                port,
                location,
                read_bytes=4096,
                timeout=10.0,
            )
            assert stream_status == 200
            assert len(body) > 0, "Expected multicast stream after following rewritten Location"
        finally:
            r2h.stop()
            upstream.stop()
            sender.stop()

    def test_relative_location_does_not_log_http_scheme_error(self, r2h_binary):
        """Relative Location must not be logged as 'URL must start with http://'."""
        port = find_free_port()
        r2h = R2HProcess(r2h_binary, port, extra_args=["-v", "4", "-m", "5"])
        upstream = MockHTTPUpstream(
            routes={
                "/catchup": {
                    "status": 302,
                    "body": b"",
                    "headers": {"Location": "/rtsp/example"},
                },
            }
        )
        upstream.start()
        try:
            r2h.start()
            status, hdrs, _ = http_get(
                "127.0.0.1",
                port,
                f"/http/127.0.0.1:{upstream.port}/catchup",
                timeout=5.0,
            )
            assert status == 302
            assert _get_location(hdrs) == "/rtsp/example"
            log = r2h.read_log()
            assert "URL must start with http://" not in log
        finally:
            r2h.stop()
            upstream.stop()


# ---------------------------------------------------------------------------
# HTTP proxy with empty response body
# ---------------------------------------------------------------------------


class TestProxyEmptyBody:
    """An upstream 200 with empty body should be forwarded."""

    def test_empty_200(self, shared_r2h):
        upstream = MockHTTPUpstream(
            routes={
                "/empty": {"status": 200, "body": b""},
            }
        )
        upstream.start()
        try:
            status, _, body = http_get(
                "127.0.0.1",
                shared_r2h.port,
                f"/http/127.0.0.1:{upstream.port}/empty",
                timeout=5.0,
            )
            assert status == 200
            assert body == b""
        finally:
            upstream.stop()
