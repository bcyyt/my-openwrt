---
layout: home
hero:
  name: rtp2httpd
  text: IPTV 转发服务器
  tagline: 将组播 RTP / RTSP / HLS 转为 HTTP 单播媒体流
  image:
    src: /icon.png
    alt: rtp2httpd
  actions:
    - theme: brand
      text: 快速上手
      link: /guide/quick-start
    - theme: alt
      text: GitHub
      link: https://github.com/stackia/rtp2httpd
features:
  - icon: 📡
    title: 多协议支持
    details: RTP/UDP、RTSP、HTTP (HLS) 转 HTTP 单播，兼容 udpxy URL 格式
  - icon: ⚡
    title: FCC 快速换台
    details: 支持运营商 FCC 协议，毫秒级换台响应，媲美原生机顶盒体验
  - icon: 📋
    title: M3U 播放列表
    details: 自动识别并转换 RTP/RTSP 地址，支持 catchup 时移回看源
  - icon: 🛡️
    title: 抗丢包纠错
    details: RTP 乱序恢复、Reed-Solomon FEC 前向纠错，消除网络抖动花屏
  - icon: 🎬
    title: 内置播放器
    details: 现代化 Web 播放器，支持 EPG、时移回看、画质增强，桌面/移动端自适应
  - icon: 📷
    title: 频道快照
    details: 通过 HTTP 获取频道实时截图，可作为播放器频道预览图
  - icon: 📊
    title: 实时监控
    details: Web 状态页面，连接统计、带宽监控、日志查看、远程管理
  - icon: 🚀
    title: 轻量高性能
    details: 纯 C 零依赖，epoll + 多核 + 共享缓冲，x86_64 仅 509KB
---

<div class="demo-section">
  <div class="demo-section__heading">
    <span class="demo-section__eyebrow">Live showcase</span>
    <h2>效果演示</h2>
  </div>

  <div class="demo-grid">
    <article class="demo-card">
      <header class="demo-card__header">
        <span class="demo-card__index">01</span>
        <h3>快速换台 + 时移回看</h3>
      </header>
      <div class="demo-card__media">
        <video controls muted preload="metadata" src="https://github.com/user-attachments/assets/ca1a332f-d6e7-4a1e-be88-92bef67758b3"></video>
      </div>
      <aside class="demo-callout">
        <span class="demo-callout__label">提示</span>
        <p>快速换台需要搭配使用针对 IPTV 优化的播放器，例如 <a href="https://github.com/mytv-android/mytv-android" target="_blank" rel="noreferrer">mytv-android</a> / <a href="https://tivimate.com" target="_blank" rel="noreferrer">TiviMate</a> / <a href="https://apps.apple.com/us/app/cloud-stream-iptv-player/id1138002135" target="_blank" rel="noreferrer">Cloud Stream</a> / 内置 Web 播放器等。视频中的播放器是 mytv-android。</p>
        <p>一些常见的万能播放器（如 PotPlayer / IINA）没有针对起播速度做优化，不会有明显效果。</p>
      </aside>
    </article>
    <article class="demo-card demo-card--cyan">
      <header class="demo-card__header">
        <span class="demo-card__index">02</span>
        <h3>内置 Web 播放器</h3>
      </header>
      <div class="demo-card__media">
        <video controls muted preload="metadata" src="https://github.com/user-attachments/assets/d3dab0c0-03c4-453b-86ae-85406e5208eb"></video>
      </div>
      <aside class="demo-callout">
        <span class="demo-callout__label">提示</span>
        <p>需要配置 M3U 播放列表后使用，通过浏览器访问 <code>http://&lt;server:port&gt;/player</code> 即可打开。</p>
        <p>受限于浏览器解码能力，一些频道可能不支持（表现为无音频、画面黑屏）。</p>
      </aside>
    </article>
    <article class="demo-card demo-card--emerald">
      <header class="demo-card__header">
        <span class="demo-card__index">03</span>
        <h3>实时状态监控</h3>
      </header>
      <div class="demo-card__media">
        <img src="./images/web-dashboard.png" alt="实时状态监控" loading="lazy" />
      </div>
    </article>
    <article class="demo-card demo-card--amber">
      <header class="demo-card__header">
        <span class="demo-card__index">04</span>
        <h3>25 条 1080p 组播流同时播放</h3>
      </header>
      <div class="demo-card__media">
        <video controls muted preload="metadata" src="https://github.com/user-attachments/assets/9d531ab6-6c35-4c50-802a-71f88b6b22c5"></video>
      </div>
      <aside class="demo-callout">
        <span class="demo-callout__label">性能</span>
        <p>单流码率 8 Mbps。总仅占用 25% CPU 单核 (i3-N305)，消耗 4MB 内存。</p>
        <p>与 udpxy / msd_lite / tvgate 的对比，详见 <a href="/reference/benchmark">性能测试报告</a>。</p>
      </aside>
    </article>
  </div>
</div>
