# Installation

rtp2httpd supports multiple installation methods to suit different usage scenarios.

## OpenWrt Router Deployment

OpenWrt is the best runtime environment for rtp2httpd. In mainland China, you usually need to complete IPTV network integration first (you can search for tutorials like `OpenWrt IPTV integration`), obtain IPTV internal network IP via DHCP, before you can access the ISP's IPTV multicast network.

See [Quick Start](/en/guide/quick-start) for details.

## Built-in Firmware and Platforms

The following firmware distributions and platforms include rtp2httpd, or offer it for direct installation from their app stores or official package repositories.

> [!IMPORTANT]
> To ensure stability, bundled or listed rtp2httpd versions usually lag behind the latest official release. If you want to stay up to date, consider using another installation method.

- [fnOS](https://www.fnnas.com): rtp2httpd is available in the App Center and integrates deeply with the fnOS desktop, Unified Gateway, and FN Connect
- [iStoreOS](https://site.istoreos.com): rtp2httpd is available in iStore
- [iKuai](https://www.ikuai8.com): rtp2httpd is available in the App Market
- [LCMD MicroServer](https://lazycat.cloud): rtp2httpd is available in the App Store
- [cooluc's OpenWrt](https://github.com/sbwml/builder): rtp2httpd is built in
- [ImmortalWrt](https://github.com/immortalwrt/immortalwrt): rtp2httpd has been added to the official repository
- [AutoBuildImmortalWrt](https://github.com/wukongdaily/AutoBuildImmortalWrt): rtp2httpd is built into [store](https://github.com/wukongdaily/store) for easy builds
- [Pandora QWRT for K2P](https://www.right.com.cn/forum/forum.php?mod=viewthread&tid=8346913&fromuid=402348): rtp2httpd is built in

## Homebrew Deployment

On macOS and Linux, you can install rtp2httpd using [Homebrew](https://brew.sh):

```bash
brew install rtp2httpd
```

After installation, edit the configuration file at `$(brew --prefix)/etc/rtp2httpd.conf`, then start the service (and register it to start automatically when the user logs in after boot):

```bash
brew services start rtp2httpd
```

To start automatically at system boot without requiring a user to log in, use sudo:

```bash
# Stop the user service first if it was previously started to avoid duplicate instances
brew services stop rtp2httpd
sudo brew services start rtp2httpd
```

## Static Binary Deployment

Download the static binary file `rtp2httpd-<version>-<arch>` for your architecture from the [Releases](https://github.com/stackia/rtp2httpd/releases) page, upload to your device, `chmod +x` and run.

By default, it reads configuration from `/etc/rtp2httpd.conf`. You can override with `--config` or `--noconfig` parameters.

**Example**:

```bash
# Get your CPU architecture
uname -m

# Download binary file
wget https://github.com/stackia/rtp2httpd/releases/download/vX.Y.Z/rtp2httpd-X.Y.Z-x86_64
chmod +x rtp2httpd-X.Y.Z-x86_64

# Run with config file
./rtp2httpd-X.Y.Z-x86_64 --config /path/to/rtp2httpd.conf

# Run with command-line parameters only
./rtp2httpd-X.Y.Z-x86_64 --noconfig --verbose 2 --listen 5140 --maxclients 20
```

> [!TIP]
> You can use this example file [rtp2httpd.conf](https://github.com/stackia/rtp2httpd/blob/main/rtp2httpd.conf) as a base to modify your configuration. See [Configuration Reference](/en/reference/configuration) for details.

On systems using systemd, such as Debian/Ubuntu, you can create a systemd service unit by adding the following content to `/etc/systemd/system/rtp2httpd.service`.

```text
[Unit]
Description=rtp2httpd - Multicast RTP/RTSP to Unicast HTTP stream converter
Documentation=https://github.com/stackia/rtp2httpd
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=60
StartLimitBurst=10

[Service]
Type=simple
# The path in ExecStart must match the actual installation location; you can verify it with `command -v rtp2httpd` or `which rtp2httpd`.
# ExecStart=/usr/local/bin/rtp2httpd --config /etc/rtp2httpd.conf
ExecStart=/opt/rtp2httpd/rtp2httpd --config /opt/rtp2httpd/rtp2httpd.conf
ExecReload=/bin/kill -HUP $MAINPID
Restart=always
RestartSec=3s
# It is recommended to run as a dedicated non-root user, which can be created via `useradd --system --no-create-home --shell /usr/sbin/nologin rtp2httpd`
User=rtp2httpd
Group=rtp2httpd
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
```

Once the file has been created, use the following commands to start the rtp2httpd service.

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now rtp2httpd
sudo systemctl status rtp2httpd
```

## Docker Container Deployment

Suitable for Docker-capable devices. **Requires host network mode** to properly receive multicast streams.

### Basic Startup

```bash
docker run --network=host --cap-add=NET_ADMIN --rm \
  ghcr.io/stackia/rtp2httpd:latest \
  --noconfig --verbose 2 --listen 5140 --maxclients 20
```

### Using docker-compose

```yaml
services:
  rtp2httpd:
    image: ghcr.io/stackia/rtp2httpd:latest
    network_mode: host
    restart: always
    cap_add:
      - NET_ADMIN
    command: --noconfig --verbose 2 --listen 5140 --maxclients 20
```

> [!NOTE]
> **About recommended parameters**:
>
> - `cap_add: NET_ADMIN`: Allows bypassing the kernel parameter `net.core.rmem_max` limit via `SO_RCVBUFFORCE`, setting a larger UDP receive buffer

### Mount Configuration File

If you need to use a configuration file (assuming config file is at `/path/to/rtp2httpd.conf`):

```bash
docker run --network=host --cap-add=NET_ADMIN --rm \
  -v /path/to/rtp2httpd.conf:/usr/local/etc/rtp2httpd.conf:ro \
  ghcr.io/stackia/rtp2httpd:latest
```

> [!TIP]
> You can use this example file [rtp2httpd.conf](https://github.com/stackia/rtp2httpd/blob/main/rtp2httpd.conf) as a base to modify your configuration. See [Configuration Reference](/en/reference/configuration) for details.

## OpenWrt Build Integration

If you want to build rtp2httpd directly into your firmware via OpenWrt source, you can add this repository directly to `feeds.conf.default`:

```text
# Use latest code from main branch
src-git rtp2httpd https://github.com/stackia/rtp2httpd.git
```

Or specify a version:

```text
# Use v3.10.1 code
src-git rtp2httpd https://github.com/stackia/rtp2httpd.git;v3.10.1
```

Run `./scripts/feeds update rtp2httpd` and `./scripts/feeds install rtp2httpd` to update the feed.

Run `make menuconfig`, find `LuCI -> Applications -> luci-app-rtp2httpd`, select it as `*` (build into firmware) or `M` (build as ipk/apk package), save and exit.

Run `make package/feeds/rtp2httpd/luci-app-rtp2httpd/compile -j1 V=sc` to build `luci-app-rtp2httpd` and `rtp2httpd` packages separately.

### Firmware Maintainer Guide

If you maintain a third-party OpenWrt firmware and want to integrate rtp2httpd directly into your feeds repository (rather than via `src-git` reference), you can use the `Makefile.versioned` provided by this project:

```bash
git clone https://github.com/stackia/rtp2httpd.git
cd rtp2httpd

# Replace original Makefile with pre-generated one (includes fixed version number, source download URL and PKG_HASH)
mv openwrt-support/rtp2httpd/Makefile.versioned openwrt-support/rtp2httpd/Makefile
mv openwrt-support/luci-app-rtp2httpd/Makefile.versioned openwrt-support/luci-app-rtp2httpd/Makefile

# Copy openwrt-support directory contents to your feeds repository
cp -r openwrt-support/* /path/to/your/feeds/
```

The difference between `Makefile.versioned` and the original `Makefile` is: version number is fixed, `PKG_HASH` is filled, builds download source package from GitHub Release, no local git repository needed. Every time rtp2httpd releases a new version, the `Makefile.versioned` in the main branch is automatically updated.

## Building from Source

Suitable for scenarios requiring custom builds or development debugging.

### Install Dependencies

```bash
# Ubuntu/Debian
sudo apt-get install build-essential cmake pkg-config curl

# Install Node.js LTS (for building Web UI)
curl -fsSL https://deb.nodesource.com/setup_24.x | sudo -E bash -
sudo apt-get install -y nodejs
corepack enable
```

### Build Steps

```bash
# Clone repository
git clone https://github.com/stackia/rtp2httpd.git
cd rtp2httpd

# Build Web UI and embed static resources
pnpm install --frozen-lockfile
pnpm run web-ui:build

# Configure and build
cmake -B build -DCMAKE_BUILD_TYPE=Release -DENABLE_AGGRESSIVE_OPT=ON
cmake --build build -j$(getconf _NPROCESSORS_ONLN)

# Install
sudo cmake --install build
```

## Next Steps

- [Quick Start](/en/guide/quick-start): OpenWrt quick configuration guide
- [Configuration Reference](/en/reference/configuration): Learn all configuration options
- [URL Format Guide](/en/guide/url-formats): Learn all supported URL formats
- [M3U Playlist Integration](/en/guide/m3u-integration): Configure playlist
- [FCC Fast Channel Change Setup](/en/guide/fcc-setup): Enable millisecond-level channel switching
